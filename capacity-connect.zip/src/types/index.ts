// =====================================================================
// CAPACITY CONNECT — TYPES & DATA MODELS
// Concept: CO1 (Normalized Entity Types matching MySQL Relational Tables)
// =====================================================================

export type UserRole = 'trainee' | 'trainer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  primaryRole: UserRole;
  activeRole: 'trainee' | 'trainer' | 'admin';
  hasTraineeRole: boolean;
  hasTrainerRole: boolean;
  isCoadmin: boolean;
  isMasterAdmin: boolean;
  bio?: string;
  headline?: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface TrainerProfile {
  userId: string;
  name: string;
  email: string;
  expertise: string;
  skills: string[];
  subjects: string[]; // Editable subjects/topics
  qualifications: string;
  experienceYears: number;
  certifications: string;
  availability: string;
  rating: number;
  totalReviews: number;
  isPubliclyVisible: boolean;
}

export interface CourseModule {
  id: string;
  title: string;
  duration: string;
  learningOutcomes: string[];
}

export interface CourseSkillRequirement {
  skill: string;
  requiredLevel: number; // 1 to 5
}

export interface Course {
  id: string;
  trainerId: string;
  trainerName: string;
  title: string;
  description: string;
  requiredSkills: CourseSkillRequirement[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  thumbnailUrl?: string;
  modules: CourseModule[];
  isPublished: boolean;
  enrolledCount: number;
  createdAt: string;
}

export type RequestStatus = 'pending' | 'accepted' | 'declined';

export interface SkillExchangeRequest {
  id: string;
  traineeId: string;
  traineeName: string;
  traineeEmail: string;
  trainerId: string;
  trainerName: string;
  trainerEmail?: string;
  courseId?: string;
  courseTitle?: string;
  learnSkill: string; // What trainee wants to learn
  teachSkill: string; // What trainee can teach in return
  notes?: string;
  status: RequestStatus;
  responseNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CourseEnrollment {
  id: string;
  traineeId: string;
  courseId: string;
  courseTitle: string;
  progressPercent: number;
  status: 'active' | 'completed' | 'dropped';
  enrolledAt: string;
  completedAt?: string;
}

export interface TraineeCompetency {
  id: string;
  traineeId: string;
  skillName: string;
  currentLevel: number; // 1 to 5
  updatedAt: string;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  points: number;
  // CRITICAL SECURITY: correctOption is NEVER sent to trainee frontend
  correctOption?: number; 
}

export interface Assessment {
  id: string;
  trainerId: string;
  trainerName: string;
  courseId: string;
  courseTitle: string;
  title: string;
  targetCompetency: string;
  durationMinutes: number;
  passingScore: number;
  questions: Question[];
  isPublished: boolean;
  createdAt: string;
}

export interface AssessmentSubmission {
  id: string;
  assessmentId: string;
  assessmentTitle: string;
  courseId: string;
  traineeId: string;
  traineeName: string;
  score: number;
  totalMarks: number;
  percentage: number;
  passed: boolean;
  submittedAnswers: Record<string, number>;
  submittedAt: string;
}

export interface Certificate {
  id: string;
  credentialId: string;
  traineeId: string;
  traineeName: string;
  trainerId: string;
  trainerName: string;
  courseId: string;
  courseTitle: string;
  skillAcquired: string;
  issueDate: string;
  status: 'issued' | 'revoked';
  grade?: string;
}

export type ResourceFileType = 'pdf' | 'doc' | 'docx' | 'image' | 'video' | 'link';

export interface KnowledgeResource {
  id: string;
  trainerId: string;
  trainerName: string;
  title: string;
  description: string;
  category: string;
  fileType: ResourceFileType;
  fileUrl: string;
  fileSize?: string;
  status: 'approved' | 'pending_review' | 'rejected';
  downloadsCount: number;
  createdAt: string;
}

export interface CoAdminRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  currentRole: string;
  reason: string;
  status: 'pending' | 'approved' | 'declined';
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  recipientId: string;
  senderId?: string;
  title: string;
  message: string;
  type: 'request_sent' | 'request_accepted' | 'request_declined' | 'assessment_result' | 'coadmin_request' | 'coadmin_approved' | 'cert_issued' | 'system';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  requestId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}

export interface TrainingSession {
  id: string;
  trainerId: string;
  trainerName: string;
  traineeId: string;
  traineeName: string;
  courseId?: string;
  courseTitle?: string;
  title: string;
  sessionDate: string;
  startTime: string;
  durationMinutes: number;
  meetingLink?: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
}
