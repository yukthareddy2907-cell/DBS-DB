import React, { useState, useEffect } from 'react';
import { 
  User, 
  TrainerProfile, 
  Course, 
  SkillExchangeRequest, 
  Assessment, 
  Certificate, 
  KnowledgeResource, 
  TrainingSession,
  AssessmentSubmission
} from '../types';
import { 
  getTrainers, 
  updateTrainerProfile, 
  getCourses, 
  createCourse, 
  deleteCourse,
  getSkillExchangeRequests, 
  handleSkillExchangeRequest,
  getAssessments, 
  createAssessment, 
  deleteAssessment,
  getAssessmentSubmissions,
  getCertificates, 
  issueCertificate,
  uploadKnowledgeResource, 
  getKnowledgeResources,
  getTrainingSessions,
  getAllUsers,
  subscribeToRealtimeEvents
} from '../services/storage';
import { RealTimeChat } from '../components/RealTimeChat';
import { ScheduleCalendar } from '../components/ScheduleCalendar';
import { downloadCertificatePdf } from '../services/pdfGenerator';
import { 
  BookOpen, 
  Users, 
  Award, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Calendar, 
  Plus, 
  MessageSquare, 
  Upload, 
  FileText, 
  ShieldCheck, 
  Trash2, 
  Edit3,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Download
} from 'lucide-react';

interface TrainerDashboardProps {
  currentUser: User;
}

export const TrainerDashboard: React.FC<TrainerDashboardProps> = ({ currentUser }) => {
  // Navigation tabs for Trainer (NOTE: AI Learning Assistant removed, My Learning removed from Course Management)
  const [activeTab, setActiveTab] = useState<
    'overview' | 'requests' | 'courses' | 'assessments' | 'certificates' | 'profile' | 'knowledge' | 'schedule'
  >('overview');

  const [profile, setProfile] = useState<TrainerProfile | null>(null);
  const [myCourses, setMyCourses] = useState<Course[]>([]);
  const [requests, setRequests] = useState<SkillExchangeRequest[]>([]);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [submissions, setSubmissions] = useState<AssessmentSubmission[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [resources, setResources] = useState<KnowledgeResource[]>([]);
  const [sessions, setSessions] = useState<TrainingSession[]>([]);

  // Modals
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [showAssessmentModal, setShowAssessmentModal] = useState(false);
  const [showIssueCertModal, setShowIssueCertModal] = useState(false);
  const [showResourceModal, setShowResourceModal] = useState(false);
  const [activeChatRequest, setActiveChatRequest] = useState<SkillExchangeRequest | null>(null);

  // New Course Form State
  const [courseTitle, setCourseTitle] = useState('');
  const [courseDesc, setCourseDesc] = useState('');
  const [courseDifficulty, setCourseDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [courseDuration, setCourseDuration] = useState('4 Weeks');
  const [courseSkillsInput, setCourseSkillsInput] = useState('Python Basics (3), Functions & Scope (4), OOP (4)');

  // New Assessment Form State
  const [selectedCourseForAss, setSelectedCourseForAss] = useState('');
  const [assTitle, setAssTitle] = useState('');
  const [assTargetComp, setAssTargetComp] = useState('');
  const [assPassingScore, setAssPassingScore] = useState(70);
  const [assDuration, setAssDuration] = useState(20);
  const [questions, setQuestions] = useState([
    { question: '', options: ['', '', '', ''], correctOption: 0, points: 1 }
  ]);

  // Issue Certificate Form State
  const [selectedTraineeId, setSelectedTraineeId] = useState('');
  const [selectedCertCourseId, setSelectedCertCourseId] = useState('');
  const [certSkillAcquired, setCertSkillAcquired] = useState('');

  // Knowledge Resource Form State
  const [resTitle, setResTitle] = useState('');
  const [resDesc, setResDesc] = useState('');
  const [resCat, setResCat] = useState('Technical Documentation');
  const [resType, setResType] = useState<'pdf' | 'doc' | 'video' | 'link'>('pdf');
  const [resUrl, setResUrl] = useState('');
  const [uploadMode, setUploadMode] = useState<'file' | 'url'>('file');
  const [fileName, setFileName] = useState('');
  const [fileSizeStr, setFileSizeStr] = useState('');
  const [fileDataUrl, setFileDataUrl] = useState('');

  // Profile Edit State
  const [editExpertise, setEditExpertise] = useState('');
  const [editSubjects, setEditSubjects] = useState('');
  const [editAvailability, setEditAvailability] = useState('');
  const [profileSaved, setProfileSaved] = useState(false);

  const loadData = () => {
    const trainers = getTrainers();
    let myProf = trainers.find(t => t.userId === currentUser.id);
    if (!myProf) {
      // Auto-initialize profile if not exists
      myProf = {
        userId: currentUser.id,
        name: currentUser.name,
        email: currentUser.email,
        expertise: currentUser.headline || 'Industry Trainer',
        skills: ['Core Fundamentals', 'Project Architecture'],
        subjects: ['Core Concepts', 'Applied Practice', 'Code Reviews'],
        qualifications: 'Certified Specialist',
        experienceYears: 4,
        certifications: 'Professional Mentor',
        availability: 'Flexible (Evenings & Weekends)',
        rating: 5.0,
        totalReviews: 0,
        isPubliclyVisible: true
      };
    }
    setProfile(myProf);
    setEditExpertise(myProf.expertise);
    setEditSubjects(myProf.subjects.join(', '));
    setEditAvailability(myProf.availability);

    const crss = getCourses().filter(c => c.trainerId === currentUser.id);
    const reqs = getSkillExchangeRequests().filter(r => 
      r.trainerId === currentUser.id || 
      (r.trainerEmail && r.trainerEmail.toLowerCase() === currentUser.email.toLowerCase()) ||
      (r.trainerName && currentUser.name && r.trainerName.trim().toLowerCase() === currentUser.name.trim().toLowerCase())
    );
    const asses = getAssessments().filter(a => a.trainerId === currentUser.id);
    const subs = getAssessmentSubmissions().filter(s => {
      const parentAss = asses.find(a => a.id === s.assessmentId);
      return !!parentAss;
    });
    const certs = getCertificates().filter(c => c.trainerId === currentUser.id);
    const res = getKnowledgeResources().filter(r => r.trainerId === currentUser.id);
    const sess = getTrainingSessions().filter(s => s.trainerId === currentUser.id);

    setMyCourses(crss);
    setRequests(reqs);
    setAssessments(asses);
    setSubmissions(subs);
    setCertificates(certs);
    setResources(res);
    setSessions(sess);

    if (crss.length > 0 && !selectedCourseForAss) {
      setSelectedCourseForAss(crss[0].id);
      setSelectedCertCourseId(crss[0].id);
    }
  };

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToRealtimeEvents(() => {
      loadData();
    });
    return unsubscribe;
  }, [currentUser.id]);

  // Request Accept / Decline Actions with Real-time sync
  const handleDecision = (requestId: string, decision: 'accepted' | 'declined') => {
    handleSkillExchangeRequest(requestId, decision);
  };

  // Create Course Handler
  const handleCreateCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseTitle.trim() || !courseDesc.trim()) return;

    // Parse skills format: "Skill Name (RequiredLevel)"
    const requiredSkills = courseSkillsInput.split(',').map(s => {
      const match = s.match(/(.+)\((\d+)\)/);
      if (match) {
        return { skill: match[1].trim(), requiredLevel: Number(match[2]) || 3 };
      }
      return { skill: s.trim(), requiredLevel: 3 };
    }).filter(s => s.skill.length > 0);

    createCourse({
      trainerId: currentUser.id,
      trainerName: currentUser.name,
      title: courseTitle.trim(),
      description: courseDesc.trim(),
      difficulty: courseDifficulty,
      duration: courseDuration,
      requiredSkills,
      modules: [
        { id: 'm1', title: 'Foundations & Architecture', duration: '1 Week', learningOutcomes: ['Core concepts'] },
        { id: 'm2', title: 'Advanced Implementation', duration: '2 Weeks', learningOutcomes: ['Practical skills'] }
      ],
      isPublished: true
    });

    setShowCourseModal(false);
    setCourseTitle('');
    setCourseDesc('');
  };

  // Create Assessment Handler
  const handleCreateAssessment = (e: React.FormEvent) => {
    e.preventDefault();
    const course = myCourses.find(c => c.id === selectedCourseForAss);
    if (!course || !assTitle.trim()) return;

    createAssessment({
      trainerId: currentUser.id,
      trainerName: currentUser.name,
      courseId: course.id,
      courseTitle: course.title,
      title: assTitle.trim(),
      targetCompetency: assTargetComp.trim() || 'Core Competency',
      durationMinutes: Number(assDuration),
      passingScore: Number(assPassingScore),
      questions: questions.map((q, i) => ({
        id: 'q_' + i + '_' + Date.now(),
        question: q.question,
        options: q.options,
        points: q.points || 1,
        correctOption: q.correctOption // SECURE: Kept on backend / database
      })),
      isPublished: true
    });

    setShowAssessmentModal(false);
    setAssTitle('');
    setQuestions([{ question: '', options: ['', '', '', ''], correctOption: 0, points: 1 }]);
  };

  // Issue Certificate Handler
  const handleIssueCert = (e: React.FormEvent) => {
    e.preventDefault();
    const course = myCourses.find(c => c.id === selectedCertCourseId);
    const allUsers = getAllUsers();
    const trainee = allUsers.find(u => u.id === selectedTraineeId);

    if (!course || !trainee) return;

    issueCertificate({
      traineeId: trainee.id,
      traineeName: trainee.name,
      trainerId: currentUser.id,
      trainerName: currentUser.name,
      courseId: course.id,
      courseTitle: course.title,
      skillAcquired: certSkillAcquired.trim() || course.title
    });

    setShowIssueCertModal(false);
    setSelectedTraineeId('');
    setCertSkillAcquired('');
  };

  // File explorer picker
  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const sizeKb = file.size / 1024;
    const formattedSize = sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} MB` : `${Math.round(sizeKb)} KB`;
    setFileSizeStr(formattedSize);

    if (!resTitle.trim()) {
      const cleanTitle = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setResTitle(cleanTitle);
    }

    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'pdf') {
      setResType('pdf');
    } else if (ext === 'doc' || ext === 'docx') {
      setResType('doc');
    } else if (['mp4', 'mov', 'webm', 'mkv'].includes(ext || '')) {
      setResType('video');
    } else if (['jpg', 'jpeg', 'png', 'svg', 'webp'].includes(ext || '')) {
      setResType('image' as any);
    }

    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      const result = loadEvt.target?.result as string;
      setFileDataUrl(result);
    };
    reader.readAsDataURL(file);
  };

  // Upload Resource Handler
  const handleUploadResource = (e: React.FormEvent) => {
    e.preventDefault();
    const finalUrl = uploadMode === 'file' ? fileDataUrl : resUrl.trim();
    if (!resTitle.trim() || !finalUrl) {
      alert('Please provide a title and select a file or enter a valid resource URL.');
      return;
    }

    uploadKnowledgeResource({
      trainerId: currentUser.id,
      trainerName: currentUser.name,
      title: resTitle.trim(),
      description: resDesc.trim(),
      category: resCat,
      fileType: resType,
      fileUrl: finalUrl,
      fileSize: uploadMode === 'file' ? fileSizeStr : undefined,
      status: 'approved'
    });

    setShowResourceModal(false);
    setResTitle('');
    setResDesc('');
    setResUrl('');
    setFileName('');
    setFileSizeStr('');
    setFileDataUrl('');
  };

  // Profile Save Handler
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const subjectsArray = editSubjects.split(',').map(s => s.trim()).filter(Boolean);

    updateTrainerProfile({
      userId: currentUser.id,
      expertise: editExpertise.trim(),
      subjects: subjectsArray,
      availability: editAvailability.trim()
    });

    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  // Accepted trainees for session scheduling and certifications
  const acceptedTrainees = requests
    .filter(r => r.status === 'accepted')
    .map(r => ({ id: r.traineeId, name: r.traineeName }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Top Banner */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
            Trainer &amp; Mentorship Portal
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
            Trainer Console — {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage reciprocal skill exchange requests, publish courses, conduct assessments, and issue verifiable credentials.
          </p>
        </div>

        {/* Quick Trainer Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowCourseModal(true)}
            className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-xs cursor-pointer transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Publish Course</span>
          </button>
        </div>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1 space-y-2">
          <div className="bg-white rounded-xl border border-slate-200 p-2 shadow-xs space-y-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <TrendingUp className="w-4 h-4" />
                <span>Dashboard Overview</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('requests')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'requests'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Users className="w-4 h-4" />
                <span>Trainees &amp; Skill Requests</span>
              </div>
              <span className="text-[10px] font-bold">{requests.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('courses')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'courses'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <BookOpen className="w-4 h-4" />
                <span>Course Management</span>
              </div>
              <span className="text-[10px] font-bold">{myCourses.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('assessments')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'assessments'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Assessments</span>
              </div>
              <span className="text-[10px] font-bold">{assessments.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('certificates')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'certificates'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Award className="w-4 h-4" />
                <span>Issued Certificates</span>
              </div>
              <span className="text-[10px] font-bold">{certificates.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Edit3 className="w-4 h-4" />
                <span>Trainer Profile</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('schedule')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'schedule'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Calendar className="w-4 h-4" />
                <span>Live Schedule</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('knowledge')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'knowledge'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <FileText className="w-4 h-4" />
                <span>Knowledge Resources</span>
              </div>
              <span className="text-[10px] font-bold">{resources.length}</span>
            </button>
          </div>
        </div>

        {/* Right Main Content */}
        <div className="lg:col-span-3 space-y-6">

          {/* TAB 1: OVERVIEW METRICS */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Total Requests</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">{requests.length}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Active Trainees</p>
                  <p className="text-xl font-bold text-blue-600 mt-1">
                    {requests.filter(r => r.status === 'accepted').length}
                  </p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Published Courses</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">{myCourses.length}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Certificates Issued</p>
                  <p className="text-xl font-bold text-emerald-600 mt-1">{certificates.length}</p>
                </div>
              </div>

              {/* Recent Pending Requests Quick Access */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-900">Pending Trainee Requests</h3>
                  <button
                    onClick={() => setActiveTab('requests')}
                    className="text-xs text-blue-600 hover:text-blue-800 font-semibold"
                  >
                    View All →
                  </button>
                </div>

                {requests.filter(r => r.status === 'pending').length === 0 ? (
                  <p className="text-xs text-slate-400 py-3 text-center">No pending skill exchange requests.</p>
                ) : (
                  <div className="space-y-2">
                    {requests.filter(r => r.status === 'pending').map(req => (
                      <div
                        key={req.id}
                        className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs font-bold text-slate-800">{req.traineeName}</p>
                          <p className="text-[11px] text-slate-500">
                            Wants to learn: <strong>{req.learnSkill}</strong> | Can teach: <strong>{req.teachSkill}</strong>
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleDecision(req.id, 'accepted')}
                            className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => handleDecision(req.id, 'declined')}
                            className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold cursor-pointer"
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: TRAINEES & SKILL REQUESTS (Real-time synchronization) */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Trainees &amp; Skill Exchange Requests</h3>
                  <p className="text-xs text-slate-500">
                    Review and accept or decline incoming skill exchange proposals from trainees in real time.
                  </p>
                </div>
              </div>

              {requests.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No trainee requests received yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    When trainees browse your public trainer profile and submit a skill exchange proposal, it will appear here immediately.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {requests.map(req => {
                    const isPending = req.status === 'pending';
                    const isAccepted = req.status === 'accepted';
                    const isDeclined = req.status === 'declined';

                    return (
                      <div
                        key={req.id}
                        className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-slate-900">{req.traineeName}</span>
                            <span className="text-[11px] text-slate-400">({req.traineeEmail})</span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                isAccepted
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : isDeclined
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}
                            >
                              {req.status}
                            </span>
                          </div>

                          <p className="text-xs text-slate-600">
                            Wants to Learn: <strong className="text-blue-600">{req.learnSkill}</strong> | Can Teach: <strong className="text-slate-800">{req.teachSkill}</strong>
                          </p>

                          {req.courseTitle && (
                            <p className="text-[11px] text-slate-500">
                              Associated Course: <span className="font-semibold">{req.courseTitle}</span>
                            </p>
                          )}

                          {req.notes && (
                            <p className="text-[11px] text-slate-500 italic mt-1">&quot;{req.notes}&quot;</p>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center space-x-2 shrink-0">
                          {isPending ? (
                            <>
                              <button
                                onClick={() => handleDecision(req.id, 'accepted')}
                                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors shadow-xs"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Accept</span>
                              </button>
                              <button
                                onClick={() => handleDecision(req.id, 'declined')}
                                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors shadow-xs"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Decline</span>
                              </button>
                            </>
                          ) : isAccepted ? (
                            <button
                              onClick={() => setActiveChatRequest(req)}
                              className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Live Chat</span>
                            </button>
                          ) : (
                            <span className="text-xs text-rose-500 font-medium">Declined</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: COURSE MANAGEMENT (ONLY Publish courses, NO My Learning) */}
          {activeTab === 'courses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Published Courses</h3>
                  <p className="text-xs text-slate-500">
                    Courses authored and published by you, visible publicly to trainees.
                  </p>
                </div>
                <button
                  onClick={() => setShowCourseModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Create Course</span>
                </button>
              </div>

              {myCourses.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No courses published yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Click &quot;+ Create Course&quot; to publish your first structured capacity curriculum for trainees.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myCourses.map(course => (
                    <div
                      key={course.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                            {course.difficulty}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-1.5">{course.title}</h4>
                        </div>
                        <button
                          onClick={() => deleteCourse(course.id)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Delete Course"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">{course.description}</p>

                      <div className="text-xs text-slate-500 space-y-1 pt-1 border-t border-slate-100">
                        <p>Enrolled Trainees: <strong>{course.enrolledCount}</strong></p>
                        <p>Duration: <strong>{course.duration}</strong></p>
                      </div>

                      <div className="pt-2 flex flex-wrap gap-1">
                        {course.requiredSkills.map((s, idx) => (
                          <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                            {s.skill} (Lvl {s.requiredLevel})
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ASSESSMENTS MANAGEMENT (Create MCQs, Secure Answer Keys, View Attempts) */}
          {activeTab === 'assessments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Assessment Management</h3>
                  <p className="text-xs text-slate-500">
                    Author MCQs for your courses. Correct answers remain strictly confidential on the backend.
                  </p>
                </div>
                <button
                  onClick={() => setShowAssessmentModal(true)}
                  disabled={myCourses.length === 0}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Create Assessment</span>
                </button>
              </div>

              {assessments.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No assessments created yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Create course assessments to test connected trainees on competencies.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {assessments.map(ass => (
                      <div
                        key={ass.id}
                        className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                              {ass.targetCompetency}
                            </span>
                            <h4 className="text-xs font-bold text-slate-900 mt-1.5">{ass.title}</h4>
                            <p className="text-[11px] text-slate-500">{ass.courseTitle}</p>
                          </div>
                          <button
                            onClick={() => deleteAssessment(ass.id)}
                            className="text-slate-400 hover:text-rose-600 p-1"
                            title="Delete Assessment"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="text-xs text-slate-600 space-y-1 pt-1 border-t border-slate-100">
                          <p>Passing Threshold: <strong>{ass.passingScore}%</strong></p>
                          <p>Questions Count: <strong>{ass.questions.length}</strong></p>
                          <p>Duration: <strong>{ass.durationMinutes} mins</strong></p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Assessment Attempts & Scores Log */}
                  <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
                    <h4 className="text-xs font-bold text-slate-900">Trainee Submissions &amp; Evaluation Log</h4>
                    {submissions.length === 0 ? (
                      <p className="text-xs text-slate-400 py-2">No trainee submissions logged yet.</p>
                    ) : (
                      <div className="divide-y divide-slate-100 text-xs">
                        {submissions.map(sub => (
                          <div key={sub.id} className="py-2.5 flex items-center justify-between">
                            <div>
                              <p className="font-bold text-slate-800">{sub.traineeName}</p>
                              <p className="text-[11px] text-slate-500">{sub.assessmentTitle}</p>
                            </div>
                            <div className="text-right">
                              <span className={`font-bold ${sub.passed ? 'text-emerald-600' : 'text-rose-600'}`}>
                                {sub.score} / {sub.totalMarks} ({sub.percentage}%) — {sub.passed ? 'PASSED' : 'FAILED'}
                              </span>
                              <p className="text-[10px] text-slate-400">
                                {new Date(sub.submittedAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: CERTIFICATES DASHBOARD (Show issued certificates, Issue new certificate) */}
          {activeTab === 'certificates' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Issued Trainee Certificates</h3>
                  <p className="text-xs text-slate-500">
                    Certificates issued to trainees upon successful completion of your courses.
                  </p>
                </div>
                <button
                  onClick={() => setShowIssueCertModal(true)}
                  disabled={acceptedTrainees.length === 0 || myCourses.length === 0}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer disabled:opacity-50"
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>+ Issue Certificate</span>
                </button>
              </div>

              {certificates.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No certificates issued yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Once a trainee completes your course and assessment, click &quot;+ Issue Certificate&quot; to award their verified credential.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {certificates.map(cert => (
                    <div
                      key={cert.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 uppercase">
                            {cert.status}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1.5">{cert.courseTitle}</h4>
                          <p className="text-[11px] text-slate-500">Awarded to: <strong>{cert.traineeName}</strong></p>
                        </div>
                        <Award className="w-5 h-5 text-blue-600" />
                      </div>

                      <div className="text-xs text-slate-600 space-y-0.5 pt-1 border-t border-slate-100">
                        <p>Skill Acquired: <strong>{cert.skillAcquired}</strong></p>
                        <p>Issue Date: <strong>{cert.issueDate}</strong></p>
                        <p className="font-mono text-[10px] text-slate-400">ID: {cert.credentialId}</p>
                      </div>

                      <button
                        onClick={() => downloadCertificatePdf(cert)}
                        className="w-full py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-center space-x-1 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Trainee PDF</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: TRAINER PROFILE (Editable subjects/topics, publicly visible to trainees) */}
          {activeTab === 'profile' && profile && (
            <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Trainer Public Profile</h3>
                <p className="text-xs text-slate-500">
                  This profile is publicly visible to all trainees in the Trainer Matching directory.
                </p>
              </div>

              {profileSaved && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-lg flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Profile updated and published publicly!</span>
                </div>
              )}

              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Primary Expertise Domain
                  </label>
                  <input
                    type="text"
                    required
                    value={editExpertise}
                    onChange={e => setEditExpertise(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Editable Subjects / Topics (comma-separated)
                  </label>
                  <input
                    type="text"
                    required
                    value={editSubjects}
                    onChange={e => setEditSubjects(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    e.g. Distributed Databases, Microservice Design, Kafka Event Streaming
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Availability
                  </label>
                  <input
                    type="text"
                    required
                    value={editAvailability}
                    onChange={e => setEditAvailability(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Save &amp; Update Public Profile
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 7: SCHEDULE */}
          {activeTab === 'schedule' && (
            <ScheduleCalendar
              sessions={sessions}
              currentUser={currentUser}
              connectedUsers={acceptedTrainees}
            />
          )}

          {/* TAB 8: KNOWLEDGE HUB UPLOAD */}
          {activeTab === 'knowledge' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">My Knowledge Resources</h3>
                  <p className="text-xs text-slate-500">
                    Upload learning materials, guides, and links to the public Knowledge Hub.
                  </p>
                </div>
                <button
                  onClick={() => setShowResourceModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>+ Upload Resource</span>
                </button>
              </div>

              {resources.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No resources uploaded yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Share your technical documents, course slides, or reference videos with trainees.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {resources.map(res => (
                    <div
                      key={res.id}
                      className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                            {res.fileType}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1.5">{res.title}</h4>
                        </div>
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2">{res.description}</p>
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span>Category: {res.category}</span>
                        <a
                          href={res.fileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 font-semibold hover:underline flex items-center space-x-1"
                        >
                          <span>View</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* MODAL 1: Create Course */}
      {showCourseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Create &amp; Publish New Course</h3>
            <p className="text-xs text-slate-500 mb-4">Course will be immediately visible in the public catalog.</p>

            <form onSubmit={handleCreateCourse} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Course Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Modern Full-Stack Cloud Architecture"
                  value={courseTitle}
                  onChange={e => setCourseTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Overview of course curriculum and learning outcomes..."
                  value={courseDesc}
                  onChange={e => setCourseDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Difficulty</label>
                  <select
                    value={courseDifficulty}
                    onChange={e => setCourseDifficulty(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Duration</label>
                  <input
                    type="text"
                    value={courseDuration}
                    onChange={e => setCourseDuration(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Required Competencies &amp; Target Levels (for Skill Gap Detection)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Python Basics (3), Functions (4), OOP (4)"
                  value={courseSkillsInput}
                  onChange={e => setCourseSkillsInput(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Format: &quot;Skill Name (Level)&quot; comma-separated. Used for dynamic course skill-gap calculations!
                </p>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCourseModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Publish Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Create Assessment */}
      {showAssessmentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-xl w-full p-6 max-h-[85vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Author Course Assessment</h3>
            <p className="text-xs text-slate-500 mb-4">
              Answers are securely evaluated on the backend and never exposed to trainees.
            </p>

            <form onSubmit={handleCreateAssessment} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Select Course</label>
                <select
                  value={selectedCourseForAss}
                  onChange={e => setSelectedCourseForAss(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                >
                  {myCourses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Assessment Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Module 1: Foundations Competency Check"
                  value={assTitle}
                  onChange={e => setAssTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Target Skill</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Python Basics"
                    value={assTargetComp}
                    onChange={e => setAssTargetComp(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Pass Score (%)</label>
                  <input
                    type="number"
                    min={40}
                    max={100}
                    value={assPassingScore}
                    onChange={e => setAssPassingScore(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Duration (m)</label>
                  <input
                    type="number"
                    min={5}
                    max={120}
                    value={assDuration}
                    onChange={e => setAssDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              </div>

              {/* Questions Builder */}
              <div className="space-y-4 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800">MCQ Questions</h4>
                  <button
                    type="button"
                    onClick={() => setQuestions(prev => [
                      ...prev,
                      { question: '', options: ['', '', '', ''], correctOption: 0, points: 1 }
                    ])}
                    className="text-xs text-blue-600 font-semibold"
                  >
                    + Add Question
                  </button>
                </div>

                {questions.map((q, qIdx) => (
                  <div key={qIdx} className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-2.5">
                    <input
                      type="text"
                      required
                      placeholder={`Question ${qIdx + 1}`}
                      value={q.question}
                      onChange={e => {
                        const newQ = [...questions];
                        newQ[qIdx].question = e.target.value;
                        setQuestions(newQ);
                      }}
                      className="w-full px-3 py-1.5 text-xs bg-white rounded border border-slate-300"
                    />

                    <div className="space-y-1.5">
                      {q.options.map((opt, optIdx) => (
                        <div key={optIdx} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            name={`correct_${qIdx}`}
                            checked={q.correctOption === optIdx}
                            onChange={() => {
                              const newQ = [...questions];
                              newQ[qIdx].correctOption = optIdx;
                              setQuestions(newQ);
                            }}
                            title="Mark as correct answer"
                          />
                          <input
                            type="text"
                            required
                            placeholder={`Option ${optIdx + 1}`}
                            value={opt}
                            onChange={e => {
                              const newQ = [...questions];
                              newQ[qIdx].options[optIdx] = e.target.value;
                              setQuestions(newQ);
                            }}
                            className="flex-1 px-2.5 py-1 text-xs bg-white rounded border border-slate-300"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAssessmentModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Save Assessment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Issue Certificate */}
      {showIssueCertModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Issue Verified Certificate</h3>
            <p className="text-xs text-slate-500 mb-4">Awards official completion credential to a qualifying trainee.</p>

            <form onSubmit={handleIssueCert} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Select Trainee</label>
                <select
                  required
                  value={selectedTraineeId}
                  onChange={e => setSelectedTraineeId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                >
                  <option value="">Select an accepted trainee...</option>
                  {acceptedTrainees.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Course</label>
                <select
                  required
                  value={selectedCertCourseId}
                  onChange={e => setSelectedCertCourseId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                >
                  {myCourses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Skill Acquired</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Java Microservices &amp; Spring Boot"
                  value={certSkillAcquired}
                  onChange={e => setCertSkillAcquired(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowIssueCertModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Award Credential
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: Upload Resource */}
      {showResourceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Upload Knowledge Resource</h3>
            <p className="text-xs text-slate-500 mb-4">Adds reference documentation or video to the Knowledge Hub.</p>

            <form onSubmit={handleUploadResource} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Resource Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed Database Architecture Whitepaper"
                  value={resTitle}
                  onChange={e => setResTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Brief summary of document..."
                  value={resDesc}
                  onChange={e => setResDesc(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    required
                    value={resCat}
                    onChange={e => setResCat(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">File Type</label>
                  <select
                    value={resType}
                    onChange={e => setResType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                  >
                    <option value="pdf">PDF Document</option>
                    <option value="doc">Word / Doc</option>
                    <option value="video">Video</option>
                    <option value="link">Web Resource</option>
                  </select>
                </div>
              </div>

              {/* Upload Source Mode Toggle */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">Upload Source</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setUploadMode('file')}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      uploadMode === 'file'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Upload from File Explorer
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadMode('url')}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      uploadMode === 'url'
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Web URL / Cloud Link
                  </button>
                </div>
              </div>

              {/* File Explorer Selection */}
              {uploadMode === 'file' ? (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Select File from Computer
                  </label>
                  <input
                    type="file"
                    id="trainer-file-explorer-input"
                    accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.mp4,.webm,.txt"
                    onChange={handleFilePick}
                    className="hidden"
                  />
                  <label
                    htmlFor="trainer-file-explorer-input"
                    className="cursor-pointer border-2 border-dashed border-blue-200 bg-blue-50/40 hover:bg-blue-50/80 rounded-xl p-4 flex flex-col items-center justify-center space-y-1.5 text-center transition-colors"
                  >
                    <Upload className="w-5 h-5 text-blue-600" />
                    <span className="text-xs font-bold text-slate-800">
                      {fileName ? fileName : 'Choose File from Explorer'}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {fileSizeStr ? `File Size: ${fileSizeStr}` : 'Supports PDF, Word, MP4 Video, Images, Text'}
                    </span>
                  </label>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Document / Resource URL</label>
                  <input
                    type="url"
                    required={uploadMode === 'url'}
                    placeholder="https://..."
                    value={resUrl}
                    onChange={e => setResUrl(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowResourceModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Upload &amp; Publish
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: Live Chat */}
      {activeChatRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="max-w-xl w-full">
            <div className="flex justify-end mb-2">
              <button
                onClick={() => setActiveChatRequest(null)}
                className="px-3 py-1 rounded bg-slate-800 text-white text-xs font-medium hover:bg-slate-700 cursor-pointer"
              >
                Close Chat ✕
              </button>
            </div>
            <RealTimeChat request={activeChatRequest} currentUser={currentUser} />
          </div>
        </div>
      )}

    </div>
  );
};
