import React from 'react';
import { Course, User } from '../types';
import { enrollInCourse } from '../services/storage';
import { BookOpen, User as UserIcon, Clock, CheckCircle2, ArrowRight } from 'lucide-react';

interface PublicCourseCatalogProps {
  courses: Course[];
  currentUser: User | null;
  onOpenAuth: () => void;
  onEnrollSuccess: () => void;
}

export const PublicCourseCatalog: React.FC<PublicCourseCatalogProps> = ({
  courses,
  currentUser,
  onOpenAuth,
  onEnrollSuccess
}) => {
  const publishedCourses = courses.filter(c => c.isPublished);

  const handleEnroll = (courseId: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const res = enrollInCourse(currentUser.id, courseId);
    if (res.success) {
      onEnrollSuccess();
    } else {
      alert(res.error || 'Enrollment error.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Enterprise Course Catalog</h1>
        <p className="text-xs text-slate-500 mt-1">
          Explore courses authored by certified trainers. Enrolling benchmarks your competencies for dynamic course skill-gap analysis.
        </p>
      </div>

      {publishedCourses.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700">No published courses available yet.</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Courses created and published by trainers will appear here automatically in real time.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {publishedCourses.map(course => (
            <div
              key={course.id}
              className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between hover:border-blue-300 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                    {course.difficulty}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{course.duration}</span>
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 leading-snug">{course.title}</h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">{course.description}</p>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-100">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center space-x-1">
                    <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                    <span>{course.trainerName}</span>
                  </span>
                  <span>{course.enrolledCount} enrolled</span>
                </div>

                <button
                  onClick={() => handleEnroll(course.id)}
                  className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
                >
                  <span>{currentUser ? 'Enroll in Course' : 'Sign In to Enroll'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
