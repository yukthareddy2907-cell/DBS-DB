import React from 'react';
import { 
  ArrowRight, 
  CheckCircle2, 
  Users, 
  GraduationCap, 
  Award, 
  FileText, 
  TrendingUp, 
  Repeat, 
  ShieldCheck, 
  Layers,
  Sparkles,
  BookOpen
} from 'lucide-react';

interface HomePageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onExplore: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onOpenAuth, onExplore }) => {
  return (
    <div className="bg-[#F8FAFC] text-[#0F172A] min-h-screen">
      
      {/* Hero Section */}
      <section className="relative pt-16 pb-20 md:pt-24 md:pb-28 border-b border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          
          {/* Subtle Tagline Badge */}
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-6">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Enterprise Capacity Building &amp; Competency Exchange</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 max-w-4xl mx-auto">
            CAPACITY CONNECT
          </h1>

          {/* Targeted Modification: Tagline replaced exactly as specified */}
          <p className="mt-4 text-xl sm:text-2xl font-medium text-slate-600 max-w-3xl mx-auto">
            Empowering People, Skills &amp; Organizational Growth
          </p>

          <p className="mt-4 text-sm sm:text-base text-slate-500 max-w-2xl mx-auto leading-relaxed">
            The next-generation digital capacity building portal for structured competency development, reciprocal skill exchange, trainer-trainee collaboration, assessments, and verifiable certifications.
          </p>

          {/* Call to Actions */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
            <button
              onClick={() => onOpenAuth('register')}
              className="w-full sm:w-auto px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>Create Your Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onExplore}
              className="w-full sm:w-auto px-6 py-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-sm border border-slate-300 transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>Explore Platform</span>
            </button>
          </div>

          {/* Trust Highlights */}
          <div className="mt-14 pt-10 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto text-left">
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Course-Specific Gaps</h4>
                <p className="text-[11px] text-slate-500">Evaluated against enrolled objectives</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Repeat className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Skill Exchange</h4>
                <p className="text-[11px] text-slate-500">Reciprocal trainer-trainee matching</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <GraduationCap className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">Secure Assessments</h4>
                <p className="text-[11px] text-slate-500">Trainer-authored MCQ evaluations</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Award className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-slate-900">PDF Certifications</h4>
                <p className="text-[11px] text-slate-500">Minimalist verifiable credentials</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Platform Modules */}
      <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
            A Complete Architecture for Modern Capacity Building
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Engineered with a minimal white and blue interface for clarity, performance, and enterprise security.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Course-Specific Skill-Gap Detection */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Dynamic Course Skill-Gap Analysis</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Assesses trainee competencies directly against the specific learning requirements of their enrolled course, accurately pinpointing areas that need focused mastery.
            </p>
          </div>

          {/* Card 2: Trainer Matching & Skill Exchange */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Repeat className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Reciprocal Skill Exchange</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Trainees connect with certified trainers through persistent exchange proposals (&quot;I want to learn X, I can teach Y&quot;) with synchronized real-time approval states.
            </p>
          </div>

          {/* Card 3: Secure Assessments */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Secure MCQ Assessments</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Assessments are accessible only to trainees whose skill exchange requests have been approved by the trainer. Correct answers are kept secure on the backend.
            </p>
          </div>

          {/* Card 4: Knowledge Hub */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Moderated Knowledge Hub</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Trainers upload public technical guides, whitepapers, and videos. Resources are verified by administrators and available to all enrolled participants.
            </p>
          </div>

          {/* Card 5: Verifiable Certifications */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Verifiable PDF Credentials</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Upon qualifying course completion, trainers issue cryptographic credentials that trainees can download as minimalist, high-resolution certificates.
            </p>
          </div>

          {/* Card 6: Master Admin Security */}
          <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Controlled Master Governance</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Led by Master Admin K. Gayathri Srivalli, Co-Admin access requires formal real-time approval, maintaining tamper-proof organizational oversight.
            </p>
          </div>

        </div>
      </section>

      {/* CTA Bottom Banner */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <h2 className="text-3xl font-bold tracking-tight">
            Ready to Accelerate Organizational Capacity?
          </h2>
          <p className="text-blue-100 text-sm max-w-xl mx-auto">
            Join CAPACITY CONNECT today. Create your account as a trainee, trainer, or dual-role participant to begin building measurable competencies.
          </p>
          <div>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-6 py-3 rounded-lg bg-white text-blue-700 hover:bg-blue-50 font-bold text-xs shadow-md transition-colors cursor-pointer"
            >
              Create Your Account Now
            </button>
          </div>
        </div>
      </section>

      {/* Minimal Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-800">CAPACITY CONNECT</span>
            <span>—</span>
            <span>Empowering People, Skills &amp; Organizational Growth</span>
          </div>
          <div>
            Master Administrator: <strong>K. Gayathri Srivalli</strong>
          </div>
        </div>
      </footer>
    </div>
  );
};
