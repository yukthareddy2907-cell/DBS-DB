import React, { useState } from 'react';
import { KnowledgeResource } from '../types';
import { FileText, ExternalLink, Search, Filter } from 'lucide-react';

interface PublicKnowledgeHubProps {
  resources: KnowledgeResource[];
}

export const PublicKnowledgeHub: React.FC<PublicKnowledgeHubProps> = ({ resources }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');

  const approved = resources.filter(r => r.status === 'approved');

  const categories = ['All', ...new Set(approved.map(r => r.category))];

  const filtered = approved.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCat === 'All' || r.category === selectedCat;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Knowledge Hub</h1>
        <p className="text-xs text-slate-500 mt-1">
          Peer-reviewed resources, guides, and technical reference documents uploaded by trainers.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search resources by title or topic..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 shadow-xs"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedCat}
            onChange={e => setSelectedCat(e.target.value)}
            className="px-3 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 shadow-xs"
          >
            {categories.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700">No resources available.</p>
          <p className="text-xs text-slate-400 mt-1">
            Documents uploaded by trainers and approved by administrators will appear here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(res => (
            <div
              key={res.id}
              className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3 flex flex-col justify-between hover:border-blue-300 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                    {res.fileType}
                  </span>
                  <span className="text-[11px] text-slate-400">{res.category}</span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 leading-snug">{res.title}</h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">{res.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-400">By: {res.trainerName}</span>
                <a
                  href={res.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1 text-xs font-semibold text-blue-600 hover:text-blue-800"
                >
                  <span>Open Resource</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
