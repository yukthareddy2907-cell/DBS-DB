import React, { useState, useEffect } from 'react';
import { 
  User, 
  Course, 
  Assessment, 
  Certificate, 
  KnowledgeResource, 
  CoAdminRequest,
  AssessmentSubmission
} from '../types';
import { 
  getAllUsers, 
  deleteUser,
  getCourses, 
  deleteCourse,
  getAssessments, 
  deleteAssessment,
  getAssessmentSubmissions,
  getCertificates, 
  deleteCertificate,
  getKnowledgeResources, 
  updateResourceStatus, 
  deleteKnowledgeResource,
  getCoAdminRequests, 
  handleCoAdminDecision,
  subscribeToRealtimeEvents,
  MASTER_ADMIN_NAME,
  MASTER_ADMIN_EMAIL
} from '../services/storage';
import { downloadCertificatePdf } from '../services/pdfGenerator';
import { 
  ShieldCheck, 
  Users, 
  BookOpen, 
  Award, 
  FileText, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Download,
  AlertTriangle,
  ExternalLink,
  Lock,
  Layers
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentUser }) => {
  // NOTE: 'Competency Standards' removed completely as specified
  const [activeTab, setActiveTab] = useState<
    'overview' | 'users' | 'coadmin-requests' | 'courses' | 'assessments' | 'knowledge' | 'certificates'
  >('overview');

  const [users, setUsers] = useState<User[]>([]);
  const [coAdminRequests, setCoAdminRequests] = useState<CoAdminRequest[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [submissions, setSubmissions] = useState<AssessmentSubmission[]>([]);
  const [resources, setResources] = useState<KnowledgeResource[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);

  const loadData = () => {
    setUsers(getAllUsers());
    setCoAdminRequests(getCoAdminRequests());
    setCourses(getCourses());
    setAssessments(getAssessments());
    setSubmissions(getAssessmentSubmissions());
    setResources(getKnowledgeResources());
    setCertificates(getCertificates());
  };

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToRealtimeEvents(() => {
      loadData();
    });
    return unsubscribe;
  }, []);

  // Co-Admin Decision Handler
  const handleCoAdmin = (requestId: string, decision: 'approved' | 'declined') => {
    handleCoAdminDecision(requestId, decision);
  };

  const isMaster = currentUser.isMasterAdmin || currentUser.email.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Top Banner */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
              Platform Administration
            </span>
            {isMaster ? (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 font-bold border border-amber-200">
                Master Administrator: {MASTER_ADMIN_NAME}
              </span>
            ) : (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-bold border border-indigo-200">
                Authorized Co-Administrator
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Governance &amp; Oversight Center
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Audit platform courses, moderate knowledge hub resources, review co-admin approvals, and manage verified credentials.
          </p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Navigation Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <div className="bg-white rounded-xl border border-slate-200 p-2 shadow-xs space-y-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Layers className="w-4 h-4" />
                <span>Executive Overview</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Users className="w-4 h-4" />
                <span>User Directory</span>
              </div>
              <span className="text-[10px] font-bold">{users.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('coadmin-requests')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'coadmin-requests'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Co-Admin Requests</span>
              </div>
              <span className="text-[10px] font-bold">
                {coAdminRequests.filter(r => r.status === 'pending').length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('courses')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'courses'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <BookOpen className="w-4 h-4" />
                <span>Course Oversight</span>
              </div>
              <span className="text-[10px] font-bold">{courses.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('assessments')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'assessments'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <FileText className="w-4 h-4" />
                <span>Assessments Log</span>
              </div>
              <span className="text-[10px] font-bold">{assessments.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('knowledge')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'knowledge'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <FileText className="w-4 h-4" />
                <span>Knowledge Moderation</span>
              </div>
              <span className="text-[10px] font-bold">{resources.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('certificates')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'certificates'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Award className="w-4 h-4" />
                <span>Issued Credentials</span>
              </div>
              <span className="text-[10px] font-bold">{certificates.length}</span>
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-3 space-y-6">

          {/* TAB 1: EXECUTIVE OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Total Users</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">{users.length}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Active Courses</p>
                  <p className="text-xl font-bold text-blue-600 mt-1">{courses.length}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Assessments</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">{assessments.length}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
                  <p className="text-[11px] font-medium text-slate-500">Issued Credentials</p>
                  <p className="text-xl font-bold text-emerald-600 mt-1">{certificates.length}</p>
                </div>
              </div>

              {/* Master Admin Security Card */}
              <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
                <div className="flex items-center space-x-2 text-blue-700">
                  <ShieldCheck className="w-5 h-5" />
                  <h3 className="text-xs font-bold text-slate-900">Master Governance Protocol</h3>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Platform administration is strictly controlled by Master Administrator <strong>{MASTER_ADMIN_NAME}</strong> ({MASTER_ADMIN_EMAIL}).
                  Co-Admin requests require formal real-time approval. Administrative PINs or secrets are never exposed in user responses.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: USER DIRECTORY */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">User Directory</h3>
                <p className="text-xs text-slate-500">All registered trainees, trainers, and administrators.</p>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                      <tr>
                        <th className="px-4 py-3">User</th>
                        <th className="px-4 py-3">Roles</th>
                        <th className="px-4 py-3">Admin Status</th>
                        <th className="px-4 py-3">Joined</th>
                        <th className="px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map(u => (
                        <tr key={u.id} className="hover:bg-slate-50/60">
                          <td className="px-4 py-3">
                            <p className="font-bold text-slate-900">{u.name}</p>
                            <p className="text-[11px] text-slate-500">{u.email}</p>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex space-x-1">
                              {u.hasTraineeRole && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700">Trainee</span>
                              )}
                              {u.hasTrainerRole && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-50 text-blue-700">Trainer</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            {u.isMasterAdmin ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700">
                                Master Admin
                              </span>
                            ) : u.isCoadmin ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
                                Co-Admin
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-400">Standard User</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-slate-500 text-[11px]">
                            {new Date(u.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {!u.isMasterAdmin && (
                              <button
                                onClick={() => deleteUser(u.id)}
                                className="text-slate-400 hover:text-rose-600 p-1"
                                title="Remove User"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CO-ADMIN REQUESTS (Real-time Approve / Decline) */}
          {activeTab === 'coadmin-requests' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Co-Admin Access Requests</h3>
                <p className="text-xs text-slate-500">
                  Users who have requested administrative privileges. Only Master Admin can approve.
                </p>
              </div>

              {coAdminRequests.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No co-admin requests on record.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {coAdminRequests.map(req => {
                    const isPending = req.status === 'pending';

                    return (
                      <div
                        key={req.id}
                        className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-slate-900">{req.userName}</span>
                            <span className="text-[11px] text-slate-500">({req.userEmail})</span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                req.status === 'approved'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : req.status === 'declined'
                                  ? 'bg-rose-50 text-rose-700'
                                  : 'bg-amber-50 text-amber-700'
                              }`}
                            >
                              {req.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600">
                            Reason: <span className="italic font-medium">&quot;{req.reason}&quot;</span>
                          </p>
                          <p className="text-[10px] text-slate-400">
                            Submitted: {new Date(req.createdAt).toLocaleString()}
                          </p>
                        </div>

                        {isPending && (
                          <div className="flex items-center space-x-2 shrink-0">
                            <button
                              onClick={() => handleCoAdmin(req.id, 'approved')}
                              className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Approve Co-Admin</span>
                            </button>
                            <button
                              onClick={() => handleCoAdmin(req.id, 'declined')}
                              className="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Decline</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: COURSE OVERSIGHT (View/Delete any course. NO Create Course, NO My Learning) */}
          {activeTab === 'courses' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Course Catalog Oversight</h3>
                <p className="text-xs text-slate-500">
                  Audit all published courses across trainers. Administrators can delete non-compliant courses.
                </p>
              </div>

              {courses.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No courses published yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {courses.map(course => (
                    <div
                      key={course.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                            {course.difficulty}
                          </span>
                          <h4 className="text-sm font-bold text-slate-900 mt-1.5">{course.title}</h4>
                          <p className="text-[11px] text-slate-500">Trainer: {course.trainerName}</p>
                        </div>
                        <button
                          onClick={() => deleteCourse(course.id)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Delete Course (Admin Oversight)"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">{course.description}</p>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span>Enrolled: {course.enrolledCount}</span>
                        <span>Duration: {course.duration}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: ASSESSMENTS LOG (View and Delete any assessment) */}
          {activeTab === 'assessments' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Assessments Audit Log</h3>
                <p className="text-xs text-slate-500">
                  View and delete assessments authored by any trainer, and inspect submission scores.
                </p>
              </div>

              {assessments.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No assessments created yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {assessments.map(ass => (
                      <div
                        key={ass.id}
                        className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                              {ass.targetCompetency}
                            </span>
                            <h4 className="text-xs font-bold text-slate-900 mt-1.5">{ass.title}</h4>
                            <p className="text-[11px] text-slate-500">
                              Trainer: {ass.trainerName} | Course: {ass.courseTitle}
                            </p>
                          </div>
                          <button
                            onClick={() => deleteAssessment(ass.id)}
                            className="text-slate-400 hover:text-rose-600 p-1"
                            title="Delete Assessment"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="text-xs text-slate-500 pt-1 border-t border-slate-100 flex justify-between">
                          <span>Pass: {ass.passingScore}%</span>
                          <span>{ass.questions.length} Questions</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Submissions Log */}
                  <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
                    <h4 className="text-xs font-bold text-slate-900">Global Trainee Submissions</h4>
                    {submissions.length === 0 ? (
                      <p className="text-xs text-slate-400 py-2">No trainee submissions logged yet.</p>
                    ) : (
                      <div className="divide-y divide-slate-100 text-xs">
                        {submissions.map(sub => (
                          <div key={sub.id} className="py-2.5 flex items-center justify-between">
                            <div>
                              <p className="font-bold text-slate-800">{sub.traineeName}</p>
                              <p className="text-[11px] text-slate-500">{sub.assessmentTitle}</p>
                            </div>
                            <span className={`font-bold ${sub.passed ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {sub.score} / {sub.totalMarks} ({sub.percentage}%) — {sub.passed ? 'PASSED' : 'FAILED'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: KNOWLEDGE MODERATION (Review, Approve, Delete resources) */}
          {activeTab === 'knowledge' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Knowledge Hub Moderation</h3>
                <p className="text-xs text-slate-500">
                  Review and moderate documents uploaded by trainers. Remove outdated or non-compliant materials.
                </p>
              </div>

              {resources.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No resources uploaded yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {resources.map(res => (
                    <div
                      key={res.id}
                      className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2.5"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                            {res.fileType}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1.5">{res.title}</h4>
                          <p className="text-[11px] text-slate-500">Uploaded by: {res.trainerName}</p>
                        </div>
                        <button
                          onClick={() => deleteKnowledgeResource(res.id)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Delete Resource"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">{res.description}</p>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span>Category: {res.category}</span>
                        <a
                          href={res.fileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 font-semibold hover:underline flex items-center space-x-1"
                        >
                          <span>Open File</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: ISSUED CREDENTIALS (View and Delete any certificate) */}
          {activeTab === 'certificates' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Issued Credentials Management</h3>
                <p className="text-xs text-slate-500">
                  Global registry of issued certificates. Administrators can view, download, or revoke credentials.
                </p>
              </div>

              {certificates.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No certificates issued yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {certificates.map(cert => (
                    <div
                      key={cert.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 uppercase">
                            {cert.status}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1.5">{cert.courseTitle}</h4>
                          <p className="text-[11px] text-slate-500">
                            Recipient: <strong>{cert.traineeName}</strong> | Trainer: <strong>{cert.trainerName}</strong>
                          </p>
                        </div>
                        <button
                          onClick={() => deleteCertificate(cert.id)}
                          className="text-slate-400 hover:text-rose-600 p-1"
                          title="Revoke / Delete Certificate"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="text-xs text-slate-500 space-y-0.5 pt-1 border-t border-slate-100">
                        <p>Skill: {cert.skillAcquired}</p>
                        <p>Date: {cert.issueDate}</p>
                        <p className="font-mono text-[10px] text-slate-400">ID: {cert.credentialId}</p>
                      </div>

                      <button
                        onClick={() => downloadCertificatePdf(cert)}
                        className="w-full py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 flex items-center justify-center space-x-1 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Verifiable PDF</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
