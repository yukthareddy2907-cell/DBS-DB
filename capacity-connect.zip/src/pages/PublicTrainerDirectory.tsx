import React from 'react';
import { TrainerProfile, User } from '../types';
import { Users, Send, CheckCircle2 } from 'lucide-react';

interface PublicTrainerDirectoryProps {
  trainers: TrainerProfile[];
  currentUser: User | null;
  onOpenAuth: () => void;
  onRequestExchange: (trainer: TrainerProfile) => void;
}

export const PublicTrainerDirectory: React.FC<PublicTrainerDirectoryProps> = ({
  trainers,
  currentUser,
  onOpenAuth,
  onRequestExchange
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Certified Trainers Directory</h1>
        <p className="text-xs text-slate-500 mt-1">
          When a user creates a trainer account, it is publicly visible here. Connect and send reciprocal skill exchange requests.
        </p>
      </div>

      {trainers.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200">
          <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700">No trainers registered yet.</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Create an account with the Trainer role to have your profile displayed here automatically.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {trainers.map(tr => (
            <div
              key={tr.userId}
              className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3.5 flex flex-col justify-between hover:border-blue-300 transition-colors"
            >
              <div className="space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm">
                      {tr.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 leading-snug">{tr.name}</h3>
                      <p className="text-xs text-blue-600 font-medium">{tr.expertise}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                    ★ {tr.rating.toFixed(1)}
                  </span>
                </div>

                <div className="space-y-1 text-xs text-slate-600">
                  <p><span className="font-semibold text-slate-700">Subjects / Topics:</span> {tr.subjects.join(', ')}</p>
                  <p><span className="font-semibold text-slate-700">Availability:</span> {tr.availability}</p>
                  <p><span className="font-semibold text-slate-700">Experience:</span> {tr.experienceYears} Years</p>
                </div>

                <div className="flex flex-wrap gap-1 pt-1">
                  {tr.skills.map((s, idx) => (
                    <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  onClick={() => {
                    if (!currentUser) {
                      onOpenAuth();
                    } else {
                      onRequestExchange(tr);
                    }
                  }}
                  className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 cursor-pointer transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{currentUser ? 'Send Skill Exchange Proposal' : 'Sign In to Request Exchange'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
