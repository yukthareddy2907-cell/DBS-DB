import React, { useState, useEffect } from 'react';
import { 
  User, 
  Course, 
  CourseEnrollment, 
  TrainerProfile, 
  SkillExchangeRequest, 
  Assessment, 
  Certificate,
  KnowledgeResource,
  TrainingSession
} from '../types';
import { 
  getTraineeEnrollments, 
  getCourses, 
  getTrainers, 
  getSkillExchangeRequests, 
  sendSkillExchangeRequest,
  getEligibleAssessmentsForTrainee,
  getAssessmentSubmissions,
  submitAssessmentSecure,
  getCertificates,
  getTraineeCompetencies,
  updateCourseProgress,
  getKnowledgeResources,
  getTrainingSessions,
  subscribeToRealtimeEvents
} from '../services/storage';
import { downloadCertificatePdf } from '../services/pdfGenerator';
import { RealTimeChat } from '../components/RealTimeChat';
import { ScheduleCalendar } from '../components/ScheduleCalendar';
import { 
  BookOpen, 
  Users, 
  Award, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  Send, 
  MessageSquare, 
  Download, 
  TrendingUp, 
  ExternalLink, 
  ShieldCheck, 
  FileText,
  AlertCircle,
  PlayCircle,
  CheckCheck
} from 'lucide-react';

interface TraineeDashboardProps {
  currentUser: User;
}

export const TraineeDashboard: React.FC<TraineeDashboardProps> = ({ currentUser }) => {
  // Navigation tabs: ONLY valid trainee sections
  // NOTE: AI Learning Assistant removed, Real-Time Sync box removed
  const [activeTab, setActiveTab] = useState<
    'my-learning' | 'skill-gap' | 'trainers' | 'requests' | 'assessments' | 'certificates' | 'knowledge' | 'schedule'
  >('my-learning');

  const [enrollments, setEnrollments] = useState<CourseEnrollment[]>([]);
  const [allCourses, setAllCourses] = useState<Course[]>([]);
  const [trainers, setTrainers] = useState<TrainerProfile[]>([]);
  const [requests, setRequests] = useState<SkillExchangeRequest[]>([]);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [resources, setResources] = useState<KnowledgeResource[]>([]);
  const [sessions, setSessions] = useState<TrainingSession[]>([]);

  // Skill Exchange Request Modal
  const [selectedTrainer, setSelectedTrainer] = useState<TrainerProfile | null>(null);
  const [learnSkill, setLearnSkill] = useState('');
  const [teachSkill, setTeachSkill] = useState('');
  const [reqNotes, setReqNotes] = useState('');
  const [selectedCourseId, setSelectedCourseId] = useState('');
  const [reqSuccess, setReqSuccess] = useState(false);

  // Active Assessment Taking State
  const [activeAssessment, setActiveAssessment] = useState<Assessment | null>(null);
  const [assessmentAnswers, setAssessmentAnswers] = useState<Record<string, number>>({});
  const [assessmentResult, setAssessmentResult] = useState<any>(null);

  // Active Chat State
  const [activeChatRequest, setActiveChatRequest] = useState<SkillExchangeRequest | null>(null);

  const loadData = () => {
    const enrs = getTraineeEnrollments(currentUser.id);
    const crss = getCourses();
    const trns = getTrainers();
    const reqs = getSkillExchangeRequests().filter(r => 
      r.traineeId === currentUser.id || 
      (r.traineeEmail && r.traineeEmail.toLowerCase() === currentUser.email.toLowerCase())
    );
    const eligibleAss = getEligibleAssessmentsForTrainee(currentUser.id);
    const certs = getCertificates().filter(c => c.traineeId === currentUser.id);
    const res = getKnowledgeResources().filter(r => r.status === 'approved');
    const sess = getTrainingSessions().filter(s => s.traineeId === currentUser.id);

    setEnrollments(enrs);
    setAllCourses(crss);
    setTrainers(trns);
    setRequests(reqs);
    setAssessments(eligibleAss);
    setCertificates(certs);
    setResources(res);
    setSessions(sess);
  };

  useEffect(() => {
    loadData();
    const unsubscribe = subscribeToRealtimeEvents(() => {
      loadData();
    });
    return unsubscribe;
  }, [currentUser.id]);

  const handleSendRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrainer || !learnSkill.trim() || !teachSkill.trim()) return;

    const course = allCourses.find(c => c.id === selectedCourseId);

    sendSkillExchangeRequest({
      traineeId: currentUser.id,
      traineeName: currentUser.name,
      traineeEmail: currentUser.email,
      trainerId: selectedTrainer.userId,
      trainerName: selectedTrainer.name,
      trainerEmail: selectedTrainer.email,
      courseId: course?.id,
      courseTitle: course?.title,
      learnSkill: learnSkill.trim(),
      teachSkill: teachSkill.trim(),
      notes: reqNotes.trim()
    });

    loadData();
    setReqSuccess(true);
    setTimeout(() => {
      setReqSuccess(false);
      setSelectedTrainer(null);
      setLearnSkill('');
      setTeachSkill('');
      setReqNotes('');
    }, 2000);
  };

  const handleAssessmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAssessment) return;

    const res = submitAssessmentSecure({
      assessmentId: activeAssessment.id,
      traineeId: currentUser.id,
      traineeName: currentUser.name,
      submittedAnswers: assessmentAnswers
    });

    if (res.success && res.submission) {
      setAssessmentResult(res.submission);
    }
  };

  // Connected trainers for scheduling
  const connectedTrainers = requests
    .filter(r => r.status === 'accepted')
    .map(r => ({ id: r.trainerId, name: r.trainerName }));

  // Dynamic Course-Specific Skill Gap Analysis
  // Benchmarks trainee's competency directly against the enrolled course's required skills
  const traineeCompetencies = getTraineeCompetencies(currentUser.id);
  const traineeCompMap = new Map(traineeCompetencies.map(c => [c.skillName.toLowerCase(), c.currentLevel]));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Top Banner / Welcome */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
            Trainee Portal
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
            Welcome back, {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track enrolled courses, request reciprocal skill exchange, and complete verified assessments.
          </p>
        </div>

        {/* Quick Stats Pill */}
        <div className="flex items-center space-x-3 text-xs">
          <div className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 shadow-xs">
            <span className="text-slate-500">Enrolled: </span>
            <span className="font-bold text-slate-900">{enrollments.length}</span>
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 shadow-xs">
            <span className="text-slate-500">Certificates: </span>
            <span className="font-bold text-blue-600">{certificates.length}</span>
          </div>
        </div>
      </div>

      {/* Main Trainee Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Sidebar Navigation */}
        {/* NOTE: 'Real-Time Sync' box removed completely from sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <div className="bg-white rounded-xl border border-slate-200 p-2 shadow-xs space-y-1">
            <button
              onClick={() => setActiveTab('my-learning')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'my-learning'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <BookOpen className="w-4 h-4" />
                <span>My Learning</span>
              </div>
              <span className="text-[10px] font-bold">{enrollments.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('skill-gap')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'skill-gap'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <TrendingUp className="w-4 h-4" />
                <span>Course Skill Gaps</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('trainers')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'trainers'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Users className="w-4 h-4" />
                <span>Trainer Matching</span>
              </div>
              <span className="text-[10px] font-bold">{trainers.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('requests')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'requests'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Clock className="w-4 h-4" />
                <span>Skill Requests</span>
              </div>
              <span className="text-[10px] font-bold">{requests.length}</span>
            </button>

            {/* Renamed from Secure Assessments to Assessments as requested */}
            <button
              onClick={() => setActiveTab('assessments')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'assessments'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Assessments</span>
              </div>
              <span className="text-[10px] font-bold">{assessments.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('certificates')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'certificates'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Award className="w-4 h-4" />
                <span>Certifications</span>
              </div>
              <span className="text-[10px] font-bold">{certificates.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('schedule')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'schedule'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <Calendar className="w-4 h-4" />
                <span>Schedule</span>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('knowledge')}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                activeTab === 'knowledge'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center space-x-2.5">
                <FileText className="w-4 h-4" />
                <span>Knowledge Hub</span>
              </div>
              <span className="text-[10px] font-bold">{resources.length}</span>
            </button>
          </div>
        </div>

        {/* Right Main Content Panel */}
        <div className="lg:col-span-3 space-y-6">

          {/* TAB 1: MY LEARNING (Only My Learning, NO Create Course) */}
          {activeTab === 'my-learning' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Enrolled Courses</h3>
                  <p className="text-xs text-slate-500">Your registered learning paths and progress</p>
                </div>
              </div>

              {enrollments.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No courses enrolled yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Browse the public Course Catalog from the top navigation to enroll in structured capacity building courses.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {enrollments.map(enr => {
                    const courseDetails = allCourses.find(c => c.id === enr.courseId);
                    return (
                      <div
                        key={enr.id}
                        className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                              {enr.status}
                            </span>
                            <h4 className="text-sm font-bold text-slate-900 mt-2">{enr.courseTitle}</h4>
                          </div>
                          <span className="text-xs font-bold text-slate-800">{enr.progressPercent}%</span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${enr.progressPercent}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
                          <span>Trainer: {courseDetails?.trainerName || 'Lead Trainer'}</span>
                          <button
                            onClick={() => {
                              const nextProgress = Math.min(100, enr.progressPercent + 25);
                              updateCourseProgress(currentUser.id, enr.courseId, nextProgress);
                            }}
                            className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-1 cursor-pointer"
                          >
                            <span>{enr.progressPercent >= 100 ? 'Review Course' : 'Continue Learning'}</span>
                            <PlayCircle className="w-3.5 h-3.5 ml-1" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: COURSE-SPECIFIC SKILL GAP DETECTION */}
          {activeTab === 'skill-gap' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Dynamic Course-Specific Skill-Gap Detection</h3>
                <p className="text-xs text-slate-500">
                  Benchmarks your competencies specifically against the required outcomes of your enrolled courses.
                </p>
              </div>

              {enrollments.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <TrendingUp className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No active course enrollments.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Enroll in a course to dynamically compute your skill gaps based on that specific course&apos;s curriculum.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {enrollments.map(enr => {
                    const course = allCourses.find(c => c.id === enr.courseId);
                    if (!course) return null;

                    const requiredSkills = course.requiredSkills || [];

                    return (
                      <div key={enr.id} className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-4">
                        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                          <div>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                              Enrolled Course Curriculum
                            </span>
                            <h4 className="text-sm font-bold text-slate-900 mt-1">{course.title}</h4>
                            <p className="text-[11px] text-slate-500 mt-0.5">Instructor: {course.trainerName}</p>
                          </div>
                        </div>

                        {/* Dynamic Course Requirements vs Trainee Competency Breakdown */}
                        <div className="space-y-3">
                          {requiredSkills.length === 0 ? (
                            <p className="text-xs text-slate-400 py-2">No individual skill outcomes specified for this course yet.</p>
                          ) : (
                            requiredSkills.map((req, idx) => {
                              const currentLevel = traineeCompMap.get(req.skill.toLowerCase()) || 1;
                              const gap = Math.max(0, req.requiredLevel - currentLevel);
                              const priority = gap >= 2 ? 'High Priority' : gap === 1 ? 'Medium Priority' : 'Proficient';

                              return (
                                <div key={idx} className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                                  <div>
                                    <div className="flex items-center space-x-2">
                                      <span className="text-xs font-bold text-slate-800">{req.skill}</span>
                                      <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                                        gap === 0 
                                          ? 'bg-emerald-50 text-emerald-700' 
                                          : gap >= 2 
                                          ? 'bg-rose-50 text-rose-700' 
                                          : 'bg-amber-50 text-amber-700'
                                      }`}>
                                        {priority}
                                      </span>
                                    </div>
                                    <p className="text-[11px] text-slate-500 mt-0.5">
                                      {gap === 0 
                                        ? 'Target competency achieved for this module.' 
                                        : `Requires ${gap} additional level${gap > 1 ? 's' : ''} to reach target competency for this course.`}
                                    </p>
                                  </div>

                                  <div className="flex items-center space-x-3 text-xs">
                                    <div className="text-right">
                                      <span className="text-[10px] text-slate-400 block">Current / Target</span>
                                      <span className="font-bold text-slate-800">Lvl {currentLevel} / Lvl {req.requiredLevel}</span>
                                    </div>
                                    <div className="w-16 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                                      <div
                                        className={`h-1.5 rounded-full ${gap === 0 ? 'bg-emerald-500' : 'bg-blue-600'}`}
                                        style={{ width: `${Math.min(100, (currentLevel / req.requiredLevel) * 100)}%` }}
                                      />
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TRAINER MATCHING & PUBLIC TRAINER DIRECTORY */}
          {activeTab === 'trainers' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Certified Trainers &amp; Mentors</h3>
                <p className="text-xs text-slate-500">
                  Publicly visible trainers. Send a Skill Exchange request to propose reciprocal learning.
                </p>
              </div>

              {trainers.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No trainers registered yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    When users register with a Trainer role, their profiles immediately appear here publicly.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trainers.map(tr => (
                    <div
                      key={tr.userId}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-sm">
                            {tr.name.charAt(0)}
                          </div>
                          <div>
                            <h4 className="text-xs font-bold text-slate-900">{tr.name}</h4>
                            <p className="text-[11px] text-blue-600 font-medium">{tr.expertise}</p>
                          </div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold">
                          ★ {tr.rating.toFixed(1)}
                        </span>
                      </div>

                      <div className="space-y-1.5 text-xs text-slate-600">
                        <p><span className="font-semibold text-slate-700">Subjects / Topics:</span> {tr.subjects.join(', ')}</p>
                        <p><span className="font-semibold text-slate-700">Availability:</span> {tr.availability}</p>
                        <p><span className="font-semibold text-slate-700">Experience:</span> {tr.experienceYears} Years</p>
                      </div>

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {tr.skills.slice(0, 3).map((s, i) => (
                            <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                              {s}
                            </span>
                          ))}
                        </div>

                        <button
                          onClick={() => {
                            setSelectedTrainer(tr);
                            setLearnSkill(tr.expertise || tr.skills[0] || 'Technical Mentorship');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
                        >
                          <Send className="w-3 h-3" />
                          <span>Request Exchange</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ACTIVE SKILL REQUESTS (Real-Time State: Pending, Accepted, Declined) */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Skill Exchange Requests</h3>
                <p className="text-xs text-slate-500">
                  Real-time status synchronization between you and your requested trainers.
                </p>
              </div>

              {requests.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No requests sent yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Browse the Trainer Matching tab to send a reciprocal skill exchange request.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {requests.map(req => {
                    const isAccepted = req.status === 'accepted';
                    const isDeclined = req.status === 'declined';
                    const isPending = req.status === 'pending';

                    return (
                      <div
                        key={req.id}
                        className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-slate-900">Trainer: {req.trainerName}</span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                isAccepted
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : isDeclined
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}
                            >
                              {isAccepted ? 'Request Accepted' : isDeclined ? 'Request Declined' : 'Request Sent — Pending'}
                            </span>
                          </div>

                          <p className="text-xs text-slate-600">
                            I want to learn: <strong className="text-blue-600">{req.learnSkill}</strong> | I can teach: <strong className="text-slate-800">{req.teachSkill}</strong>
                          </p>
                          {req.notes && (
                            <p className="text-[11px] text-slate-500 italic">&quot;{req.notes}&quot;</p>
                          )}
                        </div>

                        {/* Actions upon Acceptance */}
                        {isAccepted && (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => setActiveChatRequest(req)}
                              className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Live Chat</span>
                            </button>
                            <button
                              onClick={() => setActiveTab('assessments')}
                              className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                            >
                              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                              <span>View Assessments</span>
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: ASSESSMENTS (ONLY from approved trainers) */}
          {activeTab === 'assessments' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Course &amp; Skill Assessments</h3>
                <p className="text-xs text-slate-500">
                  Assessments are accessible exclusively from trainers who have accepted your skill exchange request.
                </p>
              </div>

              {assessments.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No assessments available yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    You can take assessments once your skill exchange request is accepted by a trainer and the trainer publishes MCQs for the course.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {assessments.map(ass => (
                    <div
                      key={ass.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                            {ass.targetCompetency}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-2">{ass.title}</h4>
                        </div>
                        <span className="text-xs text-slate-500 flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{ass.durationMinutes}m</span>
                        </span>
                      </div>

                      <div className="text-xs text-slate-600 space-y-1">
                        <p>Trainer: <strong>{ass.trainerName}</strong></p>
                        <p>Passing Threshold: <strong>{ass.passingScore}%</strong></p>
                        <p>Total Questions: <strong>{ass.questions.length} MCQs</strong></p>
                      </div>

                      <button
                        onClick={() => {
                          setActiveAssessment(ass);
                          setAssessmentAnswers({});
                          setAssessmentResult(null);
                        }}
                        className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center space-x-1 cursor-pointer"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Start Assessment</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: MY CERTIFICATIONS (Issued & Pending, Minimalist PDF Download) */}
          {activeTab === 'certificates' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Verified Certifications</h3>
                <p className="text-xs text-slate-500">
                  Credentials awarded by your trainers upon qualifying course &amp; assessment completion.
                </p>
              </div>

              {certificates.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <Award className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No certificates issued yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                    Certificates appear here as soon as your trainer marks your course work as completed and issues your credential.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {certificates.map(cert => (
                    <div
                      key={cert.id}
                      className="p-5 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 uppercase">
                            {cert.status}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-2">{cert.courseTitle}</h4>
                          <p className="text-[11px] text-slate-500">Skill: {cert.skillAcquired}</p>
                        </div>
                        <Award className="w-5 h-5 text-blue-600" />
                      </div>

                      <div className="text-[11px] text-slate-600 space-y-0.5 pt-1 border-t border-slate-100">
                        <p>Issued by: <strong>{cert.trainerName}</strong></p>
                        <p>Issue Date: <strong>{cert.issueDate}</strong></p>
                        <p className="font-mono text-[10px] text-slate-400">ID: {cert.credentialId}</p>
                      </div>

                      <button
                        onClick={() => downloadCertificatePdf(cert)}
                        className="w-full py-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 text-xs font-semibold flex items-center justify-center space-x-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Certificate (PDF)</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 7: SCHEDULE */}
          {activeTab === 'schedule' && (
            <ScheduleCalendar
              sessions={sessions}
              currentUser={currentUser}
              connectedUsers={connectedTrainers}
            />
          )}

          {/* TAB 8: KNOWLEDGE HUB */}
          {activeTab === 'knowledge' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Knowledge Hub Resources</h3>
                <p className="text-xs text-slate-500">
                  Trainer-uploaded, verified public documents, guides, and technical references.
                </p>
              </div>

              {resources.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">No resources available yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Resources uploaded by trainers and approved by administrators will appear here.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {resources.map(res => (
                    <div
                      key={res.id}
                      className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2.5"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                            {res.fileType}
                          </span>
                          <h4 className="text-xs font-bold text-slate-900 mt-1.5">{res.title}</h4>
                        </div>
                        <FileText className="w-4 h-4 text-slate-400" />
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2">{res.description}</p>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-slate-500">
                        <span>Category: {res.category}</span>
                        <a
                          href={res.fileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-semibold text-blue-600 hover:text-blue-800 flex items-center space-x-1"
                        >
                          <span>Open Resource</span>
                          <ExternalLink className="w-3 h-3 ml-0.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* MODAL 1: Skill Exchange Request */}
      {selectedTrainer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95">
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              Send Skill Exchange Request
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              To Trainer: <strong>{selectedTrainer.name}</strong> ({selectedTrainer.expertise})
            </p>

            {reqSuccess ? (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h4 className="text-xs font-bold text-slate-900">Request Sent — Pending</h4>
                <p className="text-[11px] text-slate-500">
                  Trainer {selectedTrainer.name} received your request in real time.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSendRequest} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    I want to learn (Required Skill)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Java Microservices or Python Basics"
                    value={learnSkill}
                    onChange={e => setLearnSkill(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    I can teach in return (Your Skill Offer)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dance, UI Design, or Mathematics"
                    value={teachSkill}
                    onChange={e => setTeachSkill(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                {allCourses.length > 0 && (
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Related Course (Optional)
                    </label>
                    <select
                      value={selectedCourseId}
                      onChange={e => setSelectedCourseId(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                    >
                      <option value="">Select a course (optional)...</option>
                      {allCourses.map(c => (
                        <option key={c.id} value={c.id}>{c.title}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Message / Goal Notes
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Briefly state your learning targets..."
                    value={reqNotes}
                    onChange={e => setReqNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedTrainer(null)}
                    className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                  >
                    Send Exchange Proposal
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* MODAL 2: Secure Assessment Taking */}
      {activeAssessment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 max-h-[85vh] overflow-y-auto animate-in fade-in zoom-in-95">
            
            {!assessmentResult ? (
              <form onSubmit={handleAssessmentSubmit} className="space-y-6">
                <div className="border-b border-slate-200 pb-3 flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                      Official Assessment
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-1">{activeAssessment.title}</h3>
                    <p className="text-xs text-slate-500">Instructor: {activeAssessment.trainerName} | Passing: {activeAssessment.passingScore}%</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveAssessment(null)}
                    className="text-xs text-slate-400 hover:text-slate-600"
                  >
                    Cancel
                  </button>
                </div>

                <div className="space-y-5">
                  {activeAssessment.questions.map((q, idx) => (
                    <div key={q.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                      <p className="text-xs font-bold text-slate-900">
                        {idx + 1}. {q.question}
                      </p>

                      <div className="space-y-2">
                        {q.options.map((opt, optIdx) => (
                          <label
                            key={optIdx}
                            className={`flex items-center space-x-2.5 p-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                              assessmentAnswers[q.id] === optIdx
                                ? 'bg-blue-50/70 border-blue-600 text-blue-900 font-medium'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100/60'
                            }`}
                          >
                            <input
                              type="radio"
                              name={`q_${q.id}`}
                              checked={assessmentAnswers[q.id] === optIdx}
                              onChange={() => setAssessmentAnswers(prev => ({ ...prev, [q.id]: optIdx }))}
                              className="text-blue-600"
                            />
                            <span>{opt}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                  <span className="text-xs text-slate-500">
                    {Object.keys(assessmentAnswers).length} of {activeAssessment.questions.length} answered
                  </span>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                  >
                    Submit for Evaluation
                  </button>
                </div>
              </form>
            ) : (
              <div className="py-6 text-center space-y-4">
                <div className={`w-14 h-14 rounded-full flex items-center justify-center mx-auto ${
                  assessmentResult.passed ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                }`}>
                  {assessmentResult.passed ? <CheckCheck className="w-8 h-8" /> : <AlertCircle className="w-8 h-8" />}
                </div>

                <h3 className="text-base font-bold text-slate-900">
                  {assessmentResult.passed ? 'Assessment Passed Successfully!' : 'Assessment Needs Improvement'}
                </h3>

                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  You scored <strong>{assessmentResult.score} / {assessmentResult.totalMarks}</strong> ({assessmentResult.percentage}%).
                  Passing threshold is {activeAssessment.passingScore}%.
                </p>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveAssessment(null);
                      setAssessmentResult(null);
                    }}
                    className="px-5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                  >
                    Close Results
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* MODAL 3: Real-Time Chat Drawer */}
      {activeChatRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="max-w-xl w-full">
            <div className="flex justify-end mb-2">
              <button
                onClick={() => setActiveChatRequest(null)}
                className="px-3 py-1 rounded bg-slate-800 text-white text-xs font-medium hover:bg-slate-700"
              >
                Close Chat ✕
              </button>
            </div>
            <RealTimeChat request={activeChatRequest} currentUser={currentUser} />
          </div>
        </div>
      )}

    </div>
  );
};
