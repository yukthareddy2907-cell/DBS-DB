import React from 'react';
import { Notification } from '../types';
import { markNotificationAsRead, markAllNotificationsAsRead } from '../services/storage';
import { Bell, CheckCheck, Clock, Award, CheckCircle2, XCircle, ShieldAlert } from 'lucide-react';

interface NotificationDropdownProps {
  notifications: Notification[];
  userId: string;
  onClose: () => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  notifications,
  userId,
  onClose
}) => {
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'request_accepted':
      case 'coadmin_approved':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'request_declined':
        return <XCircle className="w-4 h-4 text-rose-600" />;
      case 'cert_issued':
        return <Award className="w-4 h-4 text-blue-600" />;
      case 'coadmin_request':
        return <ShieldAlert className="w-4 h-4 text-amber-600" />;
      default:
        return <Bell className="w-4 h-4 text-blue-600" />;
    }
  };

  const formatTime = (iso: string) => {
    try {
      const diff = Date.now() - new Date(iso).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / 60);
      if (hours < 24) return `${hours}h ago`;
      return new Date(iso).toLocaleDateString();
    } catch {
      return '';
    }
  };

  return (
    <div className="absolute right-0 mt-2 w-84 sm:w-96 bg-white rounded-lg shadow-xl border border-slate-200 z-50 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
        <div className="flex items-center space-x-2">
          <Bell className="w-4 h-4 text-slate-700" />
          <span className="text-sm font-semibold text-slate-900">Notifications</span>
          {unreadCount > 0 && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">
              {unreadCount} new
            </span>
          )}
        </div>
        {unreadCount > 0 && (
          <button
            onClick={() => markAllNotificationsAsRead(userId)}
            className="text-xs text-blue-600 hover:text-blue-800 font-medium flex items-center space-x-1"
          >
            <CheckCheck className="w-3.5 h-3.5 mr-1" />
            Mark all read
          </button>
        )}
      </div>

      {/* Notifications List */}
      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
        {notifications.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-sm">
            No notifications yet.
          </div>
        ) : (
          notifications.map(n => (
            <div
              key={n.id}
              onClick={() => markNotificationAsRead(n.id)}
              className={`p-3.5 transition-colors cursor-pointer hover:bg-slate-50 flex items-start space-x-3 ${
                !n.isRead ? 'bg-blue-50/40' : ''
              }`}
            >
              <div className="mt-0.5 p-1.5 rounded-md bg-white border border-slate-200 shadow-xs">
                {getIcon(n.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className={`text-xs font-semibold ${!n.isRead ? 'text-slate-900' : 'text-slate-700'}`}>
                    {n.title}
                  </p>
                  <span className="text-[10px] text-slate-400 flex items-center">
                    <Clock className="w-3 h-3 mr-0.5" />
                    {formatTime(n.createdAt)}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">
                  {n.message}
                </p>
              </div>
              {!n.isRead && (
                <span className="w-2 h-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
