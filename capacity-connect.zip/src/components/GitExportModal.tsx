import React, { useState } from 'react';
import { generateGitPackageZip } from '../services/gitExport';
import { Download, FolderTree, Database, Server, Layout, CheckCircle, FileCode, ShieldCheck, X } from 'lucide-react';

interface GitExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitExportModal: React.FC<GitExportModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setDownloading(true);
      await generateGitPackageZip();
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 5000);
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-600">
              <FolderTree className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Git Repository Export Package</h3>
              <p className="text-xs text-slate-500">Separated 3-Tier Architecture ready to push to Git / GitHub</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content & Folders */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="p-3.5 bg-blue-50/60 rounded-lg border border-blue-100 text-xs text-blue-900 flex items-start space-x-2.5">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p>
              Contains <strong>only the necessary clean files</strong> across the 3 requested tiers (Frontend, Backend, and Database) with full CO1–CO6 comments and zero unnecessary bloat.
            </p>
          </div>

          {/* 3 Folders Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            
            {/* Folder 1: Frontend */}
            <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <div className="flex items-center space-x-2 mb-2">
                <Layout className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold text-slate-900 font-mono">/frontend</h4>
              </div>
              <p className="text-[11px] text-slate-600 mb-2.5">Minimal White + Blue Enterprise UI</p>
              <ul className="text-[10px] space-y-1 text-slate-500 font-mono">
                <li>• src/ (React + TS + Tailwind)</li>
                <li>• index.html</li>
                <li>• package.json & vite config</li>
                <li>• Realtime EventBus & SSE</li>
              </ul>
            </div>

            {/* Folder 2: Backend */}
            <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <div className="flex items-center space-x-2 mb-2">
                <Server className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold text-slate-900 font-mono">/backend</h4>
              </div>
              <p className="text-[11px] text-slate-600 mb-2.5">Multi-language Microservices</p>
              <ul className="text-[10px] space-y-1 text-slate-500 font-mono">
                <li>• spring-boot/ (Java CO4, CO5)</li>
                <li>• fastapi/ (Python CO3)</li>
                <li>• nodejs-gateway/ (CO4)</li>
                <li>• docker-compose.yml (CO6)</li>
              </ul>
            </div>

            {/* Folder 3: Database */}
            <div className="p-4 rounded-lg border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <div className="flex items-center space-x-2 mb-2">
                <Database className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs font-bold text-slate-900 font-mono">/database</h4>
              </div>
              <p className="text-[11px] text-slate-600 mb-2.5">MySQL Workbench & NoSQL</p>
              <ul className="text-[10px] space-y-1 text-slate-500 font-mono">
                <li>• schema.sql (MySQL DDL CO1)</li>
                <li>• mongodb_schema.js (Chat CO2)</li>
                <li>• vector_search.sql (pgvector)</li>
                <li>• CTEs & Window Functions</li>
              </ul>
            </div>
          </div>

          {/* Quick Git Push Terminal Command */}
          <div className="p-3 bg-slate-900 rounded-lg text-slate-200 font-mono text-[11px]">
            <div className="text-slate-400 mb-1 flex items-center justify-between">
              <span>Push to Git Terminal Command:</span>
              <FileCode className="w-3.5 h-3.5 text-slate-400" />
            </div>
            <code>
              git init && git add . && git commit -m &quot;feat: capacity connect final draft&quot;
            </code>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
          >
            Close
          </button>
          
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="px-5 py-2.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex items-center space-x-2 disabled:opacity-50 transition-all cursor-pointer"
          >
            {downloading ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Generating Zip Archive...</span>
              </>
            ) : downloaded ? (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-200" />
                <span>Downloaded Successfully!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download Git Repository Package (.ZIP)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
