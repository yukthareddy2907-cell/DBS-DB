import React, { useState } from 'react';
import { TrainingSession, User } from '../types';
import { createTrainingSession } from '../services/storage';
import { Calendar as CalendarIcon, Clock, Plus, Video, CheckCircle2, User as UserIcon } from 'lucide-react';

interface ScheduleCalendarProps {
  sessions: TrainingSession[];
  currentUser: User;
  connectedUsers: { id: string; name: string }[];
}

export const ScheduleCalendar: React.FC<ScheduleCalendarProps> = ({
  sessions,
  currentUser,
  connectedUsers
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [selectedPartnerId, setSelectedPartnerId] = useState(connectedUsers[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('14:00');
  const [duration, setDuration] = useState(60);
  const [link, setLink] = useState('');

  const isTrainer = currentUser.activeRole === 'trainer';

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !selectedPartnerId) return;

    const partner = connectedUsers.find(u => u.id === selectedPartnerId);
    if (!partner) return;

    createTrainingSession({
      trainerId: isTrainer ? currentUser.id : partner.id,
      trainerName: isTrainer ? currentUser.name : partner.name,
      traineeId: isTrainer ? partner.id : currentUser.id,
      traineeName: isTrainer ? partner.name : currentUser.name,
      title: title.trim(),
      sessionDate: date,
      startTime: time,
      durationMinutes: Number(duration),
      meetingLink: link.trim() || 'https://meet.google.com/capacity-session'
    });

    setShowAddModal(false);
    setTitle('');
  };

  const mySessions = sessions.filter(
    s => s.trainerId === currentUser.id || s.traineeId === currentUser.id
  ).sort((a, b) => new Date(`${a.sessionDate}T${a.startTime}`).getTime() - new Date(`${b.sessionDate}T${b.startTime}`).getTime());

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Interactive Training Schedule</h3>
          <p className="text-xs text-slate-500">Live calendar with real-time participant synchronization</p>
        </div>

        {connectedUsers.length > 0 && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Session</span>
          </button>
        )}
      </div>

      {/* Sessions Grid */}
      {mySessions.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-xl border border-slate-200">
          <CalendarIcon className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-600">No scheduled sessions yet.</p>
          <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
            {connectedUsers.length > 0 
              ? 'Click "Schedule Session" above to set up a live training sync.'
              : 'Connect with a trainer or trainee through Skill Exchange to unlock live scheduling.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {mySessions.map(s => {
            const isMyTrainer = s.trainerId === currentUser.id;
            return (
              <div
                key={s.id}
                className="p-4 rounded-xl border border-slate-200 bg-white hover:border-blue-200 transition-colors shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 uppercase">
                      {s.status}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 mt-1.5">{s.title}</h4>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold text-slate-800">{s.sessionDate}</span>
                    <p className="text-[10px] text-slate-500 flex items-center justify-end space-x-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{s.startTime} ({s.durationMinutes}m)</span>
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-600 flex items-center space-x-2 pt-1 border-t border-slate-100">
                  <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {isMyTrainer ? `Trainee: ${s.traineeName}` : `Trainer: ${s.trainerName}`}
                  </span>
                </div>

                {s.meetingLink && (
                  <a
                    href={s.meetingLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1 text-xs text-blue-600 hover:text-blue-800 font-medium"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>Join Video Meeting</span>
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add Session Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95">
            <h4 className="text-sm font-bold text-slate-900 mb-3">Schedule Training Session</h4>
            
            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Session Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hands-on Code Review & Architecture Sync"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Participant ({isTrainer ? 'Trainee' : 'Trainer'})
                </label>
                <select
                  value={selectedPartnerId}
                  onChange={e => setSelectedPartnerId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 bg-white"
                >
                  {connectedUsers.map(u => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Start Time</label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Duration (minutes)</label>
                <input
                  type="number"
                  min={15}
                  max={180}
                  step={15}
                  value={duration}
                  onChange={e => setDuration(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Meeting Link (optional)</label>
                <input
                  type="url"
                  placeholder="https://meet.google.com/..."
                  value={link}
                  onChange={e => setLink(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  Confirm Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
