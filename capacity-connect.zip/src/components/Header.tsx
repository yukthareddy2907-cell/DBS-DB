import React, { useState } from 'react';
import { User, Notification } from '../types';
import { switchActiveRole } from '../services/storage';
import { NotificationDropdown } from './NotificationDropdown';
import { 
  Layers, 
  Bell, 
  ArrowLeftRight, 
  LogOut, 
  ShieldCheck, 
  User as UserIcon,
  ChevronDown,
  Check,
  GraduationCap,
  Users
} from 'lucide-react';

interface HeaderProps {
  currentUser: User | null;
  notifications: Notification[];
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onLogout: () => void;
  onOpenCoAdminModal: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  notifications,
  onOpenAuth,
  onLogout,
  onOpenCoAdminModal,
  activeTab,
  onSelectTab
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const canSwitchRole = currentUser && (
    (currentUser.hasTraineeRole && currentUser.hasTrainerRole) || 
    currentUser.isMasterAdmin || 
    currentUser.isCoadmin
  );

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo & Product Title */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onSelectTab('home')}>
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <span className="text-base font-bold tracking-tight text-slate-900 block leading-tight">
              CAPACITY CONNECT
            </span>
          </div>
        </div>

        {/* Center / Navigation Links (Clean minimal nav) */}
        <nav className="hidden md:flex items-center space-x-1">
          <button
            onClick={() => onSelectTab('home')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'home'
                ? 'bg-slate-100 text-blue-600'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            Home
          </button>

          {currentUser && (
            <button
              onClick={() => onSelectTab('dashboard')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {currentUser.activeRole === 'admin'
                ? 'Admin Center'
                : currentUser.activeRole === 'trainer'
                ? 'Trainer Dashboard'
                : 'Trainee Dashboard'}
            </button>
          )}
        </nav>

        {/* Right Action Controls */}
        <div className="flex items-center space-x-2.5">

          {currentUser ? (
            <>
              {/* Role Switcher Dropdown Menu */}
              {canSwitchRole && (
                <div className="relative">
                  <button
                    onClick={() => {
                      setShowRoleDropdown(!showRoleDropdown);
                      setShowUserMenu(false);
                      setShowNotifications(false);
                    }}
                    title="Change active role"
                    className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border border-blue-200 bg-blue-50/70 hover:bg-blue-100/70 text-blue-700 text-xs font-medium transition-colors cursor-pointer"
                  >
                    <ArrowLeftRight className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Role:</span>
                    <span className="font-bold capitalize">{currentUser.activeRole}</span>
                    <ChevronDown className="w-3 h-3 ml-0.5 opacity-70" />
                  </button>

                  {showRoleDropdown && (
                    <div className="absolute right-0 mt-2 w-52 bg-white rounded-lg shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                      <div className="px-3.5 py-1.5 border-b border-slate-100">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                          Select Active Role
                        </p>
                      </div>

                      {currentUser.hasTraineeRole && (
                        <button
                          onClick={() => {
                            switchActiveRole('trainee');
                            setShowRoleDropdown(false);
                          }}
                          className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors cursor-pointer ${
                            currentUser.activeRole === 'trainee'
                              ? 'bg-blue-50 text-blue-700 font-semibold'
                              : 'text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            <GraduationCap className="w-4 h-4 text-blue-600" />
                            <span>Trainee Portal</span>
                          </div>
                          {currentUser.activeRole === 'trainee' && (
                            <Check className="w-3.5 h-3.5 text-blue-600" />
                          )}
                        </button>
                      )}

                      {currentUser.hasTrainerRole && (
                        <button
                          onClick={() => {
                            switchActiveRole('trainer');
                            setShowRoleDropdown(false);
                          }}
                          className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors cursor-pointer ${
                            currentUser.activeRole === 'trainer'
                              ? 'bg-blue-50 text-blue-700 font-semibold'
                              : 'text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            <Users className="w-4 h-4 text-blue-600" />
                            <span>Trainer Console</span>
                          </div>
                          {currentUser.activeRole === 'trainer' && (
                            <Check className="w-3.5 h-3.5 text-blue-600" />
                          )}
                        </button>
                      )}

                      {(currentUser.isMasterAdmin || currentUser.isCoadmin) && (
                        <button
                          onClick={() => {
                            switchActiveRole('admin');
                            setShowRoleDropdown(false);
                          }}
                          className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors cursor-pointer ${
                            currentUser.activeRole === 'admin'
                              ? 'bg-blue-50 text-blue-700 font-semibold'
                              : 'text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            <ShieldCheck className="w-4 h-4 text-blue-600" />
                            <span>Admin Center</span>
                          </div>
                          {currentUser.activeRole === 'admin' && (
                            <Check className="w-3.5 h-3.5 text-blue-600" />
                          )}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Real-time Notifications Bell */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    setShowUserMenu(false);
                    setShowRoleDropdown(false);
                  }}
                  className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 relative transition-colors cursor-pointer"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-600 ring-2 ring-white" />
                  )}
                </button>

                {showNotifications && (
                  <NotificationDropdown
                    notifications={notifications}
                    userId={currentUser.id}
                    onClose={() => setShowNotifications(false)}
                  />
                )}
              </div>

              {/* User Menu Trigger */}
              <div className="relative">
                <button
                  onClick={() => {
                    setShowUserMenu(!showUserMenu);
                    setShowNotifications(false);
                    setShowRoleDropdown(false);
                  }}
                  className="flex items-center space-x-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-700">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="hidden lg:block text-left">
                    <p className="text-xs font-semibold text-slate-800 leading-tight">{currentUser.name}</p>
                    <p className="text-[10px] text-slate-500 capitalize">{currentUser.activeRole}</p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-slate-200 py-1 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-4 py-2.5 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <div className="mt-1.5 flex items-center space-x-1.5">
                        <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-700 capitalize">
                          {currentUser.activeRole}
                        </span>
                        {currentUser.isMasterAdmin && (
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700">
                            Master Admin
                          </span>
                        )}
                        {currentUser.isCoadmin && (
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700">
                            Co-Admin
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Co-Admin Request Option (for non-admins) */}
                    {!currentUser.isMasterAdmin && !currentUser.isCoadmin && (
                      <button
                        onClick={() => {
                          setShowUserMenu(false);
                          onOpenCoAdminModal();
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center space-x-2 cursor-pointer"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                        <span>Request Co-Admin Access</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onSelectTab('dashboard');
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center space-x-2 cursor-pointer"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                      <span>My Dashboard</span>
                    </button>

                    <div className="border-t border-slate-100 my-1" />

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onLogout();
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center space-x-2 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-500" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              <button
                onClick={() => onOpenAuth('login')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
              >
                Sign In
              </button>

              <button
                onClick={() => onOpenAuth('register')}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors cursor-pointer"
              >
                Create Your Account
              </button>
            </>
          )}

        </div>
      </div>
    </header>
  );
};
