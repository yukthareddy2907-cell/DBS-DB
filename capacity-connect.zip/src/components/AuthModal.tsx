import React, { useState } from 'react';
import { registerUser, loginUser, MASTER_ADMIN_EMAIL, MASTER_ADMIN_NAME } from '../services/storage';
import { User } from '../types';
import { X, Lock, Mail, UserCheck, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'register';
  onSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'register',
  onSuccess
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(defaultMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [roleChoice, setRoleChoice] = useState<'trainee' | 'trainer' | 'both'>('trainee');
  const [expertise, setExpertise] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'register') {
        if (!name.trim()) {
          setError('Please provide your full name.');
          setLoading(false);
          return;
        }
        if (!email.trim() || !email.includes('@')) {
          setError('Please provide a valid email address.');
          setLoading(false);
          return;
        }

        const res = registerUser({
          name: name.trim(),
          email: email.trim(),
          roleChoice,
          expertise: expertise.trim() || undefined
        });

        if (!res.success || !res.user) {
          setError(res.error || 'Registration failed.');
          setLoading(false);
          return;
        }

        if (email.trim().toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() || email.trim().toLowerCase().includes('gayathri')) {
          localStorage.setItem('capacity_connect_master_admin_created', 'true');
        }

        onSuccess(res.user);
        onClose();
      } else {
        if (!email.trim()) {
          setError('Please enter your email.');
          setLoading(false);
          return;
        }

        const res = loginUser(email.trim());
        if (!res.success || !res.user) {
          setError(res.error || 'Account not found.');
          setLoading(false);
          return;
        }

        if (email.trim().toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase() || email.trim().toLowerCase().includes('gayathri')) {
          localStorage.setItem('capacity_connect_master_admin_created', 'true');
        }

        onSuccess(res.user);
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication error.');
    } finally {
      setLoading(false);
    }
  };

  const isMasterAdminAccountCreated = typeof window !== 'undefined' && 
    localStorage.getItem('capacity_connect_master_admin_created') === 'true';

  const handleQuickMasterAdmin = () => {
    setEmail(MASTER_ADMIN_EMAIL);
    setPassword('MasterAdmin2026!');
    setMode('login');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Tabs */}
        <div className="px-6 pt-5 pb-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex space-x-4">
            <button
              onClick={() => { setMode('register'); setError(null); }}
              className={`text-sm font-semibold pb-1 border-b-2 transition-all cursor-pointer ${
                mode === 'register'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Create Account
            </button>
            <button
              onClick={() => { setMode('login'); setError(null); }}
              className={`text-sm font-semibold pb-1 border-b-2 transition-all cursor-pointer ${
                mode === 'login'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Sign In
            </button>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master Admin Quick Access Badge: Only shown in Sign In mode, only after account was created by Gayathri, and to no one else */}
        {mode === 'login' && isMasterAdminAccountCreated && (
          <div className="px-6 pt-3">
            <button
              type="button"
              onClick={handleQuickMasterAdmin}
              className="w-full text-left p-2.5 rounded-lg bg-slate-50 border border-slate-200 hover:bg-blue-50/50 hover:border-blue-200 transition-colors flex items-center justify-between group"
            >
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <div>
                  <p className="text-xs font-semibold text-slate-800">Master Admin Account</p>
                  <p className="text-[10px] text-slate-500">{MASTER_ADMIN_NAME} ({MASTER_ADMIN_EMAIL})</p>
                </div>
              </div>
              <span className="text-[10px] font-medium text-blue-600 group-hover:underline">Quick Fill →</span>
            </button>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
              {error}
            </div>
          )}

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. Sarah Jenkins"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
            <div className="relative">
              <input
                type="email"
                required
                placeholder="name@organization.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
            <div className="relative">
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-2">Select Your Role</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setRoleChoice('trainee')}
                  className={`p-2.5 rounded-lg border text-center transition-all cursor-pointer ${
                    roleChoice === 'trainee'
                      ? 'border-blue-600 bg-blue-50/60 text-blue-900 font-semibold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <p className="text-xs">Trainee</p>
                  <span className="text-[10px] text-slate-500 font-normal">Learn skills</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRoleChoice('trainer')}
                  className={`p-2.5 rounded-lg border text-center transition-all cursor-pointer ${
                    roleChoice === 'trainer'
                      ? 'border-blue-600 bg-blue-50/60 text-blue-900 font-semibold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <p className="text-xs">Trainer</p>
                  <span className="text-[10px] text-slate-500 font-normal">Mentor others</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRoleChoice('both')}
                  className={`p-2.5 rounded-lg border text-center transition-all cursor-pointer ${
                    roleChoice === 'both'
                      ? 'border-blue-600 bg-blue-50/60 text-blue-900 font-semibold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <p className="text-xs">Both</p>
                  <span className="text-[10px] text-slate-500 font-normal">Dual role</span>
                </button>
              </div>

              {(roleChoice === 'trainer' || roleChoice === 'both') && (
                <div className="mt-3">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Trainer Expertise / Domain
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Distributed Systems & Java"
                    value={expertise}
                    onChange={e => setExpertise(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Your trainer profile will be immediately visible publicly to all trainees.
                  </p>
                </div>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
          >
            <span>{mode === 'register' ? 'Create Your Account' : 'Sign In'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
