// =====================================================================
// CAPACITY CONNECT — REAL-TIME CHAT
// Concept: CO2 (Document-oriented chat message persistence & streaming)
// Available only between connected trainees and approved trainers
// =====================================================================

import React, { useState, useEffect, useRef } from 'react';
import { User, SkillExchangeRequest, ChatMessage } from '../types';
import { getChatMessages, sendChatMessage, subscribeToRealtimeEvents } from '../services/storage';
import { Send, MessageSquare, Clock, UserCheck, ShieldCheck } from 'lucide-react';

interface RealTimeChatProps {
  request: SkillExchangeRequest;
  currentUser: User;
}

export const RealTimeChat: React.FC<RealTimeChatProps> = ({ request, currentUser }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const receiverId = currentUser.id === request.traineeId ? request.trainerId : request.traineeId;
  const receiverName = currentUser.id === request.traineeId ? request.trainerName : request.traineeName;

  const loadMessages = () => {
    const list = getChatMessages(request.id);
    setMessages(list);
  };

  useEffect(() => {
    loadMessages();
    const unsubscribe = subscribeToRealtimeEvents((eventType, payload) => {
      if (eventType === 'CHAT_MESSAGE_SENT' && payload?.requestId === request.id) {
        loadMessages();
      }
    });
    return unsubscribe;
  }, [request.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    sendChatMessage({
      requestId: request.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      receiverId,
      content: inputText.trim()
    });

    setInputText('');
    loadMessages();
  };

  const formatTimestamp = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="flex flex-col h-[500px] bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
      
      {/* Top Bar */}
      <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
            {receiverName.charAt(0)}
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
              <span>{receiverName}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" title="Online" />
            </h4>
            <p className="text-[10px] text-slate-500">
              Skill Exchange: <span className="font-semibold text-blue-600">{request.learnSkill}</span> ↔ <span className="font-semibold text-slate-700">{request.teachSkill}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 px-2 py-1 rounded-md bg-white border border-slate-200 text-[10px] text-slate-600">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
          <span>Verified Exchange</span>
        </div>
      </div>

      {/* Messages Thread */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/40">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <MessageSquare className="w-8 h-8 text-slate-300 mb-2" />
            <p className="text-xs font-medium text-slate-600">No messages yet.</p>
            <p className="text-[11px] text-slate-400 max-w-xs mt-1">
              Start your training discussion, share session goals, or coordinate learning materials.
            </p>
          </div>
        ) : (
          messages.map(msg => {
            const isMe = msg.senderId === currentUser.id;
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-3.5 py-2.5 rounded-xl text-xs ${
                    isMe
                      ? 'bg-blue-600 text-white rounded-br-xs'
                      : 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs shadow-xs'
                  }`}
                >
                  {!isMe && (
                    <p className="text-[10px] font-bold text-blue-700 mb-0.5">
                      {msg.senderName}
                    </p>
                  )}
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                </div>
                <span className="text-[9px] text-slate-400 mt-1 px-1">
                  {formatTimestamp(msg.timestamp)}
                </span>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200 flex items-center space-x-2">
        <input
          type="text"
          placeholder={`Message ${receiverName}...`}
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          className="flex-1 px-3.5 py-2 text-xs bg-slate-50 rounded-lg border border-slate-200 focus:outline-hidden focus:border-blue-600 focus:bg-white"
        />
        <button
          type="submit"
          disabled={!inputText.trim()}
          className="p-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-40 transition-colors cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
