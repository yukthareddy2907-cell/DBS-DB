import React, { useState } from 'react';
import { requestCoAdmin } from '../services/storage';
import { User } from '../types';
import { ShieldCheck, X, Send, AlertCircle, CheckCircle2 } from 'lucide-react';

interface CoAdminRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
}

export const CoAdminRequestModal: React.FC<CoAdminRequestModalProps> = ({
  isOpen,
  onClose,
  currentUser
}) => {
  const [reason, setReason] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen || !currentUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Please provide a reason for requesting Co-Admin access.');
      return;
    }

    setLoading(true);
    setError(null);

    const res = requestCoAdmin(currentUser.id, reason.trim());
    setLoading(false);

    if (res.success) {
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setReason('');
        onClose();
      }, 3000);
    } else {
      setError(res.error || 'Failed to submit request.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Request Co-Admin Privileges</h3>
              <p className="text-[11px] text-slate-500">Requires Master Administrator Approval</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900">Request Dispatched in Real Time</h4>
              <p className="text-xs text-slate-600 max-w-xs mx-auto">
                Your request has been routed to Master Admin <strong>K. Gayathri Srivalli</strong>. You will receive a real-time notification once reviewed.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-lg text-xs text-blue-900 space-y-1">
                <p className="font-semibold">Security Governance Notice</p>
                <p className="text-blue-700 leading-relaxed">
                  Administrator access is strictly controlled. Submitting this request sends an instant alert to the Master Admin. Sensitive credentials or Master Admin PINs are never shared.
                </p>
              </div>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Requester
                </label>
                <input
                  type="text"
                  disabled
                  value={`${currentUser.name} (${currentUser.email})`}
                  className="w-full px-3 py-2 text-xs bg-slate-100 text-slate-600 rounded-lg border border-slate-200 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Justification / Operational Reason
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Explain why you require administrative oversight (e.g., department training coordination, course moderation)..."
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-white rounded-lg border border-slate-300 focus:outline-hidden focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-xs flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Request</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
