/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// =====================================================================
// CAPACITY CONNECT — ROOT APPLICATION CONTROLLER
// Concept: CO4 (Application routing, state management & real-time event distribution)
// =====================================================================

import React, { useState, useEffect } from 'react';
import { User, Notification, Course, TrainerProfile, KnowledgeResource } from './types';
import { 
  getCurrentUser, 
  setCurrentUser, 
  getNotifications, 
  getCourses, 
  getTrainers, 
  getKnowledgeResources,
  subscribeToRealtimeEvents 
} from './services/storage';

import { Header } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { CoAdminRequestModal } from './components/CoAdminRequestModal';

import { HomePage } from './pages/HomePage';
import { TraineeDashboard } from './pages/TraineeDashboard';
import { TrainerDashboard } from './pages/TrainerDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { PublicCourseCatalog } from './pages/PublicCourseCatalog';
import { PublicTrainerDirectory } from './pages/PublicTrainerDirectory';
import { PublicKnowledgeHub } from './pages/PublicKnowledgeHub';

export default function App() {
  const [currentUser, setCurUser] = useState<User | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [trainers, setTrainers] = useState<TrainerProfile[]>([]);
  const [resources, setResources] = useState<KnowledgeResource[]>([]);

  // Active top-level view: restored across page refreshes
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const savedUser = getCurrentUser();
      const savedTab = localStorage.getItem('capacity_connect_active_tab');
      if (savedUser) {
        return savedTab && savedTab !== 'home' ? savedTab : 'dashboard';
      }
      return savedTab || 'home';
    }
    return 'home';
  });

  const handleSelectTab = (tab: string) => {
    setActiveTab(tab);
    if (typeof window !== 'undefined') {
      localStorage.setItem('capacity_connect_active_tab', tab);
    }
  };

  // Modal Visibility
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [showCoAdminModal, setShowCoAdminModal] = useState(false);

  // Sync state from storage
  const syncState = () => {
    const user = getCurrentUser();
    setCurUser(user);
    if (user) {
      setNotifications(getNotifications(user.id));
    } else {
      setNotifications([]);
    }
    setCourses(getCourses());
    setTrainers(getTrainers());
    setResources(getKnowledgeResources());
  };

  useEffect(() => {
    syncState();
    const unsubscribe = subscribeToRealtimeEvents(() => {
      syncState();
    });
    return unsubscribe;
  }, []);

  const handleOpenAuth = (mode: 'login' | 'register' = 'register') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  const handleAuthSuccess = (user: User) => {
    setCurUser(user);
    // Route to user's dashboard immediately and persist
    handleSelectTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurUser(null);
    handleSelectTab('home');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex flex-col font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
      
      {/* Universal Header */}
      <Header
        currentUser={currentUser}
        notifications={notifications}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
        onOpenCoAdminModal={() => setShowCoAdminModal(true)}
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
      />

      {/* Main Body Router */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomePage
            onOpenAuth={handleOpenAuth}
            onExplore={() => setActiveTab('courses')}
          />
        )}

        {activeTab === 'dashboard' && currentUser && (
          <>
            {currentUser.activeRole === 'admin' && (
              <AdminDashboard currentUser={currentUser} />
            )}
            {currentUser.activeRole === 'trainer' && (
              <TrainerDashboard currentUser={currentUser} />
            )}
            {currentUser.activeRole === 'trainee' && (
              <TraineeDashboard currentUser={currentUser} />
            )}
          </>
        )}

        {activeTab === 'courses' && (
          <PublicCourseCatalog
            courses={courses}
            currentUser={currentUser}
            onOpenAuth={() => handleOpenAuth('login')}
            onEnrollSuccess={() => {
              setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'trainers' && (
          <PublicTrainerDirectory
            trainers={trainers}
            currentUser={currentUser}
            onOpenAuth={() => handleOpenAuth('login')}
            onRequestExchange={(tr) => {
              // Direct to trainee dashboard for exchange
              setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'knowledge' && (
          <PublicKnowledgeHub resources={resources} />
        )}
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        defaultMode={authMode}
        onSuccess={handleAuthSuccess}
      />

      {/* Co-Admin Request Modal */}
      <CoAdminRequestModal
        isOpen={showCoAdminModal}
        onClose={() => setShowCoAdminModal(false)}
        currentUser={currentUser}
      />

    </div>
  );
}
