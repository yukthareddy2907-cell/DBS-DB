// =====================================================================
// CAPACITY CONNECT — MINIMALIST PDF CERTIFICATE GENERATOR
// Uses jsPDF to create a clean, modern, enterprise certificate of competency
// =====================================================================

import { jsPDF } from 'jspdf';
import { Certificate } from '../types';

export function downloadCertificatePdf(cert: Certificate): void {
  // A4 Landscape: 297mm x 210mm
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  const width = doc.internal.pageSize.getWidth();
  const height = doc.internal.pageSize.getHeight();

  // Background subtle canvas
  doc.setFillColor(248, 250, 252); // #F8FAFC
  doc.rect(0, 0, width, height, 'F');

  // Outer minimal navy border
  doc.setDrawColor(226, 232, 240); // #E2E8F0
  doc.setLineWidth(1.5);
  doc.rect(12, 12, width - 24, height - 24);

  // Inner clean accent border
  doc.setDrawColor(37, 99, 235); // #2563EB primary blue
  doc.setLineWidth(0.6);
  doc.rect(16, 16, width - 32, height - 32);

  // Top Brand Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(15, 23, 42); // #0F172A Deep Navy
  doc.text('CAPACITY CONNECT', width / 2, 34, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139); // #64748B Secondary Text
  doc.text('EMPOWERING PEOPLE, SKILLS & ORGANIZATIONAL GROWTH', width / 2, 41, { align: 'center' });

  // Divider Accent Line
  doc.setDrawColor(37, 99, 235);
  doc.setLineWidth(1);
  doc.line(width / 2 - 30, 46, width / 2 + 30, 46);

  // Certificate Label
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(37, 99, 235);
  doc.text('CERTIFICATE OF COMPETENCY COMPLETION', width / 2, 57, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(71, 85, 105);
  doc.text('This verified enterprise credential certifies that', width / 2, 68, { align: 'center' });

  // Recipient Trainee Name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(26);
  doc.setTextColor(15, 23, 42);
  doc.text(cert.traineeName, width / 2, 82, { align: 'center' });

  // Underlying subtle line under name
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.5);
  doc.line(width / 2 - 60, 86, width / 2 + 60, 86);

  // Course completion text
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(71, 85, 105);
  doc.text('has successfully demonstrated required proficiency and fulfilled all learning standards for', width / 2, 95, { align: 'center' });

  // Course Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(29, 78, 216); // #1D4ED8 Dark blue
  doc.text(cert.courseTitle, width / 2, 107, { align: 'center' });

  // Skill Acquired & Evaluation Grade
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Specialized Skill Focus: ${cert.skillAcquired}   |   Assessment Status: ${cert.grade || 'Certified Competent'}`, width / 2, 116, { align: 'center' });

  // Bottom Signatures & Verification Details
  const bottomY = 155;

  // Trainer Signature Box (Left)
  doc.setDrawColor(203, 213, 225);
  doc.line(35, bottomY, 105, bottomY);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text(cert.trainerName, 70, bottomY + 6, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Authorized Lead Trainer', 70, bottomY + 11, { align: 'center' });

  // Official Badge (Center)
  doc.setFillColor(239, 246, 255); // #EFF6FF
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(width / 2 - 25, bottomY - 14, 50, 24, 3, 3, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(37, 99, 235);
  doc.text('CAPACITY CONNECT', width / 2, bottomY - 4, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 64, 175);
  doc.text('VERIFIED CREDENTIAL', width / 2, bottomY + 2, { align: 'center' });

  // Platform Master Admin (Right)
  doc.setDrawColor(203, 213, 225);
  doc.line(width - 105, bottomY, width - 35, bottomY);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text('K. Gayathri Srivalli', width - 70, bottomY + 6, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Master Administrator', width - 70, bottomY + 11, { align: 'center' });

  // Footer Metadata
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184);
  doc.text(`Credential ID: ${cert.credentialId}`, 22, height - 19);
  doc.text(`Issue Date: ${cert.issueDate}`, width / 2, height - 19, { align: 'center' });
  doc.text('Official Digital Record — Tamper Proof', width - 22, height - 19, { align: 'right' });

  // Trigger browser download
  const sanitizedFilename = `CapacityConnect_${cert.courseTitle.replace(/[^a-zA-Z0-9]/g, '_')}_Certificate.pdf`;
  doc.save(sanitizedFilename);
}
