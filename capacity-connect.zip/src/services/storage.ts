// =====================================================================
// CAPACITY CONNECT — REAL-TIME DATABASE & STORAGE SERVICE
// Concept: CO1 (ACID transactional state & normalized relational tables)
// Concept: CO2 (Polyglot document store for chat messages)
// Concept: CO5 (Event-driven pub/sub communication & real-time synchronization)
// =====================================================================

import {
  User,
  TrainerProfile,
  Course,
  SkillExchangeRequest,
  CourseEnrollment,
  TraineeCompetency,
  Assessment,
  AssessmentSubmission,
  Certificate,
  KnowledgeResource,
  CoAdminRequest,
  Notification,
  ChatMessage,
  TrainingSession
} from '../types';

const STORAGE_KEY_PREFIX = 'capacity_connect_';

// Real-time synchronization channel across browser tabs/contexts
const syncChannel = typeof window !== 'undefined' && 'BroadcastChannel' in window 
  ? new BroadcastChannel('capacity_connect_realtime_events') 
  : null;

// Listeners for local real-time reactivity
type EventCallback = (eventType: string, payload?: any) => void;
const eventListeners: Set<EventCallback> = new Set();

export function subscribeToRealtimeEvents(callback: EventCallback): () => void {
  eventListeners.add(callback);
  return () => {
    eventListeners.delete(callback);
  };
}

function broadcastEvent(eventType: string, payload?: any) {
  // Notify internal tab listeners
  eventListeners.forEach(listener => listener(eventType, payload));
  
  // Broadcast across multi-user browser sessions/tabs
  if (syncChannel) {
    try {
      syncChannel.postMessage({ eventType, payload, timestamp: Date.now() });
    } catch (e) {
      console.warn('BroadcastChannel error:', e);
    }
  }

  // Trigger storage event in other browser windows
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY_PREFIX + 'last_sync_timestamp', Date.now().toString());
    } catch (e) {
      // Ignore storage quota warnings
    }
  }
}

if (syncChannel) {
  syncChannel.onmessage = (event) => {
    const { eventType, payload } = event.data || {};
    if (eventType) {
      eventListeners.forEach(listener => listener(eventType, payload));
    }
  };
}

// Window storage listener for instant cross-tab sync
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key && e.key.startsWith(STORAGE_KEY_PREFIX)) {
      eventListeners.forEach(listener => listener('STORAGE_SYNC', e.key));
    }
  });

  // Automatic real-time polling every 2 seconds to ensure dynamic updates
  setInterval(() => {
    eventListeners.forEach(listener => listener('POLL_TICK'));
  }, 2000);
}

// ---------------------------------------------------------------------
// Storage Helpers
// ---------------------------------------------------------------------
function getItem<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    return raw ? JSON.parse(raw) : defaultValue;
  } catch (e) {
    console.error(`Failed to read ${key} from storage:`, e);
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to write ${key} to storage:`, e);
  }
}

// ---------------------------------------------------------------------
// Initial State Bootstrap
// CRITICAL: NO MOCK DATA. Starts clean.
// Only the Master Admin account is recognized.
// ---------------------------------------------------------------------
export const MASTER_ADMIN_EMAIL = 'gayathri@gmail.com';
export const MASTER_ADMIN_NAME = 'K. Gayathri Srivalli';

export function initializeDatabase(): void {
  const users = getItem<User[]>('users', []);
  
  // Ensure Master Admin exists in database
  const masterAdminExists = users.some(u => u.email.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase());
  let masterAdmin: User;
  if (!masterAdminExists) {
    masterAdmin = {
      id: 'usr_master_admin_01',
      name: MASTER_ADMIN_NAME,
      email: MASTER_ADMIN_EMAIL,
      primaryRole: 'admin',
      activeRole: 'admin',
      hasTraineeRole: true,
      hasTrainerRole: true,
      isCoadmin: false,
      isMasterAdmin: true,
      headline: 'Master Platform Administrator',
      bio: 'Leading enterprise capacity building, skills development, and learning architecture.',
      createdAt: new Date().toISOString()
    };
    users.unshift(masterAdmin);
    setItem('users', users);
  } else {
    masterAdmin = users.find(u => u.email.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase())!;
  }

  // Ensure Master Admin is also registered in trainer profiles for skill exchange
  const trainerProfiles = getItem<TrainerProfile[]>('trainer_profiles', []);
  if (!trainerProfiles.some(t => t.userId === masterAdmin.id || t.email.toLowerCase() === MASTER_ADMIN_EMAIL.toLowerCase())) {
    trainerProfiles.unshift({
      userId: masterAdmin.id,
      name: MASTER_ADMIN_NAME,
      email: MASTER_ADMIN_EMAIL,
      expertise: 'Enterprise Architecture & Cloud Capacity Building',
      skills: ['Distributed Systems', 'Software Engineering', 'Team Mentorship'],
      subjects: ['System Design', 'Enterprise Development', 'Full-Stack Architecture'],
      qualifications: 'Master System Architect & Lead Mentor',
      experienceYears: 10,
      certifications: 'Executive Enterprise Capacity Lead',
      availability: 'Flexible (Evenings & Weekends)',
      rating: 5.0,
      totalReviews: 5,
      isPubliclyVisible: true
    });
    setItem('trainer_profiles', trainerProfiles);
  }
}

// Initialize on module load
initializeDatabase();

// ---------------------------------------------------------------------
// AUTH & USER MANAGEMENT (CO1 & CO4)
// ---------------------------------------------------------------------
export function getCurrentUser(): User | null {
  return getItem<User | null>('current_user', null);
}

export function setCurrentUser(user: User | null): void {
  setItem('current_user', user);
  broadcastEvent('AUTH_STATE_CHANGED', user);
}

export function registerUser(params: {
  name: string;
  email: string;
  roleChoice: 'trainee' | 'trainer' | 'both';
  bio?: string;
  expertise?: string;
  skills?: string[];
}): { success: boolean; user?: User; error?: string } {
  const users = getItem<User[]>('users', []);
  const emailNorm = params.email.trim().toLowerCase();

  if (users.some(u => u.email.toLowerCase() === emailNorm)) {
    return { success: false, error: 'An account with this email address already exists.' };
  }

  const isMaster = emailNorm === MASTER_ADMIN_EMAIL.toLowerCase();
  const hasTrainee = params.roleChoice === 'trainee' || params.roleChoice === 'both' || isMaster;
  const hasTrainer = params.roleChoice === 'trainer' || params.roleChoice === 'both' || isMaster;
  const primaryRole: 'trainee' | 'trainer' | 'admin' = isMaster ? 'admin' : (hasTrainer && !hasTrainee ? 'trainer' : 'trainee');

  const newUser: User = {
    id: 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    name: params.name.trim(),
    email: emailNorm,
    primaryRole,
    activeRole: primaryRole,
    hasTraineeRole: hasTrainee,
    hasTrainerRole: hasTrainer,
    isCoadmin: false,
    isMasterAdmin: isMaster,
    bio: params.bio || '',
    headline: hasTrainer ? (params.expertise || 'Certified Trainer & Skill Mentor') : 'Active Trainee & Learner',
    createdAt: new Date().toISOString()
  };

  users.push(newUser);
  setItem('users', users);

  // If user selected trainer role, create their publicly visible Trainer Profile immediately
  if (hasTrainer) {
    const trainerProfiles = getItem<TrainerProfile[]>('trainer_profiles', []);
    const newProfile: TrainerProfile = {
      userId: newUser.id,
      name: newUser.name,
      email: newUser.email,
      expertise: params.expertise || 'Specialized Industry Domain',
      skills: params.skills && params.skills.length > 0 ? params.skills : ['Domain Fundamentals', 'Best Practices'],
      subjects: ['Core Concepts', 'Hands-on Projects', 'Applied Practice'],
      qualifications: 'Professional Industry Practitioner',
      experienceYears: 3,
      certifications: 'Enterprise Certified Specialist',
      availability: 'Flexible (Weekday Evenings & Weekends)',
      rating: 5.0,
      totalReviews: 0,
      isPubliclyVisible: true
    };
    trainerProfiles.push(newProfile);
    setItem('trainer_profiles', trainerProfiles);
    broadcastEvent('TRAINERS_UPDATED');
  }

  setCurrentUser(newUser);
  broadcastEvent('USER_REGISTERED', newUser);
  return { success: true, user: newUser };
}

export function loginUser(email: string): { success: boolean; user?: User; error?: string } {
  const users = getItem<User[]>('users', []);
  const emailNorm = email.trim().toLowerCase();
  const found = users.find(u => u.email.toLowerCase() === emailNorm);

  if (!found) {
    return { success: false, error: 'User not found. Please create an account.' };
  }

  // Set active role appropriately
  const updatedUser = { ...found, activeRole: found.primaryRole };
  setCurrentUser(updatedUser);
  return { success: true, user: updatedUser };
}

export function switchActiveRole(targetRole: 'trainee' | 'trainer' | 'admin'): User | null {
  const current = getCurrentUser();
  if (!current) return null;

  // Authorization check for target role
  if (targetRole === 'trainee' && !current.hasTraineeRole) return null;
  if (targetRole === 'trainer' && !current.hasTrainerRole) return null;
  if (targetRole === 'admin' && !current.isMasterAdmin && !current.isCoadmin) return null;

  const updated: User = { ...current, activeRole: targetRole };
  setCurrentUser(updated);

  // Update in user list
  const users = getItem<User[]>('users', []);
  const idx = users.findIndex(u => u.id === current.id);
  if (idx !== -1) {
    users[idx] = updated;
    setItem('users', users);
  }

  broadcastEvent('ROLE_SWITCHED', updated);
  return updated;
}

// ---------------------------------------------------------------------
// CO-ADMIN REQUEST FLOW (Master Admin Controlled Authorization)
// ---------------------------------------------------------------------
export function requestCoAdmin(userId: string, reason: string): { success: boolean; error?: string } {
  const users = getItem<User[]>('users', []);
  const user = users.find(u => u.id === userId);
  if (!user) return { success: false, error: 'User not found.' };

  const requests = getItem<CoAdminRequest[]>('coadmin_requests', []);
  const existingPending = requests.find(r => r.userId === userId && r.status === 'pending');
  if (existingPending) {
    return { success: false, error: 'You already have a pending Co-Admin request awaiting Master Admin review.' };
  }

  const newReq: CoAdminRequest = {
    id: 'coadmin_req_' + Date.now(),
    userId: user.id,
    userName: user.name,
    userEmail: user.email,
    currentRole: user.activeRole,
    reason: reason.trim(),
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  requests.push(newReq);
  setItem('coadmin_requests', requests);

  // Send real-time notification to Master Admin
  const masterAdmin = users.find(u => u.isMasterAdmin);
  if (masterAdmin) {
    createNotification({
      recipientId: masterAdmin.id,
      senderId: user.id,
      title: 'New Co-Admin Access Request',
      message: `${user.name} (${user.email}) requested Co-Admin privileges. Reason: "${reason.substring(0, 100)}..."`,
      type: 'coadmin_request'
    });
  }

  broadcastEvent('COADMIN_REQUESTS_UPDATED');
  return { success: true };
}

export function getCoAdminRequests(): CoAdminRequest[] {
  return getItem<CoAdminRequest[]>('coadmin_requests', []);
}

export function handleCoAdminDecision(requestId: string, decision: 'approved' | 'declined'): boolean {
  const requests = getItem<CoAdminRequest[]>('coadmin_requests', []);
  const req = requests.find(r => r.id === requestId);
  if (!req) return false;

  req.status = decision;
  req.updatedAt = new Date().toISOString();
  setItem('coadmin_requests', requests);

  const users = getItem<User[]>('users', []);
  const user = users.find(u => u.id === req.userId);

  if (user) {
    if (decision === 'approved') {
      user.isCoadmin = true;
      user.primaryRole = 'admin';
      user.activeRole = 'admin';
      
      createNotification({
        recipientId: user.id,
        title: 'Co-Admin Request Approved',
        message: 'Your request for Co-Admin privileges has been approved by Master Admin K. Gayathri Srivalli. You now have administrative access.',
        type: 'coadmin_approved'
      });
    } else {
      createNotification({
        recipientId: user.id,
        title: 'Co-Admin Request Declined',
        message: 'Your request for Co-Admin privileges was reviewed and declined by the Master Administrator.',
        type: 'system'
      });
    }

    setItem('users', users);

    // If current logged-in user is the requester, update active session
    const current = getCurrentUser();
    if (current && current.id === user.id) {
      setCurrentUser(user);
    }
  }

  broadcastEvent('COADMIN_REQUESTS_UPDATED');
  broadcastEvent('USERS_UPDATED');
  return true;
}

// ---------------------------------------------------------------------
// TRAINERS DIRECTORY & PROFILES (Publicly Viewable to Trainees)
// ---------------------------------------------------------------------
export function getTrainers(): TrainerProfile[] {
  let profiles = getItem<TrainerProfile[]>('trainer_profiles', []);
  const users = getItem<User[]>('users', []);

  // Ensure every user who has trainer role has a profile
  const trainerUsers = users.filter(u => u.hasTrainerRole || u.primaryRole === 'trainer');
  let changed = false;

  for (const tu of trainerUsers) {
    const existingIndex = profiles.findIndex(p => p.userId === tu.id || p.email.toLowerCase() === tu.email.toLowerCase());
    if (existingIndex === -1) {
      profiles.push({
        userId: tu.id,
        name: tu.name,
        email: tu.email,
        expertise: tu.headline || 'Industry Trainer & Specialist',
        skills: ['Core Competencies', 'Hands-on Mentorship', 'Applied Best Practices'],
        subjects: ['Core Concepts', 'Problem Solving', 'Project Guidance'],
        qualifications: 'Certified Professional Practitioner',
        experienceYears: 3,
        certifications: 'Enterprise Certified Trainer',
        availability: 'Flexible (Weekdays & Weekends)',
        rating: 5.0,
        totalReviews: 0,
        isPubliclyVisible: true
      });
      changed = true;
    } else {
      if (profiles[existingIndex].name !== tu.name || profiles[existingIndex].email !== tu.email) {
        profiles[existingIndex].name = tu.name;
        profiles[existingIndex].email = tu.email;
        changed = true;
      }
    }
  }

  if (changed) {
    setItem('trainer_profiles', profiles);
  }

  return profiles;
}

export function getTrainerById(userId: string): TrainerProfile | undefined {
  const trainers = getTrainers();
  return trainers.find(t => t.userId === userId);
}

export function updateTrainerProfile(profile: Partial<TrainerProfile> & { userId: string }): boolean {
  const trainers = getTrainers();
  const idx = trainers.findIndex(t => t.userId === profile.userId);
  if (idx === -1) return false;

  trainers[idx] = { ...trainers[idx], ...profile };
  setItem('trainer_profiles', trainers);
  broadcastEvent('TRAINERS_UPDATED');
  return true;
}

// ---------------------------------------------------------------------
// COURSES CATALOG & MANAGEMENT
// ---------------------------------------------------------------------
export function getCourses(): Course[] {
  return getItem<Course[]>('courses', []);
}

export function getPublishedCourses(): Course[] {
  return getCourses().filter(c => c.isPublished);
}

export function getCourseById(courseId: string): Course | undefined {
  return getCourses().find(c => c.id === courseId);
}

export function createCourse(courseData: Omit<Course, 'id' | 'createdAt' | 'enrolledCount'>): Course {
  const courses = getCourses();
  const newCourse: Course = {
    ...courseData,
    id: 'course_' + Date.now(),
    enrolledCount: 0,
    createdAt: new Date().toISOString()
  };
  courses.push(newCourse);
  setItem('courses', courses);
  broadcastEvent('COURSES_UPDATED');
  return newCourse;
}

export function deleteCourse(courseId: string): boolean {
  const courses = getCourses();
  const filtered = courses.filter(c => c.id !== courseId);
  if (filtered.length === courses.length) return false;

  setItem('courses', filtered);
  broadcastEvent('COURSES_UPDATED');
  return true;
}

// ---------------------------------------------------------------------
// COURSE ENROLLMENTS
// ---------------------------------------------------------------------
export function getEnrollments(): CourseEnrollment[] {
  return getItem<CourseEnrollment[]>('course_enrollments', []);
}

export function getTraineeEnrollments(traineeId: string): CourseEnrollment[] {
  return getEnrollments().filter(e => e.traineeId === traineeId);
}

export function enrollInCourse(traineeId: string, courseId: string): { success: boolean; enrollment?: CourseEnrollment; error?: string } {
  const course = getCourseById(courseId);
  if (!course) return { success: false, error: 'Course not found.' };

  const enrollments = getEnrollments();
  const existing = enrollments.find(e => e.traineeId === traineeId && e.courseId === courseId);
  if (existing) {
    return { success: false, error: 'You are already enrolled in this course.' };
  }

  const newEnrollment: CourseEnrollment = {
    id: 'enr_' + Date.now(),
    traineeId,
    courseId,
    courseTitle: course.title,
    progressPercent: 0,
    status: 'active',
    enrolledAt: new Date().toISOString()
  };

  enrollments.push(newEnrollment);
  setItem('course_enrollments', enrollments);

  // Increment enrolledCount
  const courses = getCourses();
  const courseIdx = courses.findIndex(c => c.id === courseId);
  if (courseIdx !== -1) {
    courses[courseIdx].enrolledCount = (courses[courseIdx].enrolledCount || 0) + 1;
    setItem('courses', courses);
  }

  broadcastEvent('ENROLLMENTS_UPDATED');
  return { success: true, enrollment: newEnrollment };
}

export function updateCourseProgress(traineeId: string, courseId: string, newProgress: number): void {
  const enrollments = getEnrollments();
  const enr = enrollments.find(e => e.traineeId === traineeId && e.courseId === courseId);
  if (enr) {
    enr.progressPercent = Math.min(100, Math.max(0, newProgress));
    if (enr.progressPercent === 100) {
      enr.status = 'completed';
      enr.completedAt = new Date().toISOString();
    }
    setItem('course_enrollments', enrollments);
    broadcastEvent('ENROLLMENTS_UPDATED');
  }
}

// ---------------------------------------------------------------------
// SKILL EXCHANGE & TRAINER REQUESTS (Real-time synchronization)
// ---------------------------------------------------------------------
export function getSkillExchangeRequests(): SkillExchangeRequest[] {
  return getItem<SkillExchangeRequest[]>('skill_exchange_requests', []);
}

export function sendSkillExchangeRequest(params: {
  traineeId: string;
  traineeName: string;
  traineeEmail: string;
  trainerId: string;
  trainerName: string;
  trainerEmail?: string;
  learnSkill: string;
  teachSkill: string;
  courseId?: string;
  courseTitle?: string;
  notes?: string;
}): SkillExchangeRequest {
  const requests = getSkillExchangeRequests();
  
  // Resolve trainerEmail if not explicitly passed
  let resolvedTrainerEmail = params.trainerEmail;
  if (!resolvedTrainerEmail) {
    const trainers = getTrainers();
    const tr = trainers.find(t => t.userId === params.trainerId);
    if (tr) resolvedTrainerEmail = tr.email;
  }

  const newReq: SkillExchangeRequest = {
    id: 'req_' + Date.now(),
    ...params,
    trainerEmail: resolvedTrainerEmail,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  requests.push(newReq);
  setItem('skill_exchange_requests', requests);

  // Send real-time notification to Trainer
  createNotification({
    recipientId: params.trainerId,
    senderId: params.traineeId,
    title: 'New Skill Exchange Request',
    message: `${params.traineeName} wants to learn "${params.learnSkill}" and can teach "${params.teachSkill}".`,
    type: 'request_sent'
  });

  // Real-time synchronization
  broadcastEvent('REQUEST_CREATED', newReq);
  return newReq;
}

export function handleSkillExchangeRequest(requestId: string, status: 'accepted' | 'declined', responseNote?: string): boolean {
  const requests = getSkillExchangeRequests();
  const req = requests.find(r => r.id === requestId);
  if (!req) return false;

  req.status = status;
  req.responseNote = responseNote;
  req.updatedAt = new Date().toISOString();
  setItem('skill_exchange_requests', requests);

  // Send notification to Trainee
  if (status === 'accepted') {
    createNotification({
      recipientId: req.traineeId,
      senderId: req.trainerId,
      title: 'Skill Exchange Request Accepted!',
      message: `Trainer ${req.trainerName} accepted your request to learn "${req.learnSkill}". You can now access assessments, schedule sessions, and chat directly.`,
      type: 'request_accepted'
    });
  } else {
    createNotification({
      recipientId: req.traineeId,
      senderId: req.trainerId,
      title: 'Skill Exchange Request Declined',
      message: `Trainer ${req.trainerName} was unable to accept your request for "${req.learnSkill}".`,
      type: 'request_declined'
    });
  }

  // Real-time synchronization across trainee & trainer dashboards
  broadcastEvent('REQUEST_UPDATED', req);
  return true;
}

// ---------------------------------------------------------------------
// ASSESSMENTS & SECURE EVALUATION
// Rule: Trainee can ONLY take assessments made by their trainers who approved their request
// CRITICAL: Answer key correctOption is never sent to trainee
// ---------------------------------------------------------------------
export function getAssessments(): Assessment[] {
  return getItem<Assessment[]>('assessments', []);
}

export function createAssessment(assessment: Omit<Assessment, 'id' | 'createdAt'>): Assessment {
  const assessments = getAssessments();
  const newAss: Assessment = {
    ...assessment,
    id: 'ass_' + Date.now(),
    createdAt: new Date().toISOString()
  };
  assessments.push(newAss);
  setItem('assessments', assessments);
  broadcastEvent('ASSESSMENTS_UPDATED');
  return newAss;
}

export function deleteAssessment(assessmentId: string): boolean {
  const assessments = getAssessments();
  const filtered = assessments.filter(a => a.id !== assessmentId);
  if (filtered.length === assessments.length) return false;

  setItem('assessments', filtered);
  broadcastEvent('ASSESSMENTS_UPDATED');
  return true;
}

// Trainee assessments filter: ONLY assessments from trainers who accepted their skill exchange request
export function getEligibleAssessmentsForTrainee(traineeId: string): Assessment[] {
  const requests = getSkillExchangeRequests();
  const acceptedRequests = requests.filter(r => r.traineeId === traineeId && r.status === 'accepted');
  const approvedTrainerIds = new Set(acceptedRequests.map(r => r.trainerId));

  const allAssessments = getAssessments();
  // Filter only assessments created by approved trainers
  return allAssessments.filter(ass => approvedTrainerIds.has(ass.trainerId));
}

export function getAssessmentSubmissions(): AssessmentSubmission[] {
  return getItem<AssessmentSubmission[]>('assessment_submissions', []);
}

// SECURE Backend Evaluation
export function submitAssessmentSecure(params: {
  assessmentId: string;
  traineeId: string;
  traineeName: string;
  submittedAnswers: Record<string, number>;
}): { success: boolean; submission?: AssessmentSubmission; error?: string } {
  const assessment = getAssessments().find(a => a.id === params.assessmentId);
  if (!assessment) return { success: false, error: 'Assessment not found.' };

  // Evaluate securely against correct answers
  let score = 0;
  let totalMarks = 0;

  assessment.questions.forEach(q => {
    totalMarks += (q.points || 1);
    const traineeAns = params.submittedAnswers[q.id];
    if (traineeAns !== undefined && q.correctOption !== undefined && traineeAns === q.correctOption) {
      score += (q.points || 1);
    }
  });

  const percentage = totalMarks > 0 ? Math.round((score / totalMarks) * 100) : 0;
  const passed = percentage >= assessment.passingScore;

  const submissions = getAssessmentSubmissions();
  const newSubmission: AssessmentSubmission = {
    id: 'sub_' + Date.now(),
    assessmentId: assessment.id,
    assessmentTitle: assessment.title,
    courseId: assessment.courseId,
    traineeId: params.traineeId,
    traineeName: params.traineeName,
    score,
    totalMarks,
    percentage,
    passed,
    submittedAnswers: params.submittedAnswers,
    submittedAt: new Date().toISOString()
  };

  submissions.push(newSubmission);
  setItem('assessment_submissions', submissions);

  // Notify trainer of attempt
  createNotification({
    recipientId: assessment.trainerId,
    senderId: params.traineeId,
    title: `Assessment Completed: ${assessment.title}`,
    message: `${params.traineeName} scored ${score}/${totalMarks} (${percentage}% - ${passed ? 'PASSED' : 'FAILED'}).`,
    type: 'assessment_result'
  });

  // Notify trainee of result
  createNotification({
    recipientId: params.traineeId,
    title: `Assessment Evaluated: ${assessment.title}`,
    message: `You scored ${percentage}% (${score}/${totalMarks}). Result: ${passed ? 'PASSED' : 'NEEDS IMPROVEMENT'}.`,
    type: 'assessment_result'
  });

  // Automatically improve trainee competency if passed
  if (passed) {
    updateTraineeCompetency(params.traineeId, assessment.targetCompetency, 1);
  }

  broadcastEvent('ASSESSMENT_SUBMITTED', newSubmission);
  return { success: true, submission: newSubmission };
}

// ---------------------------------------------------------------------
// TRAINEE COMPETENCIES (Course-Specific Skill-Gap Detection)
// ---------------------------------------------------------------------
export function getTraineeCompetencies(traineeId: string): TraineeCompetency[] {
  const all = getItem<TraineeCompetency[]>('trainee_competencies', []);
  return all.filter(c => c.traineeId === traineeId);
}

export function updateTraineeCompetency(traineeId: string, skillName: string, deltaOrSet: number, isAbsolute = false): void {
  const all = getItem<TraineeCompetency[]>('trainee_competencies', []);
  const existing = all.find(c => c.traineeId === traineeId && c.skillName.toLowerCase() === skillName.toLowerCase());

  if (existing) {
    existing.currentLevel = isAbsolute 
      ? Math.min(5, Math.max(1, deltaOrSet))
      : Math.min(5, Math.max(1, existing.currentLevel + deltaOrSet));
    existing.updatedAt = new Date().toISOString();
  } else {
    all.push({
      id: 'comp_' + Date.now() + Math.random().toString(36).substring(2, 5),
      traineeId,
      skillName,
      currentLevel: isAbsolute ? Math.min(5, Math.max(1, deltaOrSet)) : Math.min(5, 1 + deltaOrSet),
      updatedAt: new Date().toISOString()
    });
  }

  setItem('trainee_competencies', all);
  broadcastEvent('COMPETENCIES_UPDATED');
}

// ---------------------------------------------------------------------
// CERTIFICATES
// Trainer issues certificate upon course completion
// Trainee views and downloads minimalist PDF
// Admin can view/delete any certificate
// ---------------------------------------------------------------------
export function getCertificates(): Certificate[] {
  return getItem<Certificate[]>('certificates', []);
}

export function issueCertificate(params: {
  traineeId: string;
  traineeName: string;
  trainerId: string;
  trainerName: string;
  courseId: string;
  courseTitle: string;
  skillAcquired: string;
  grade?: string;
}): Certificate {
  const certs = getCertificates();
  const credentialId = 'CC-CERT-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString().slice(-4);
  
  const newCert: Certificate = {
    id: 'cert_' + Date.now(),
    credentialId,
    traineeId: params.traineeId,
    traineeName: params.traineeName,
    trainerId: params.trainerId,
    trainerName: params.trainerName,
    courseId: params.courseId,
    courseTitle: params.courseTitle,
    skillAcquired: params.skillAcquired,
    issueDate: new Date().toISOString().split('T')[0],
    status: 'issued',
    grade: params.grade || 'Certified Competent'
  };

  certs.push(newCert);
  setItem('certificates', certs);

  // Notify trainee
  createNotification({
    recipientId: params.traineeId,
    senderId: params.trainerId,
    title: 'Certificate of Completion Issued!',
    message: `Trainer ${params.trainerName} has awarded your Certificate for ${params.courseTitle}. Credential ID: ${credentialId}.`,
    type: 'cert_issued'
  });

  broadcastEvent('CERTIFICATES_UPDATED', newCert);
  return newCert;
}

export function deleteCertificate(certificateId: string): boolean {
  const certs = getCertificates();
  const filtered = certs.filter(c => c.id !== certificateId);
  if (filtered.length === certs.length) return false;

  setItem('certificates', filtered);
  broadcastEvent('CERTIFICATES_UPDATED');
  return true;
}

// ---------------------------------------------------------------------
// KNOWLEDGE HUB RESOURCES
// ---------------------------------------------------------------------
export function getKnowledgeResources(): KnowledgeResource[] {
  return getItem<KnowledgeResource[]>('knowledge_resources', []);
}

export function uploadKnowledgeResource(resource: Omit<KnowledgeResource, 'id' | 'downloadsCount' | 'createdAt'>): KnowledgeResource {
  const resources = getKnowledgeResources();
  const newRes: KnowledgeResource = {
    ...resource,
    id: 'res_' + Date.now(),
    downloadsCount: 0,
    createdAt: new Date().toISOString()
  };
  resources.push(newRes);
  setItem('knowledge_resources', resources);
  broadcastEvent('RESOURCES_UPDATED');
  return newRes;
}

export function updateResourceStatus(resourceId: string, status: 'approved' | 'rejected'): boolean {
  const resources = getKnowledgeResources();
  const res = resources.find(r => r.id === resourceId);
  if (!res) return false;

  res.status = status;
  setItem('knowledge_resources', resources);
  broadcastEvent('RESOURCES_UPDATED');
  return true;
}

export function deleteKnowledgeResource(resourceId: string): boolean {
  const resources = getKnowledgeResources();
  const filtered = resources.filter(r => r.id !== resourceId);
  if (filtered.length === resources.length) return false;

  setItem('knowledge_resources', filtered);
  broadcastEvent('RESOURCES_UPDATED');
  return true;
}

// ---------------------------------------------------------------------
// REAL-TIME CHAT MESSAGES (CO2 - Document Structure)
// ---------------------------------------------------------------------
export function getChatMessages(requestId: string): ChatMessage[] {
  const messages = getItem<ChatMessage[]>('chat_messages', []);
  return messages.filter(m => m.requestId === requestId);
}

export function sendChatMessage(params: {
  requestId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
}): ChatMessage {
  const messages = getItem<ChatMessage[]>('chat_messages', []);
  const newMsg: ChatMessage = {
    id: 'msg_' + Date.now() + Math.random().toString(36).substring(2, 6),
    ...params,
    timestamp: new Date().toISOString(),
    read: false
  };

  messages.push(newMsg);
  setItem('chat_messages', messages);
  broadcastEvent('CHAT_MESSAGE_SENT', newMsg);
  return newMsg;
}

// ---------------------------------------------------------------------
// NOTIFICATIONS
// ---------------------------------------------------------------------
export function getNotifications(userId: string): Notification[] {
  const all = getItem<Notification[]>('notifications', []);
  return all.filter(n => n.recipientId === userId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function createNotification(notif: Omit<Notification, 'id' | 'isRead' | 'createdAt'>): Notification {
  const all = getItem<Notification[]>('notifications', []);
  const newNotif: Notification = {
    ...notif,
    id: 'notif_' + Date.now() + Math.random().toString(36).substring(2, 6),
    isRead: false,
    createdAt: new Date().toISOString()
  };
  all.push(newNotif);
  setItem('notifications', all);
  broadcastEvent('NOTIFICATION_CREATED', newNotif);
  return newNotif;
}

export function markNotificationAsRead(id: string): void {
  const all = getItem<Notification[]>('notifications', []);
  const target = all.find(n => n.id === id);
  if (target) {
    target.isRead = true;
    setItem('notifications', all);
    broadcastEvent('NOTIFICATIONS_UPDATED');
  }
}

export function markAllNotificationsAsRead(userId: string): void {
  const all = getItem<Notification[]>('notifications', []);
  all.forEach(n => {
    if (n.recipientId === userId) n.isRead = true;
  });
  setItem('notifications', all);
  broadcastEvent('NOTIFICATIONS_UPDATED');
}

// ---------------------------------------------------------------------
// SCHEDULE & CALENDAR
// ---------------------------------------------------------------------
export function getTrainingSessions(): TrainingSession[] {
  return getItem<TrainingSession[]>('training_sessions', []);
}

export function createTrainingSession(session: Omit<TrainingSession, 'id' | 'status'>): TrainingSession {
  const all = getTrainingSessions();
  const newSess: TrainingSession = {
    ...session,
    id: 'sess_' + Date.now(),
    status: 'scheduled'
  };
  all.push(newSess);
  setItem('training_sessions', all);

  createNotification({
    recipientId: session.traineeId,
    senderId: session.trainerId,
    title: 'Training Session Scheduled',
    message: `${session.title} on ${session.sessionDate} at ${session.startTime}.`,
    type: 'system'
  });

  broadcastEvent('SESSIONS_UPDATED');
  return newSess;
}

// ---------------------------------------------------------------------
// USERS LIST (Admin Management)
// ---------------------------------------------------------------------
export function getAllUsers(): User[] {
  return getItem<User[]>('users', []);
}

export function deleteUser(userId: string): boolean {
  const users = getAllUsers();
  const filtered = users.filter(u => u.id !== userId);
  if (filtered.length === users.length) return false;

  setItem('users', filtered);
  broadcastEvent('USERS_UPDATED');
  return true;
}
