-- =====================================================================
-- CAPACITY CONNECT — VECTOR STORAGE & SEMANTIC SEARCH
-- Concept: CO2 (Vector Database / pgvector)
-- Purpose: Embeddings for semantic search across Knowledge Hub resources,
--          course descriptions, and intelligent skill matching.
-- =====================================================================

-- CO2: Enable the pgvector extension for high-dimensional vector operations
CREATE EXTENSION IF NOT EXISTS vector;

-- Table to store semantic text embeddings (e.g. OpenAI text-embedding-3-small or Gemini text-embedding-004: 768 / 1536 dims)
CREATE TABLE IF NOT EXISTS resource_embeddings (
    id VARCHAR(64) PRIMARY KEY,
    resource_id VARCHAR(64) NOT NULL,
    title TEXT NOT NULL,
    content_chunk TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    embedding vector(768), -- 768-dimensional vector representation
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- CO2: HNSW Index for ultra-fast approximate nearest neighbor (ANN) cosine distance queries
CREATE INDEX IF NOT EXISTS idx_resource_embeddings_hnsw 
ON resource_embeddings 
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

-- CO2: Example function to perform semantic similarity search against user queries
CREATE OR REPLACE FUNCTION search_knowledge_hub(
    query_embedding vector(768),
    match_threshold float,
    match_count int
)
RETURNS TABLE (
    resource_id VARCHAR(64),
    title TEXT,
    content_chunk TEXT,
    category VARCHAR(100),
    similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        re.resource_id,
        re.title,
        re.content_chunk,
        re.category,
        1 - (re.embedding <=> query_embedding) AS similarity
    FROM resource_embeddings re
    WHERE 1 - (re.embedding <=> query_embedding) > match_threshold
    ORDER BY re.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;
