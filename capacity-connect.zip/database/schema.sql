-- =====================================================================
-- CAPACITY CONNECT — DATABASE DEFINITION
-- Target RDBMS: MySQL 8.0+ / MySQL Workbench
-- Project: Digital Capacity Building & Learning Management Portal
-- Concept: CO1 (Normalized Relational Schema, Constraints, Indexes, CTEs, Window Functions)
-- =====================================================================

DROP DATABASE IF EXISTS capacity_connect_db;
CREATE DATABASE capacity_connect_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE capacity_connect_db;

-- ---------------------------------------------------------------------
-- 1. USERS TABLE (Identity & Authentication)
-- CO1: Primary key, unique constraints, and audit timestamps
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(191) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    primary_role ENUM('trainee', 'trainer', 'admin') NOT NULL DEFAULT 'trainee',
    has_trainee_role BOOLEAN NOT NULL DEFAULT TRUE,
    has_trainer_role BOOLEAN NOT NULL DEFAULT FALSE,
    is_coadmin BOOLEAN NOT NULL DEFAULT FALSE,
    is_master_admin BOOLEAN NOT NULL DEFAULT FALSE,
    avatar_url VARCHAR(500) NULL,
    bio TEXT NULL,
    headline VARCHAR(255) NULL,
    status ENUM('active', 'suspended', 'pending') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (primary_role)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. TRAINER PROFILES (Publicly Viewable to Trainees)
-- CO1: 1-to-1 relationship with foreign key constraint and cascade
-- ---------------------------------------------------------------------
CREATE TABLE trainer_profiles (
    user_id VARCHAR(64) PRIMARY KEY,
    expertise VARCHAR(255) NOT NULL,
    skills JSON NOT NULL, -- Array of skills offered
    subjects JSON NOT NULL, -- Editable subjects/topics
    qualifications TEXT NULL,
    experience_years INT NOT NULL DEFAULT 0,
    certifications TEXT NULL,
    availability VARCHAR(100) DEFAULT 'Flexible / Weekdays & Weekends',
    rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
    total_reviews INT NOT NULL DEFAULT 0,
    is_publicly_visible BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_trainer_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_trainer_expertise (expertise)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. COURSES TABLE
-- CO1: Relational catalog with foreign key to trainer
-- ---------------------------------------------------------------------
CREATE TABLE courses (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    required_skills JSON NOT NULL, -- Array of required skills/competencies with benchmark levels
    difficulty ENUM('Beginner', 'Intermediate', 'Advanced') NOT NULL DEFAULT 'Intermediate',
    duration VARCHAR(50) NOT NULL DEFAULT '4 Weeks',
    thumbnail_url VARCHAR(500) NULL,
    modules JSON NOT NULL, -- Modules, lessons, and learning outcomes
    is_published BOOLEAN NOT NULL DEFAULT TRUE,
    enrolled_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_course_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_courses_published (is_published),
    INDEX idx_courses_trainer (trainer_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. SKILL EXCHANGE & TRAINER REQUESTS
-- CO1: Normalized M-to-N interaction with foreign keys and state constraints
-- ---------------------------------------------------------------------
CREATE TABLE skill_exchange_requests (
    id VARCHAR(64) PRIMARY KEY,
    trainee_id VARCHAR(64) NOT NULL,
    trainer_id VARCHAR(64) NOT NULL,
    course_id VARCHAR(64) NULL,
    learn_skill VARCHAR(150) NOT NULL, -- What trainee wants to learn
    teach_skill VARCHAR(150) NOT NULL, -- What trainee offers in return
    notes TEXT NULL,
    status ENUM('pending', 'accepted', 'declined') NOT NULL DEFAULT 'pending',
    response_note TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_req_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_req_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_req_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    INDEX idx_req_trainee (trainee_id),
    INDEX idx_req_trainer (trainer_id),
    INDEX idx_req_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. COURSE ENROLLMENTS
-- CO1: Enrollment tracking with progress and completion state
-- ---------------------------------------------------------------------
CREATE TABLE course_enrollments (
    id VARCHAR(64) PRIMARY KEY,
    trainee_id VARCHAR(64) NOT NULL,
    course_id VARCHAR(64) NOT NULL,
    progress_percent INT NOT NULL DEFAULT 0,
    status ENUM('active', 'completed', 'dropped') NOT NULL DEFAULT 'active',
    completed_at TIMESTAMP NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_enr_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_enr_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY uk_trainee_course (trainee_id, course_id),
    INDEX idx_enr_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. TRAINEE SKILL COMPETENCIES
-- CO1: Granular skill levels (1 to 5) for dynamic course-specific skill-gap calculations
-- ---------------------------------------------------------------------
CREATE TABLE trainee_competencies (
    id VARCHAR(64) PRIMARY KEY,
    trainee_id VARCHAR(64) NOT NULL,
    skill_name VARCHAR(150) NOT NULL,
    current_level INT NOT NULL DEFAULT 1 CHECK (current_level BETWEEN 1 AND 5),
    verified_by_trainer_id VARCHAR(64) NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_comp_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uk_trainee_skill (trainee_id, skill_name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. ASSESSMENTS TABLE
-- CO1: Created by trainers for specific courses & skill exchange
-- CRITICAL SECURITY: Answer keys stored securely in database, NEVER exposed to trainee before submission
-- ---------------------------------------------------------------------
CREATE TABLE assessments (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) NOT NULL,
    course_id VARCHAR(64) NOT NULL,
    title VARCHAR(200) NOT NULL,
    target_competency VARCHAR(150) NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 20,
    passing_score INT NOT NULL DEFAULT 70,
    questions JSON NOT NULL, -- Contains question, options, points, and SECURE correct_option
    is_published BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ass_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_ass_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_ass_trainer (trainer_id),
    INDEX idx_ass_course (course_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. ASSESSMENT SUBMISSIONS & RESULTS
-- CO1: Submissions evaluated securely by backend
-- ---------------------------------------------------------------------
CREATE TABLE assessment_submissions (
    id VARCHAR(64) PRIMARY KEY,
    assessment_id VARCHAR(64) NOT NULL,
    trainee_id VARCHAR(64) NOT NULL,
    score INT NOT NULL,
    total_marks INT NOT NULL,
    percentage DECIMAL(5,2) NOT NULL,
    passed BOOLEAN NOT NULL,
    answers_submitted JSON NOT NULL,
    ai_feedback TEXT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sub_assessment FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sub_trainee (trainee_id),
    INDEX idx_sub_assessment (assessment_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9. CERTIFICATES TABLE
-- CO1: Issued by trainers when trainees successfully complete qualifying work
-- ---------------------------------------------------------------------
CREATE TABLE certificates (
    id VARCHAR(64) PRIMARY KEY,
    credential_id VARCHAR(50) NOT NULL UNIQUE,
    trainee_id VARCHAR(64) NOT NULL,
    trainer_id VARCHAR(64) NOT NULL,
    course_id VARCHAR(64) NOT NULL,
    course_title VARCHAR(200) NOT NULL,
    skill_acquired VARCHAR(150) NOT NULL,
    issue_date DATE NOT NULL,
    status ENUM('issued', 'revoked') NOT NULL DEFAULT 'issued',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_cert_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cert_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cert_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    INDEX idx_cert_trainee (trainee_id),
    INDEX idx_cert_trainer (trainer_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 10. KNOWLEDGE HUB RESOURCES
-- CO1: Resources uploaded by trainers, moderated/approved by admin
-- ---------------------------------------------------------------------
CREATE TABLE knowledge_resources (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    category VARCHAR(100) NOT NULL,
    file_type ENUM('pdf', 'doc', 'docx', 'image', 'video', 'link') NOT NULL,
    file_url VARCHAR(500) NOT NULL,
    file_size VARCHAR(50) NULL,
    status ENUM('approved', 'pending_review', 'rejected') NOT NULL DEFAULT 'approved',
    downloads_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_res_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_res_category (category),
    INDEX idx_res_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 11. CO-ADMIN REQUESTS (Controlled Admin Access)
-- CO1: Master Admin receives real-time notification to approve/reject
-- ---------------------------------------------------------------------
CREATE TABLE coadmin_requests (
    id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    user_name VARCHAR(150) NOT NULL,
    user_email VARCHAR(191) NOT NULL,
    current_role VARCHAR(50) NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('pending', 'approved', 'declined') NOT NULL DEFAULT 'pending',
    reviewed_by VARCHAR(64) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_coadmin_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_coadmin_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 12. NOTIFICATIONS TABLE
-- CO1: Persistent notifications updated in real time
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    id VARCHAR(64) PRIMARY KEY,
    recipient_id VARCHAR(64) NOT NULL,
    sender_id VARCHAR(64) NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('request_sent', 'request_accepted', 'request_declined', 'assessment_result', 'coadmin_request', 'coadmin_approved', 'cert_issued', 'system') NOT NULL,
    link VARCHAR(255) NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_recipient FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_recipient (recipient_id, is_read)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 13. SCHEDULED SESSIONS (Interactive Calendar)
-- ---------------------------------------------------------------------
CREATE TABLE training_sessions (
    id VARCHAR(64) PRIMARY KEY,
    trainer_id VARCHAR(64) NOT NULL,
    trainee_id VARCHAR(64) NOT NULL,
    course_id VARCHAR(64) NULL,
    title VARCHAR(200) NOT NULL,
    session_date DATE NOT NULL,
    start_time TIME NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 60,
    meeting_link VARCHAR(500) NULL,
    status ENUM('scheduled', 'completed', 'cancelled') NOT NULL DEFAULT 'scheduled',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sess_trainer FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_trainee FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sess_date (session_date)
) ENGINE=InnoDB;

-- =====================================================================
-- CO1 ADVANCED SQL: CTEs, WINDOW FUNCTIONS & ANALYTICS QUERIES
-- =====================================================================

-- CO1: CTE to calculate course-specific skill-gap for enrolled trainees
-- Demonstrates WITH clause (CTE), JOINs, and conditional aggregation
CREATE OR REPLACE VIEW vw_trainee_course_skill_gaps AS
WITH CourseSkills AS (
    SELECT 
        c.id AS course_id,
        c.title AS course_title,
        jt.skill_name,
        jt.required_level
    FROM courses c,
    JSON_TABLE(c.required_skills, '$[*]' COLUMNS (
        skill_name VARCHAR(100) PATH '$.skill',
        required_level INT PATH '$.level'
    )) AS jt
),
TraineeSkillLevels AS (
    SELECT 
        ce.trainee_id,
        ce.course_id,
        cs.course_title,
        cs.skill_name,
        COALESCE(tc.current_level, 0) AS current_level,
        cs.required_level,
        GREATEST(0, cs.required_level - COALESCE(tc.current_level, 0)) AS skill_gap,
        CASE 
            WHEN (cs.required_level - COALESCE(tc.current_level, 0)) >= 3 THEN 'High Priority'
            WHEN (cs.required_level - COALESCE(tc.current_level, 0)) BETWEEN 1 AND 2 THEN 'Medium Priority'
            ELSE 'Proficient'
        END AS gap_priority
    FROM course_enrollments ce
    JOIN CourseSkills cs ON ce.course_id = cs.course_id
    LEFT JOIN trainee_competencies tc ON ce.trainee_id = tc.trainee_id AND cs.skill_name = tc.skill_name
    WHERE ce.status = 'active'
)
SELECT * FROM TraineeSkillLevels;

-- CO1: Window function to rank trainees by assessment performance per course
CREATE OR REPLACE VIEW vw_trainee_assessment_rankings AS
SELECT 
    sub.assessment_id,
    ass.title AS assessment_title,
    ass.course_id,
    sub.trainee_id,
    u.name AS trainee_name,
    sub.score,
    sub.percentage,
    sub.passed,
    -- Window Function: RANK() partitioned by assessment
    RANK() OVER (PARTITION BY sub.assessment_id ORDER BY sub.score DESC) AS trainee_rank,
    -- Window Function: DENSE_RANK() for ties
    DENSE_RANK() OVER (PARTITION BY sub.assessment_id ORDER BY sub.percentage DESC) AS dense_rank,
    -- Window Function: AVG() to show deviation from peer average
    AVG(sub.score) OVER (PARTITION BY sub.assessment_id) AS average_assessment_score
FROM assessment_submissions sub
JOIN assessments ass ON sub.assessment_id = ass.id
JOIN users u ON sub.trainee_id = u.id;

-- ---------------------------------------------------------------------
-- INITIAL SEED: Master Admin K. Gayathri Srivalli
-- Note: Real database starts clean without fake courses or fake users.
-- Only the designated Master Admin is provisioned.
-- ---------------------------------------------------------------------
INSERT INTO users (
    id, name, email, password_hash, primary_role, 
    has_trainee_role, has_trainer_role, is_coadmin, is_master_admin
) VALUES (
    'admin-gayathri-01',
    'K. Gayathri Srivalli',
    'gayathri@gmail.com',
    '$2a$10$e8w6Q01t43iN8h.7y4B7tehG25b87.q6rPzJcK.4Uq3xG8fI.7N2i', -- real bcrypt hash
    'admin',
    TRUE,
    TRUE,
    FALSE,
    TRUE
) ON DUPLICATE KEY UPDATE is_master_admin = TRUE;
