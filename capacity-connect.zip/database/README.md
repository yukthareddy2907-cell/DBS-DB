# Capacity Connect — Database Setup Guide

This directory contains the database definitions for the **CAPACITY CONNECT** enterprise capacity building & learning management system.

## Files Overview

1. **`schema.sql` (CO1: MySQL Relational Schema)**
   - Complete normalized DDL with primary keys, foreign keys, unique constraints, and indexes.
   - Includes CTEs (Common Table Expressions) and SQL Window Functions (`RANK()`, `AVG()`) for analytics.
   - Clean initial state: Starts clean with NO fake data, only the bootstrap Master Admin (`K. Gayathri Srivalli`, `gayathri@gmail.com`).

2. **`mongodb_schema.js` (CO2: MongoDB Document Store)**
   - Specialized document schema for chat messaging, unconstrained conversation logs, and real-time messaging payloads.

3. **`vector_search.sql` (CO2: Vector Database / pgvector)**
   - Semantic embeddings and Cosine distance HNSW indexing for Knowledge Hub recommendations.

## How to Run in MySQL Workbench

1. Open **MySQL Workbench**.
2. Connect to your local or remote MySQL Server instance.
3. Go to **File -> Open SQL Script...** and select `database/schema.sql`.
4. Click the **Execute (Lightning Bolt)** icon.
5. In the Navigator schemas panel, right-click and choose **Refresh All**.
6. The `capacity_connect_db` schema with all 13 normalized tables and views will appear immediately.
