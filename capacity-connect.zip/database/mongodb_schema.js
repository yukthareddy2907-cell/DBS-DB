// =====================================================================
// CAPACITY CONNECT — MONGODB DOCUMENT STORE
// Concept: CO2 (Document Database vs Relational SQL)
// Purpose: MongoDB is chosen specifically for real-time chat messages,
//          unstructured conversation threads, and AI contextual history
//          due to schema flexibility and horizontal write throughput.
// =====================================================================

const { MongoClient } = require('mongodb');

// Connection URI (configured via environment variable in production/Docker)
const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/capacity_connect';

// CO2: Collection validation schema for real-time chat messages
const chatMessageSchema = {
  $jsonSchema: {
    bsonType: "object",
    required: ["requestId", "senderId", "receiverId", "content", "timestamp"],
    properties: {
      _id: { bsonType: "objectId" },
      requestId: {
        bsonType: "string",
        description: "References MySQL skill_exchange_requests.id"
      },
      senderId: {
        bsonType: "string",
        description: "User ID of sender (trainee or trainer)"
      },
      senderName: {
        bsonType: "string"
      },
      receiverId: {
        bsonType: "string",
        description: "User ID of receiver"
      },
      content: {
        bsonType: "string",
        maxLength: 2000,
        description: "Chat message payload"
      },
      attachmentUrl: {
        bsonType: ["string", "null"]
      },
      read: {
        bsonType: "bool"
      },
      timestamp: {
        bsonType: "date"
      }
    }
  }
};

async function initMongoCollections() {
  const client = new MongoClient(MONGO_URI);
  try {
    await client.connect();
    const db = client.db();

    // Create chat_messages collection with schema validation
    await db.createCollection('chat_messages', {
      validator: chatMessageSchema
    });

    // CO2: Compound index for rapid chronological query retrieval per request
    await db.collection('chat_messages').createIndex({ requestId: 1, timestamp: 1 });
    await db.collection('chat_messages').createIndex({ receiverId: 1, read: 1 });

    console.log("CO2: MongoDB chat_messages collection and indexes initialized successfully.");
  } catch (err) {
    console.error("MongoDB init error:", err);
  } finally {
    await client.close();
  }
}

module.exports = { initMongoCollections };
