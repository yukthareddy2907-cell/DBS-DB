# CAPACITY CONNECT — Course Outcome (CO1 - CO6) Technical Mapping

This document provides the formal architectural and code mapping for the six engineering course outcomes implemented in the **CAPACITY CONNECT** digital capacity building and learning management platform.

---

### CO1: Advanced Relational Database Design, SQL Normalization, Transactions & Analytical Queries
- **Normalized Schema**: Implemented in `/database/schema.sql`. Includes 3NF/BCNF relational tables (`users`, `trainer_profiles`, `courses`, `skill_exchange_requests`, `course_enrollments`, `assessments`, `assessment_submissions`, `certificates`, `knowledge_resources`, `coadmin_requests`, `notifications`).
- **Primary & Foreign Key Constraints**: Strict cascading and nullifying constraints (`ON DELETE CASCADE`, `ON DELETE SET NULL`) ensuring referential integrity.
- **Indexes**: Composite and single-column indexes on high-cardinality query columns (`email`, `status`, `trainer_id`, `trainee_id`).
- **Common Table Expressions (CTE)**: `vw_trainee_course_skill_gaps` utilizes recursive/multistage `WITH` clauses joining dynamic course skill benchmarks with trainee competency records.
- **Window Functions**: `vw_trainee_assessment_rankings` calculates analytical ranking across peer submissions using `RANK() OVER (PARTITION BY assessment_id ORDER BY score DESC)` and `AVG() OVER ()` for benchmarking.
- **Code Comments**: Marked throughout `/database/schema.sql` and `/src/services/db.ts`.

---

### CO2: Polyglot Persistence, NoSQL Document Storage & Vector Semantic Search
- **SQL vs Document Store Decision**: Relational MySQL is selected for ACID transactional entities (enrollments, user access control, certificates), while MongoDB is selected for high-frequency, variable-schema chat messages and conversational threads (`/database/mongodb_schema.js`).
- **Vector Database (pgvector)**: Configured in `/database/vector_search.sql` using 768-dimensional embeddings and HNSW (Hierarchical Navigable Small World) index for sub-millisecond cosine distance approximate nearest neighbor (`ANN`) search across Knowledge Hub resources and skill recommendations.
- **Code Comments**: Marked in `/database/mongodb_schema.js` and `/database/vector_search.sql`.

---

### CO3: Modern RESTful Microservices with FastAPI, Pydantic & Dependency Injection
- **FastAPI Microservice**: Located in `/backend/fastapi/main.py`.
- **Pydantic Validation**: Strict type checking and request validation models (`CourseSkillGapRequest`, `CourseSkillGapResponse`, `SkillGapItem`).
- **Dependency Injection**: Reusable `verify_jwt_token` dependency injected into protected analytic endpoints.
- **Dynamic Course-Specific Skill Gap**: Accurately computes trainee competency gaps relative to specific enrolled course objectives rather than generic job roles.
- **Automated OpenAPI / Swagger**: Built-in interactive documentation available at `/docs`.
- **Code Comments**: Marked in `/backend/fastapi/main.py`.

---

### CO4: Multi-Language Backend Architecture (Node.js/Express & Java Spring Boot)
- **Node.js / Express**: Acts as the real-time API gateway and Server-Sent Events (SSE) broadcaster in `/server.ts` and `/src/services/api.ts`.
- **Java Spring Boot**: Implements enterprise business logic for trainer approvals, assessment dispatching, and transaction management in `/backend/spring-boot/`.
- **Code Comments**: Explicitly placed in `/server.ts` and `/backend/spring-boot/src/main/java/com/capacityconnect/`.

---

### CO5: Distributed Systems, Bounded Contexts & Event-Driven Messaging (Kafka)
- **Bounded Contexts**: Clean separation of domains:
  1. *Identity & Admin Context*
  2. *Trainer & Skill Exchange Context*
  3. *Course & Learning Context*
  4. *Assessment & Evaluation Context*
  5. *Notification & Real-Time Context*
- **Asynchronous Kafka Events**: Spring Boot Kafka producer (`KafkaProducerService.java`) emits events including `TrainerRequestCreated`, `TrainerRequestAccepted`, `AssessmentSubmitted`, and `CertificationIssued`.
- **Real-Time Synchronization**: Live event streams notify connected clients immediately when states transition from `pending` to `accepted` or `declined`.
- **Code Comments**: Documented in `KafkaProducerService.java` and `server.ts`.

---

### CO6: DevOps, Containerization, Portability & C4 Architecture
- **Dockerization**: Independent container definitions for MySQL, MongoDB, Kafka, FastAPI, Spring Boot, and Web client orchestrated in `/backend/docker-compose.yml`.
- **Multi-Stage Build**: Dockerfile optimizes production image footprint using lightweight Alpine base images (`/backend/Dockerfile`).
- **Portability**: Complete decoupling from host paths (no hardcoded Windows/D-drive assumptions), purely configured via environment variables.
- **CI/CD Pipeline Definition**: Automated workflow for linting, testing, and container verification in `.github/workflows/ci-cd.yml`.
