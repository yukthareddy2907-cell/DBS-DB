package com.capacityconnect;

// CO4: Spring Boot enterprise service implementing the Trainer and Assessment bounded context
// CO5: Microservice configured for independent containerized deployment

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapacityConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(CapacityConnectApplication.class, args);
    }
}
