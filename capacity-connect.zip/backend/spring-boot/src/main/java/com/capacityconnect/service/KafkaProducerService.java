package com.capacityconnect.service;

// CO5: Apache Kafka message producer for asynchronous event streaming
// Ensures zero coupling between Assessment/Trainer service and Notification service

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class KafkaProducerService {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public KafkaProducerService(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishEvent(String topic, Map<String, Object> eventData) {
        // CO5: Asynchronous event publication across distributed microservices
        this.kafkaTemplate.send(topic, eventData);
    }
}
