package com.capacityconnect.controller;

// CO4: REST controller exposing enterprise endpoints for trainer profile & request management
// CO5: Dispatches asynchronous events to Apache Kafka message broker

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/v1/trainers")
@CrossOrigin(origins = "*")
public class TrainerController {

    // CO5: Kafka Event Publisher for decoupled service messaging
    private final com.capacityconnect.service.KafkaProducerService kafkaProducerService;

    public TrainerController(com.capacityconnect.service.KafkaProducerService kafkaProducerService) {
        this.kafkaProducerService = kafkaProducerService;
    }

    // CO4: Endpoint to accept or decline trainee skill-exchange request
    @PatchMapping("/requests/{requestId}/status")
    public ResponseEntity<Map<String, Object>> updateRequestStatus(
            @PathVariable String requestId,
            @RequestBody Map<String, String> payload) {
        
        String newStatus = payload.get("status"); // "accepted" or "declined"
        
        // CO5: Publish asynchronous event to Kafka topic for Notification & Chat services
        if ("accepted".equalsIgnoreCase(newStatus)) {
            kafkaProducerService.publishEvent("TrainerRequestAccepted", Map.of(
                "requestId", requestId,
                "timestamp", System.currentTimeMillis()
            ));
        } else {
            kafkaProducerService.publishEvent("TrainerRequestDeclined", Map.of(
                "requestId", requestId,
                "timestamp", System.currentTimeMillis()
            ));
        }

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("requestId", requestId);
        response.put("status", newStatus);
        return ResponseEntity.ok(response);
    }
}
