# CAPACITY CONNECT — Frontend Web Application
Minimal White + Blue Enterprise UI for Capacity Building & Competency Exchange.

## Architecture & Features

- **Public Landing Page**: Minimalist hero with tagline *"Empowering People, Skills & Organizational Growth"*.
- **Role System**: Supports Trainee, Trainer, and Both roles with instant in-session role switching.
- **Dynamic Course-Specific Skill-Gap Detection**: Compares trainee competency directly against the enrolled course curriculum.
- **Trainer Matching & Reciprocal Skill Exchange**: Real-time request synchronization (`Pending` -> `Accepted` / `Declined`).
- **Secure Assessments**: Only accessible from approved trainers. Correct answers evaluated securely on the backend.
- **Verifiable PDF Certificates**: Minimalist, high-quality certificates generated on demand via jsPDF.
- **Controlled Master Administration**: Master Admin `K. Gayathri Srivalli` (`gayathri@gmail.com`) oversees users, courses, assessments, and approves/rejects Co-Admin requests in real time.

## Running Locally

\`\`\`bash
npm install
npm run dev
\`\`\`
