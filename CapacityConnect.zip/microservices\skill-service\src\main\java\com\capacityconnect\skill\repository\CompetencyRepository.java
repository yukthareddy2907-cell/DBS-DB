package com.capacityconnect.skill.repository;

import com.capacityconnect.skill.model.Competency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Repository for Competency Framework
 * =============================================================================
 */
@Repository
public interface CompetencyRepository extends JpaRepository<Competency, Long> {
    Optional<Competency> findByName(String name);
    boolean existsByName(String name);
}
