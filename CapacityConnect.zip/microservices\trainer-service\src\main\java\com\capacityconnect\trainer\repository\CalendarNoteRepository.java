package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.CalendarNote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CalendarNoteRepository extends JpaRepository<CalendarNote, Long> {
    Optional<CalendarNote> findByUserId(Long userId);
}
