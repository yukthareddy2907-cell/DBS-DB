package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.CalendarNote;
import com.capacityconnect.trainer.model.ChatMessage;
import com.capacityconnect.trainer.model.TrainingSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findByExchangeIdOrderBySentAtAsc(Long exchangeId);
}
