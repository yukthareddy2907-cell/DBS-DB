package com.capacityconnect.trainer.controller;

import com.capacityconnect.trainer.model.TrainerProfile;
import com.capacityconnect.trainer.service.TrainerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] REST Controller for Trainer Management
 * [CO5] Matching Endpoint for Inter-Service REST Calls from Skill Service
 * =============================================================================
 */
@RestController
@RequestMapping("/trainers")
public class TrainerController {

    private final TrainerService trainerService;

    @Autowired
    public TrainerController(TrainerService trainerService) {
        this.trainerService = trainerService;
    }

    @GetMapping
    public ResponseEntity<List<TrainerProfile>> getAllTrainers() {
        return ResponseEntity.ok(trainerService.getAllTrainers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTrainerById(@PathVariable Long id) {
        return trainerService.getTrainerById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * [CO5] GET /api/trainers/match?skills=SQL,Power%20BI
     */
    @GetMapping("/match")
    public ResponseEntity<List<Map<String, Object>>> matchTrainers(
            @RequestParam(required = false) String skills) {
        List<String> skillList = (skills != null && !skills.isBlank())
                ? Arrays.asList(skills.split(","))
                : Collections.emptyList();

        return ResponseEntity.ok(trainerService.matchTrainersForSkills(skillList));
    }
}
