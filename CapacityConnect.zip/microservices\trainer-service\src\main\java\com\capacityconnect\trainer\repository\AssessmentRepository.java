package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.Assessment;
import com.capacityconnect.trainer.model.AssessmentSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] JPA Repositories for Assessments & Submissions
 * =============================================================================
 */
@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, Long> {
    List<Assessment> findBySkillName(String skillName);
    List<Assessment> findByTrainerId(Long trainerId);
}
