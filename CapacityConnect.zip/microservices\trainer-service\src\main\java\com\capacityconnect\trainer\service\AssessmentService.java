package com.capacityconnect.trainer.service;

import com.capacityconnect.trainer.dto.TrainerDtos.*;
import com.capacityconnect.trainer.model.*;
import com.capacityconnect.trainer.repository.AssessmentQuestionRepository;
import com.capacityconnect.trainer.repository.AssessmentRepository;
import com.capacityconnect.trainer.repository.AssessmentSubmissionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * =============================================================================
 * [CO1] Transactional Assessment Management & Auto-Evaluation Engine
 * [CO2] Document/JSON Persistence for Question-by-Question Review Breakdown
 * [CO3] Instant AI Evaluation Pipeline with Score Validation
 * =============================================================================
 */
@Service
public class AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final AssessmentQuestionRepository questionRepository;
    private final AssessmentSubmissionRepository submissionRepository;
    private final ObjectMapper objectMapper;

    @Autowired
    public AssessmentService(AssessmentRepository assessmentRepository,
                             AssessmentQuestionRepository questionRepository,
                             AssessmentSubmissionRepository submissionRepository) {
        this.assessmentRepository = assessmentRepository;
        this.questionRepository = questionRepository;
        this.submissionRepository = submissionRepository;
        this.objectMapper = new ObjectMapper();
    }

    public List<Assessment> getAllAssessments() {
        return assessmentRepository.findAll();
    }

    public Optional<Assessment> getAssessmentById(Long id) {
        return assessmentRepository.findById(id);
    }

    public List<Assessment> getAssessmentsByTrainerId(Long trainerId) {
        return assessmentRepository.findByTrainerId(trainerId);
    }

    /**
     * [CO1] Trainer Creates New Assessment with Questions & Secret Server-Side Answer Key
     */
    @Transactional
    public Assessment createAssessment(CreateAssessmentRequest request) {
        Assessment assessment = Assessment.builder()
                .trainerId(request.getTrainerId() != null ? request.getTrainerId() : 2L)
                .title(request.getTitle())
                .skillName(request.getSkillName())
                .targetRole(request.getTargetRole() != null ? request.getTargetRole() : "Data Analyst")
                .durationMinutes(request.getDurationMinutes() > 0 ? request.getDurationMinutes() : 20)
                .passingScore(request.getPassingScore() > 0 ? request.getPassingScore() : 75)
                .targetProficiency(request.getTargetProficiency() > 0 ? request.getTargetProficiency() : 3)
                .build();

        if (request.getQuestions() != null && !request.getQuestions().isEmpty()) {
            for (QuestionDto qDto : request.getQuestions()) {
                AssessmentQuestion q = AssessmentQuestion.builder()
                        .assessment(assessment)
                        .questionText(qDto.getQuestionText())
                        .optionA(qDto.getOptionA())
                        .optionB(qDto.getOptionB())
                        .optionC(qDto.getOptionC())
                        .optionD(qDto.getOptionD())
                        .correctOption(qDto.getCorrectOption() != null ? qDto.getCorrectOption().toUpperCase() : "A")
                        .explanation(qDto.getExplanation() != null ? qDto.getExplanation() : "Correct concept applied.")
                        .build();
                assessment.getQuestions().add(q);
            }
        }

        return assessmentRepository.save(assessment);
    }

    /**
     * [CO1/CO2/CO3] Real Trainee Exam Submission: Instant Server Evaluation & Question-by-Question Breakdown
     */
    @Transactional
    public AssessmentEvaluationResult evaluateSubmission(SubmitAssessmentRequest request) {
        Assessment assessment = assessmentRepository.findById(request.getAssessmentId())
                .orElseThrow(() -> new IllegalArgumentException("Assessment with ID " + request.getAssessmentId() + " not found."));

        List<AssessmentQuestion> questions = assessment.getQuestions();
        if (questions.isEmpty()) {
            questions = questionRepository.findByAssessmentId(assessment.getId());
        }

        int totalQuestions = questions.size();
        int correctCount = 0;
        List<QuestionReviewItem> reviewItems = new ArrayList<>();
        Map<Long, String> selected = (request.getSelectedAnswers() != null) ? request.getSelectedAnswers() : Collections.emptyMap();

        for (AssessmentQuestion q : questions) {
            String selectedOpt = selected.getOrDefault(q.getId(), "Unanswered");
            boolean isCorrect = q.getCorrectOption().equalsIgnoreCase(selectedOpt.trim());

            if (isCorrect) {
                correctCount++;
            }

            reviewItems.add(QuestionReviewItem.builder()
                    .questionId(q.getId())
                    .questionText(q.getQuestionText())
                    .selectedOption(selectedOpt)
                    .correctOption(q.getCorrectOption())
                    .isCorrect(isCorrect)
                    .explanation(q.getExplanation())
                    .build());
        }

        double scorePercentage = (totalQuestions > 0) ? ((double) correctCount / totalQuestions) * 100.0 : 0.0;
        boolean passed = scorePercentage >= assessment.getPassingScore();
        int newProficiencyLevel = passed ? assessment.getTargetProficiency() : 2;

        String aiNotes = generateAiEvaluationNotes(assessment.getSkillName(), scorePercentage, passed, correctCount, totalQuestions);

        // [CO2] Serialize Question Breakdown to JSON Document
        String breakdownJson = "[]";
        try {
            breakdownJson = objectMapper.writeValueAsString(reviewItems);
        } catch (Exception e) {
            breakdownJson = "[]";
        }

        AssessmentSubmission submission = AssessmentSubmission.builder()
                .assessment(assessment)
                .userId(request.getUserId())
                .userName(request.getUserName() != null ? request.getUserName() : "Rahul Kumar")
                .scorePercentage(Math.round(scorePercentage * 100.0) / 100.0)
                .passed(passed)
                .totalQuestions(totalQuestions)
                .correctCount(correctCount)
                .detailedBreakdownJson(breakdownJson)
                .aiEvaluationNotes(aiNotes)
                .build();

        AssessmentSubmission saved = submissionRepository.save(submission);

        return AssessmentEvaluationResult.builder()
                .submissionId(saved.getId())
                .assessmentId(assessment.getId())
                .assessmentTitle(assessment.getTitle())
                .skillName(assessment.getSkillName())
                .scorePercentage(scorePercentage)
                .passed(passed)
                .correctCount(correctCount)
                .totalQuestions(totalQuestions)
                .newProficiencyLevel(newProficiencyLevel)
                .questionReviews(reviewItems)
                .aiEvaluationNotes(aiNotes)
                .build();
    }

    public List<AssessmentSubmission> getSubmissionsByUserId(Long userId) {
        return submissionRepository.findByUserIdOrderBySubmittedAtDesc(userId);
    }

    public List<AssessmentSubmission> getSubmissionsForTrainer(Long trainerId) {
        return submissionRepository.findByAssessmentTrainerIdOrderBySubmittedAtDesc(trainerId);
    }

    private String generateAiEvaluationNotes(String skill, double score, boolean passed, int correct, int total) {
        if (passed) {
            return "Exceptional performance in " + skill + "! You answered " + correct + "/" + total 
                    + " questions correctly (" + Math.round(score) + "%). Your demonstrated mastery qualifies you for an upgrade to the next competency tier.";
        } else {
            return "Good diagnostic attempt in " + skill + " (" + Math.round(score) 
                    + "% score). Review the incorrect question explanations above, focus on practical query/modeling exercises, and retake the assessment to elevate your competency level.";
        }
    }
}
