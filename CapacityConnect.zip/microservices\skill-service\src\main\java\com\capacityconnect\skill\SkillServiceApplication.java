package com.capacityconnect.skill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * =============================================================================
 * CAPACITY CONNECT — SKILL & AI COMPETENCY ENGINE MICROSERVICE
 * =============================================================================
 * Course Outcomes Mapped:
 * [CO4] Develop backend services using Spring Boot through project-driven delivery.
 * [CO5] Decompose monolithic system into independently deployable microservices;
 *       implement inter-service communication via REST (Skill Service -> Trainer Service).
 * =============================================================================
 */
@SpringBootApplication
public class SkillServiceApplication {

    public static void main(String[] args) {
        System.out.println(">>> [CO4/CO5] Starting CAPACITY CONNECT - Skill & Competency Microservice on Port 8082...");
        SpringApplication.run(SkillServiceApplication.class, args);
        System.out.println(">>> [CO4/CO5] Skill Microservice is LIVE at http://localhost:8082/api");
    }
}
