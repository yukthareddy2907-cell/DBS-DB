/**
 * ============================================================================
 * CAPACITY CONNECT — AI-POWERED ORGANIZATIONAL CAPACITY BUILDING PLATFORM
 * Master Admin: K. GAYATHRI SRIVALLI (gayathri@gmail.com)
 * ============================================================================
 */

// Persistent Storage Key
const STORAGE_KEY = "CAPACITY_CONNECT_STORE_V3";

function loadSavedState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn("Storage load error:", e);
  }
  return null;
}

function saveStateToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      currentUser: state.currentUser,
      allUsers: state.allUsers,
      trainers: state.trainers,
      courses: state.courses,
      knowledgeResources: state.knowledgeResources,
      assessments: state.assessments,
      assessmentSubmissions: state.assessmentSubmissions,
      skillExchangeRequests: state.skillExchangeRequests,
      chatMessages: state.chatMessages,
      trainingSessions: state.trainingSessions,
      certificates: state.certificates,
      notesList: state.notesList,
      notifications: state.notifications,
      userCompetencies: state.userCompetencies,
      competencyHistory: state.competencyHistory,
      coAdminRequests: state.coAdminRequests
    }));
  } catch (e) {
    console.warn("Storage save error:", e);
  }
}

// Default Master Admin User
const masterAdminUser = {
  id: 101,
  fullName: "K. GAYATHRI SRIVALLI",
  email: "gayathri@gmail.com",
  primaryRole: "ADMIN",
  activeRole: "ADMIN",
  isMasterAdmin: true,
  isCoAdmin: false,
  isAdmin: true,
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
  bio: "Master System Administrator & Chief Learning Architect for CAPACITY CONNECT.",
  careerScore: 92,
  streak: 5,
  learningProgress: 88
};

const defaultSaved = loadSavedState();

const state = {
  currentUser: defaultSaved ? defaultSaved.currentUser : masterAdminUser,
  currentView: "landing",
  currentTab: "overview", // "overview" | "skill-gap" | "trainers" | "assessments" | "calendar" | "knowledge-hub" | "certificates"
  chatActiveExchangeId: null,
  currentAssessment: null,
  cmdSelectedIdx: 0,
  
  // Clean Data Stores
  allUsers: defaultSaved ? defaultSaved.allUsers : [
    { id: 101, fullName: "K. GAYATHRI SRIVALLI", email: "gayathri@gmail.com", role: "ADMIN", isMasterAdmin: true, isCoAdmin: false }
  ],
  trainers: defaultSaved ? defaultSaved.trainers : [],
  courses: defaultSaved ? defaultSaved.courses : [],
  knowledgeResources: defaultSaved ? defaultSaved.knowledgeResources : [],
  assessments: defaultSaved ? defaultSaved.assessments : [],
  assessmentSubmissions: defaultSaved ? defaultSaved.assessmentSubmissions : [],
  skillExchangeRequests: defaultSaved ? defaultSaved.skillExchangeRequests : [],
  chatMessages: defaultSaved ? defaultSaved.chatMessages : [],
  trainingSessions: defaultSaved ? defaultSaved.trainingSessions : [],
  certificates: defaultSaved ? defaultSaved.certificates : [],
  notesList: defaultSaved ? defaultSaved.notesList : [
    { id: 1, text: "Welcome K. GAYATHRI SRIVALLI! Master Admin governance console is active." }
  ],
  notifications: defaultSaved ? defaultSaved.notifications : [
    { id: 1, type: "success", title: "Master Admin Initialized", desc: "K. GAYATHRI SRIVALLI (gayathri@gmail.com) is active as Primary Admin.", time: "Just now", read: false }
  ],
  userCompetencies: defaultSaved ? defaultSaved.userCompetencies : [],
  competencyHistory: defaultSaved ? defaultSaved.competencyHistory : [],
  coAdminRequests: defaultSaved ? defaultSaved.coAdminRequests : [],

  // Benchmark Competencies (1 to 5 scale)
  benchmarkCompetencies: [
    { skill: "SQL", required: 4, category: "Database & Querying", weight: 1.30, importance: "HIGH" },
    { skill: "Python", required: 3, category: "Programming & Scripting", weight: 1.00, importance: "MEDIUM" },
    { skill: "Statistics", required: 4, category: "Mathematics & Analytics", weight: 1.25, importance: "HIGH" },
    { skill: "Excel", required: 4, category: "Spreadsheets & Modeling", weight: 1.10, importance: "HIGH" },
    { skill: "Power BI", required: 3, category: "Business Intelligence", weight: 1.20, importance: "HIGH" },
    { skill: "Data Visualization", required: 3, category: "Storytelling & UX", weight: 1.00, importance: "MEDIUM" }
  ]
};

// ============================================================================
// REAL-TIME NOTIFICATIONS ENGINE
// ============================================================================
function triggerRealtimeNotification(title, desc, type = "normal") {
  const newNotif = {
    id: Date.now(),
    type: type,
    title: title,
    desc: desc,
    time: "Just now",
    read: false
  };

  state.notifications.unshift(newNotif);
  renderNavigation();
  showToast(`${title} — ${desc}`, type === "alert" ? "normal" : "success");
  saveStateToStorage();
}

// ============================================================================
// DETERMINISTIC SKILL-GAP ENGINE
// ============================================================================
function calculateSkillGapEngine() {
  const requiredList = state.benchmarkCompetencies;
  let totalWeightedCurrent = 0;
  let totalWeightedRequired = 0;
  let totalGapsCount = 0;
  
  const items = requiredList.map(req => {
    const userComp = state.userCompetencies.find(uc => uc.skill.toLowerCase() === req.skill.toLowerCase());
    const current = userComp ? Number(userComp.current) : 1;
    const required = req.required;
    const gap = Math.max(0, required - current);
    
    let severity = "Meets Requirement";
    let priority = "LOW";
    
    if (gap === 1) {
      severity = "Low";
      priority = req.importance === "HIGH" ? "MEDIUM" : "LOW";
      totalGapsCount++;
    } else if (gap === 2) {
      severity = "Moderate";
      priority = req.importance === "LOW" ? "MEDIUM" : "HIGH";
      totalGapsCount++;
    } else if (gap >= 3) {
      severity = "Critical";
      priority = "HIGH";
      totalGapsCount++;
    }
    
    totalWeightedCurrent += Math.min(current, required) * req.weight;
    totalWeightedRequired += required * req.weight;
    
    const evidence = userComp ? userComp.evidence : "Self-Reported / Baseline";
    const reason = `${req.skill} is currently at Level ${current}/5 (benchmark requires Level ${required}/5). Focus on targeted practice to bridge this ${gap}-level gap.`;
    const action = `Study core principles of ${req.skill}, complete practical exercises in Knowledge Hub, and practice with a mentor.`;
    
    return {
      skill: req.skill,
      category: req.category,
      current: current,
      required: required,
      gap: gap,
      severity: severity,
      priority: priority,
      weight: req.weight,
      importance: req.importance,
      evidence: evidence,
      reason: reason,
      recommendedAction: action,
      estimatedImprovement: `+${gap * 15 + 5}% benchmark readiness`
    };
  });
  
  const overallReadiness = totalWeightedRequired > 0 
    ? Math.round((totalWeightedCurrent / totalWeightedRequired) * 100) 
    : 20;
  
  items.sort((a, b) => {
    const pWeight = { HIGH: 3, MEDIUM: 2, LOW: 1 };
    if (pWeight[b.priority] !== pWeight[a.priority]) {
      return pWeight[b.priority] - pWeight[a.priority];
    }
    return b.gap - a.gap;
  });
  
  const priorityGaps = items.filter(i => i.gap > 0).slice(0, 3);
  if (state.currentUser) {
    state.currentUser.careerScore = overallReadiness;
  }
  
  return {
    overallReadiness: overallReadiness,
    totalGapsCount: totalGapsCount,
    items: items,
    priorityGaps: priorityGaps,
    explainableSummary: priorityGaps.length === 0
      ? "Outstanding! You meet 100% of the required competency benchmarks. Maintain your skills through continuous practice."
      : `Your overall organizational competency readiness is ${overallReadiness}%. Focus on high-priority areas in ${priorityGaps.map(g => g.skill).join(", ")}.`
  };
}

// ============================================================================
// NAVIGATION & HEADER
// ============================================================================
function renderNavigation() {
  const navContainer = document.getElementById("navbar-container");
  if (!navContainer) return;

  const isAuth = !!state.currentUser;
  const unreadCount = state.notifications.filter(n => !n.read).length;

  navContainer.innerHTML = `
    <nav class="navbar">
      <div class="logo-container" onclick="handleLogoClick()">
        <div class="logo-icon">C</div>
        <div class="logo-text">
          <span class="cap">CAPACITY</span> <span class="con">CONNECT</span>
        </div>
      </div>

      ${isAuth ? `
        <!-- Minimal Header Search & Multi-Role Switcher -->
        <div style="display:flex; align-items:center; gap:1.25rem;">
          <div class="nav-cmd-trigger" onclick="toggleCmdPalette()">
            <span>🔍 Search capabilities, mentors, courses...</span>
            <span class="kbd-shortcut">⌘K</span>
          </div>

          <div class="role-switcher-pill">
            <button class="role-tab-btn ${state.currentUser.activeRole === 'TRAINEE' ? 'active' : ''}" onclick="switchActiveRole('TRAINEE')">
              🎓 Trainee
            </button>
            <button class="role-tab-btn ${state.currentUser.activeRole === 'TRAINER' ? 'active' : ''}" onclick="switchActiveRole('TRAINER')">
              👨‍🏫 Trainer
            </button>
            <button class="role-tab-btn ${state.currentUser.activeRole === 'ADMIN' ? 'active' : ''}" onclick="handleAdminRoleSwitch()">
              🛡️ Admin
            </button>
          </div>
        </div>
      ` : `
        <div style="font-size:0.88rem; font-weight:600; color:var(--slate-500);">
          Digital Organizational Capacity Building & Skill Intelligence
        </div>
      `}

      <div class="nav-actions">
        ${isAuth ? `
          <div class="nav-cmd-trigger" style="padding:0.45rem 0.75rem; cursor:pointer;" onclick="toggleNotifPopover()" title="Real-Time Notifications">
            <span>🔔</span>
            ${unreadCount > 0 ? `<span style="background:var(--rose); color:#fff; font-size:0.7rem; font-weight:800; border-radius:10px; padding:0.1rem 0.4rem; margin-left:0.2rem;">${unreadCount}</span>` : ''}
          </div>

          <div class="user-profile-badge" onclick="openProfileModal()" title="Edit Profile, Skills & Photo">
            <img src="${state.currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" alt="${state.currentUser.fullName}" class="user-avatar" id="nav-user-avatar">
            <span class="user-name-small">${state.currentUser.fullName}</span>
            <span style="font-size:0.75rem; color:var(--slate-400); font-weight:700;">▾</span>
          </div>
        ` : `
          <button class="btn-primary" onclick="openAuthModal('signup')">
            Create Your Account
          </button>
        `}
      </div>
    </nav>
  `;
}

function handleLogoClick() {
  if (!state.currentUser) {
    showView("landing");
  } else {
    state.currentTab = "overview";
    showView(state.currentUser.activeRole.toLowerCase());
  }
}

function showView(viewName) {
  state.currentView = viewName;
  state.currentTab = "overview";
  renderNavigation();

  const appContainer = document.getElementById("app-container");
  if (!appContainer) return;

  if (viewName === "landing" || !state.currentUser) {
    renderLandingView(appContainer);
  } else if (viewName === "trainee") {
    state.currentUser.activeRole = "TRAINEE";
    renderNavigation();
    renderTraineeDashboard(appContainer);
  } else if (viewName === "trainer") {
    state.currentUser.activeRole = "TRAINER";
    renderNavigation();
    renderTrainerDashboard(appContainer);
  } else if (viewName === "admin") {
    state.currentUser.activeRole = "ADMIN";
    renderNavigation();
    renderAdminDashboard(appContainer);
  }
  saveStateToStorage();
}

function switchActiveRole(newRole) {
  if (!state.currentUser) {
    openAuthModal('signup');
    return;
  }
  state.currentUser.activeRole = newRole;
  state.currentTab = "overview";
  showToast(`Switched to ${newRole} Dashboard`, "normal");
  showView(newRole.toLowerCase());
}

function handleAdminRoleSwitch() {
  if (!state.currentUser) {
    openAuthModal('signup');
    return;
  }

  const isGayathri = state.currentUser.email.toLowerCase() === "gayathri@gmail.com";
  const isMaster = state.currentUser.isMasterAdmin || isGayathri;
  const isCoAdmin = state.currentUser.isCoAdmin;
  const isPrimaryRoleAdmin = state.currentUser.primaryRole === "ADMIN";

  if (isMaster || isCoAdmin || isPrimaryRoleAdmin) {
    switchActiveRole("ADMIN");
  } else {
    openRequestCoAdminModal();
  }
}

function openRequestCoAdminModal() {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem; text-align:center;">
      <div style="font-size:2.5rem; margin-bottom:0.5rem;">🛡️</div>
      <h3 style="font-size:1.4rem; color:var(--slate-900);">Admin Access Control</h3>
      <p style="font-size:0.88rem; color:var(--slate-600); margin-top:0.3rem;">
        The Master Admin for this platform is <strong>K. GAYATHRI SRIVALLI (gayathri@gmail.com)</strong>.
      </p>
    </div>

    <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1.25rem; margin-bottom:1.5rem;">
      <h4 style="font-size:0.95rem; margin-bottom:0.4rem; color:var(--slate-900);">Co-Admin Authorization Flow:</h4>
      <p style="font-size:0.85rem; color:var(--slate-700); line-height:1.5; margin-bottom:0.75rem;">
        1. Click below to request Co-Admin authorization.<br>
        2. A secure <strong>4-digit code</strong> will appear in K. GAYATHRI SRIVALLI's User Management dashboard.<br>
        3. Enter the 4-digit code provided by K. GAYATHRI SRIVALLI to unlock Co-Admin privileges.
      </p>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:center;">
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn-primary" onclick="generateCoAdminRequestForCurrentUser()">
        Request Co-Admin Authorization Code ➔
      </button>
    </div>
  `);
}

function generateCoAdminRequestForCurrentUser() {
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  const req = {
    id: Date.now(),
    userId: state.currentUser.id,
    fullName: state.currentUser.fullName,
    email: state.currentUser.email,
    code: code,
    status: "PENDING",
    requestedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  state.coAdminRequests = state.coAdminRequests.filter(r => r.userId !== state.currentUser.id);
  state.coAdminRequests.unshift(req);

  // Store notification for Master Admin
  state.notifications.unshift({
    id: Date.now(),
    type: "alert",
    title: "New Co-Admin Request",
    desc: `${state.currentUser.fullName} (${state.currentUser.email}) requested Co-Admin access (PIN: ${code})`,
    time: "Just now",
    read: false
  });

  // User gets confirmation toast without revealing the PIN
  showToast("Co-Admin request sent! Ask Master Admin K. GAYATHRI SRIVALLI for your 4-digit approval code.", "normal");

  openCoAdminPinEntryModal(req.id, code);
  saveStateToStorage();
}

function openCoAdminPinEntryModal(reqId, expectedCode) {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem; text-align:center;">
      <div style="font-size:2.2rem; margin-bottom:0.3rem;">🔑</div>
      <h3 style="font-size:1.35rem;">Enter 4-Digit Co-Admin Code</h3>
      <p style="font-size:0.85rem; color:var(--slate-600); margin-top:0.25rem;">
        Ask Master Admin <strong>K. GAYATHRI SRIVALLI</strong> for the 4-digit code generated in her User Management panel.
      </p>
    </div>

    <form onsubmit="handleVerifyCoAdminPin(event, ${reqId}, '${expectedCode}')">
      <div style="margin-bottom:1.5rem; text-align:center;">
        <label style="font-size:0.85rem; font-weight:700; display:block; margin-bottom:0.75rem;">4-Digit Authorization Code</label>
        <input type="text" id="coadmin-pin-input" maxlength="4" pattern="[0-9]{4}" required class="chat-input-field" style="width:200px; font-size:1.8rem; font-weight:800; letter-spacing:0.5em; text-align:center; font-family:var(--font-mono);" placeholder="••••" autofocus>
      </div>

      <div style="display:flex; justify-content:space-between; align-items:center;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">Verify & Unlock Admin Dashboard ➔</button>
      </div>
    </form>
  `);
}

function handleVerifyCoAdminPin(e, reqId, expectedCode) {
  e.preventDefault();
  const inputPin = document.getElementById("coadmin-pin-input").value.trim();

  if (inputPin === expectedCode) {
    const req = state.coAdminRequests.find(r => r.id === reqId);
    if (req) req.status = "APPROVED";

    state.currentUser.isCoAdmin = true;
    state.currentUser.isAdmin = true;
    state.currentUser.activeRole = "ADMIN";

    const userRecord = state.allUsers.find(u => u.id === state.currentUser.id);
    if (userRecord) {
      userRecord.isCoAdmin = true;
      userRecord.role = "CO-ADMIN";
    }

    closeModal();
    triggerRealtimeNotification("Access Granted", "You are now verified as a Co-Administrator!", "success");
    showView("admin");
    saveStateToStorage();
  } else {
    showToast("Invalid 4-digit code. Please verify with K. GAYATHRI SRIVALLI.", "normal");
  }
}

// ============================================================================
// 1. HOMEPAGE & HERO
// ============================================================================
function renderLandingView(container) {
  container.innerHTML = `
    <div class="hero-section" id="hero">
      <div class="hero-badge">
        ✦ Organizational Capacity Intelligence & Reciprocal Learning
      </div>

      <h1 class="hero-title">
        CAPACITY CONNECT<br>
        <span class="highlight-gradient">Empower Learners.</span> Scale Organizational Mastery.
      </h1>

      <p class="hero-subtitle">
        A grounded, data-driven capacity-building ecosystem. Compare competencies against organizational frameworks, eliminate skill gaps with explainable AI learning paths, connect with trainers, and build your own learning management portal.
      </p>

      <div class="hero-cta-group">
        <button class="btn-primary" style="padding:0.85rem 1.75rem; font-size:1rem;" onclick="openAuthModal('signup')">
          Create Your Account ➔
        </button>
      </div>
    </div>

    <!-- Human-Crafted Value Pillars -->
    <div style="max-width:1100px; margin:0 auto 5rem auto; padding:0 2rem;">
      <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:1.5rem;">
        <div class="section-card">
          <div style="font-size:1.6rem; margin-bottom:0.75rem;">📊</div>
          <h3 style="font-size:1.15rem; margin-bottom:0.5rem;">Deterministic Skill Gap Engine</h3>
          <p style="font-size:0.9rem;">Mathematical 1-5 proficiency comparisons between current competencies and organizational benchmarks with explainable AI reasoning.</p>
        </div>

        <div class="section-card">
          <div style="font-size:1.6rem; margin-bottom:0.75rem;">🤝</div>
          <h3 style="font-size:1.15rem; margin-bottom:0.5rem;">Reciprocal Skill Exchange</h3>
          <p style="font-size:0.9rem;">Connect with mentors, specify what you want to learn and what you offer to teach, and unlock real-time peer mentorship channels.</p>
        </div>

        <div class="section-card">
          <div style="font-size:1.6rem; margin-bottom:0.75rem;">📜</div>
          <h3 style="font-size:1.15rem; margin-bottom:0.5rem;">Knowledge Hub & Credentials</h3>
          <p style="font-size:0.9rem;">Upload and download interactive reference handbooks that open directly in your browser, take assessments, and earn credentials.</p>
        </div>
      </div>
    </div>
  `;
}

// ============================================================================
// 2. TRAINEE DASHBOARD (NO TARGET ROLE IN HEADER)
// ============================================================================
function renderTraineeDashboard(container) {
  container.innerHTML = `
    <div class="dashboard-container" id="trainee-dashboard-container">
      ${renderTraineeTabContent()}
    </div>
  `;
}

function setTraineeTab(tabName) {
  state.currentTab = tabName;
  const container = document.getElementById("trainee-dashboard-container");
  if (container) {
    container.innerHTML = renderTraineeTabContent();
  }
}

function renderTraineeTabContent() {
  switch (state.currentTab) {
    case "skill-gap":
      return renderTraineeSkillGapView();
    case "trainers":
      return renderTraineeTrainerMatchingView();
    case "assessments":
      return renderTraineeAssessmentsView();
    case "calendar":
      return renderCalendarWithNotesView();
    case "knowledge-hub":
      return renderKnowledgeHubView();
    case "certificates":
      return renderCertificatesView();
    default:
      return renderTraineeModularOverview();
  }
}

function renderTraineeModularOverview() {
  const analysis = calculateSkillGapEngine();
  const nextSession = state.trainingSessions.length > 0 ? state.trainingSessions[0] : null;
  const highestGap = analysis.priorityGaps.length > 0 ? analysis.priorityGaps[0] : null;
  const pendingExams = state.assessments.length;

  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? "Good morning" : (hour < 17 ? "Good afternoon" : "Good evening");

  return `
    <!-- Header with Personalized Greeting (Target Role Removed) -->
    <div class="dashboard-welcome-header">
      <div>
        <div class="greeting-text">${timeGreeting}, ${state.currentUser.fullName} 👋</div>
        <p style="font-size:0.92rem; color:var(--slate-600); margin-bottom:0.4rem;">
          Here’s what you should focus on today to accelerate your capacity growth.
        </p>
      </div>
      <div>
        <button class="btn-primary" onclick="setTraineeTab('skill-gap')">
          ⚡ Run Skill-Gap Analysis
        </button>
      </div>
    </div>

    <!-- 4 Summary Metric Cards -->
    <div class="metric-cards-grid-4">
      <div class="metric-card">
        <div class="metric-icon-box indigo">🎯</div>
        <div>
          <div class="metric-title">Role Readiness</div>
          <div class="metric-val">${analysis.overallReadiness}%</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box rose">⚡</div>
        <div>
          <div class="metric-title">Active Skill Gaps</div>
          <div class="metric-val">${analysis.totalGapsCount} gaps</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box emerald">📈</div>
        <div>
          <div class="metric-title">Learning Progress</div>
          <div class="metric-val">${state.currentUser.learningProgress || 0}%</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box amber">📅</div>
        <div>
          <div class="metric-title">Upcoming Session</div>
          <div class="metric-val" style="font-size:1.05rem; font-weight:800; line-height:1.2;">
            ${nextSession ? nextSession.sessionTime : 'None Scheduled'}
          </div>
        </div>
      </div>
    </div>

    <!-- Contextual Recommended Next Step -->
    <div class="next-step-card">
      <div>
        <div class="next-step-title">
          <span>🚀</span> Recommended Next Step
        </div>
        <p style="font-size:0.9rem; color:var(--slate-700); max-width:760px; line-height:1.5;">
          ${highestGap ? `Identified focus area: <strong>${highestGap.skill}</strong> (Level ${highestGap.current} → Level ${highestGap.required}). Update your skills in your profile, explore resources in Knowledge Hub, or connect with a mentor.` : 'Update your competencies in your Profile to generate personalized recommendations.'}
        </p>
      </div>
      <button class="btn-primary" style="white-space:nowrap; padding:0.65rem 1.15rem;" onclick="setTraineeTab('skill-gap')">
        View Analysis ➔
      </button>
    </div>

    <!-- Core Capability Cards -->
    <h3 style="font-size:1.2rem; margin-bottom:1.25rem;">Core Capabilities</h3>
    <div class="capability-grid">

      <div class="capability-card" onclick="setTraineeTab('skill-gap')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--rose); background:var(--rose-light);">⚡</div>
            <div class="capability-card-title">AI Skill-Gap Analysis</div>
          </div>
          <div class="capability-status-line" style="color:var(--rose);">
            ${analysis.totalGapsCount > 0 ? `${analysis.totalGapsCount} skills need improvement` : 'Benchmarks Met'}
          </div>
          <div class="capability-card-desc">
            Highest gap: <strong>${highestGap ? highestGap.skill : 'None'}</strong>. Mathematical 1-5 proficiency matrix and explainable AI reasoning.
          </div>
        </div>
        <div class="capability-action-btn">
          View Skill Gaps ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTraineeTab('trainers')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--primary); background:var(--primary-light);">🤝</div>
            <div class="capability-card-title">Trainer Matching & Exchange</div>
          </div>
          <div class="capability-status-line">
            ${state.trainers.length} verified mentors registered
          </div>
          <div class="capability-card-desc">
            Connect with trainers, send reciprocal skill exchange proposals, and chat 1-on-1.
          </div>
        </div>
        <div class="capability-action-btn">
          Find a Trainer ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTraineeTab('assessments')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--emerald); background:var(--emerald-light);">📝</div>
            <div class="capability-card-title">Assessments & Exams</div>
          </div>
          <div class="capability-status-line" style="color:var(--emerald);">
            ${pendingExams} active tests available
          </div>
          <div class="capability-card-desc">
            Latest result: ${state.assessmentSubmissions.length > 0 ? `${state.assessmentSubmissions[0].scorePercentage}% (${state.assessmentSubmissions[0].skillName})` : 'Diagnostic Ready'}. Instant AI grading.
          </div>
        </div>
        <div class="capability-action-btn">
          Take Assessment ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTraineeTab('knowledge-hub')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--amber); background:var(--amber-light);">📚</div>
            <div class="capability-card-title">Knowledge Hub</div>
          </div>
          <div class="capability-status-line" style="color:var(--amber);">
            ${state.knowledgeResources.length} curated resources & guides
          </div>
          <div class="capability-card-desc">
            Downloadable interactive reference handbooks that open directly in your browser.
          </div>
        </div>
        <div class="capability-action-btn">
          Browse Knowledge Hub ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTraineeTab('calendar')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--primary); background:var(--primary-light);">📅</div>
            <div class="capability-card-title">Schedule & Notes</div>
          </div>
          <div class="capability-status-line">
            Next session: ${nextSession ? nextSession.topic : 'No sessions'}
          </div>
          <div class="capability-card-desc">
            ${state.notesList.length} personal notes & goal reminders stored in your planner.
          </div>
        </div>
        <div class="capability-action-btn">
          View Schedule & Notes ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTraineeTab('certificates')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--amber); background:var(--amber-light);">🏆</div>
            <div class="capability-card-title">Official Certifications</div>
          </div>
          <div class="capability-status-line" style="color:var(--amber);">
            ${state.certificates.length} verifiable credentials earned
          </div>
          <div class="capability-card-desc">
            Downloadable high-resolution digital certificates for completed milestones.
          </div>
        </div>
        <div class="capability-action-btn">
          View Credentials ➔
        </div>
      </div>

    </div>
  `;
}

function renderTraineeSkillGapView() {
  const analysis = calculateSkillGapEngine();

  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="section-card" style="margin-bottom:2rem;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem; margin-bottom:1.5rem;">
        <div>
          <h2 style="font-size:1.8rem; margin:0.3rem 0;">Competency Gap Analysis</h2>
          <p style="font-size:0.9rem; max-width:680px;">${analysis.explainableSummary}</p>
        </div>
        <div style="text-align:right;">
          <div style="font-size:2.4rem; font-weight:800; color:var(--primary); line-height:1;">${analysis.overallReadiness}%</div>
          <div style="font-size:0.85rem; font-weight:700; color:var(--slate-500); text-transform:uppercase;">Benchmark Readiness</div>
          <button class="btn-primary" style="margin-top:0.75rem; font-size:0.82rem; padding:0.4rem 0.85rem;" onclick="openProfileModal()">
            + Edit Skills in Profile
          </button>
        </div>
      </div>

      <div style="overflow-x:auto;">
        <table style="width:100%; border-collapse:collapse; text-align:left; font-size:0.9rem;">
          <thead>
            <tr style="border-bottom:2px solid var(--border-soft); color:var(--slate-500); font-size:0.78rem; text-transform:uppercase; letter-spacing:0.05em;">
              <th style="padding:0.75rem 1rem;">Skill</th>
              <th style="padding:0.75rem 1rem;">Category</th>
              <th style="padding:0.75rem 1rem; text-align:center;">Current</th>
              <th style="padding:0.75rem 1rem; text-align:center;">Required</th>
              <th style="padding:0.75rem 1rem; text-align:center;">Gap</th>
              <th style="padding:0.75rem 1rem;">Severity</th>
              <th style="padding:0.75rem 1rem;">Priority</th>
              <th style="padding:0.75rem 1rem;">Action</th>
            </tr>
          </thead>
          <tbody>
            ${analysis.items.map(item => `
              <tr style="border-bottom:1px solid var(--border-soft);">
                <td style="padding:1rem; font-weight:700; color:var(--slate-900);">${item.skill}</td>
                <td style="padding:1rem; color:var(--slate-600);">${item.category}</td>
                <td style="padding:1rem; text-align:center; font-weight:700;">Level ${item.current}</td>
                <td style="padding:1rem; text-align:center; font-weight:700; color:var(--primary);">Level ${item.required}</td>
                <td style="padding:1rem; text-align:center; font-weight:800; color:${item.gap > 0 ? 'var(--rose)' : 'var(--emerald)'};">${item.gap}</td>
                <td style="padding:1rem;">
                  <span class="gap-severity-badge ${item.severity === 'Critical' ? 'high' : (item.severity === 'Moderate' ? 'medium' : 'low')}">
                    ${item.severity}
                  </span>
                </td>
                <td style="padding:1rem;">
                  <span style="font-weight:700; font-size:0.82rem; color:${item.priority === 'HIGH' ? 'var(--rose)' : (item.priority === 'MEDIUM' ? 'var(--amber)' : 'var(--emerald)')};">
                    ${item.priority}
                  </span>
                </td>
                <td style="padding:1rem;">
                  <button class="btn-secondary" style="padding:0.35rem 0.7rem; font-size:0.78rem;" onclick="openExplainableSkillDetailModal('${item.skill}')">
                    Explain Why ℹ
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderTraineeTrainerMatchingView() {
  const myRequests = state.skillExchangeRequests.filter(r => r.traineeId === (state.currentUser ? state.currentUser.id : 0));
  const activeChatExchange = state.skillExchangeRequests.find(r => r.id === state.chatActiveExchangeId && r.status === "ACCEPTED");
  const messages = activeChatExchange ? state.chatMessages.filter(m => m.exchangeId === activeChatExchange.id) : [];

  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Trainer Matching & Reciprocal Skill Exchange</h2>
        <p style="font-size:0.88rem;">Specify what you wish to learn and what you are ready to teach in return.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem; margin-bottom:2.5rem;">
      ${state.trainers.length > 0 ? state.trainers.map(tr => {
        const existingReq = myRequests.find(r => r.trainerId === tr.id);
        return `
          <div class="section-card" style="margin-bottom:0;">
            <div style="display:flex; align-items:center; gap:1rem; margin-bottom:1rem;">
              <img src="${tr.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'}" alt="${tr.fullName}" style="width:52px; height:52px; border-radius:50%; object-fit:cover;">
              <div>
                <h3 style="font-size:1.1rem; margin-bottom:0.15rem;">${tr.fullName}</h3>
                <div style="font-size:0.82rem; color:var(--slate-500);">${tr.primaryExpertise || 'Mentor'}</div>
                <div style="font-size:0.78rem; font-weight:700; color:var(--amber);">★ ${tr.rating || 5.0} rating (${tr.experienceYears || 1}+ years exp)</div>
              </div>
            </div>

            <p style="font-size:0.85rem; margin-bottom:1rem; line-height:1.45;">${tr.bio || 'Trainer & domain expert.'}</p>

            <div style="background:var(--slate-50); padding:0.75rem; border-radius:var(--radius-sm); margin-bottom:1.25rem; font-size:0.8rem;">
              <div style="margin-bottom:0.25rem;"><strong>Teaches:</strong> ${tr.skillsTaught || 'Technical Skills'}</div>
              <div><strong>Interested in Learning:</strong> ${tr.skillsWants || 'General Exchange'}</div>
            </div>

            <div style="display:flex; gap:0.5rem;">
              ${existingReq ? `
                <div style="flex-grow:1; text-align:center; padding:0.5rem; border-radius:var(--radius-md); font-size:0.82rem; font-weight:800; ${existingReq.status === 'ACCEPTED' ? 'background:var(--emerald-light); color:var(--emerald); border:1px solid var(--emerald-border);' : (existingReq.status === 'DECLINED' ? 'background:var(--rose-light); color:var(--rose); border:1px solid var(--rose-border);' : 'background:var(--amber-light); color:var(--amber); border:1px solid var(--amber-border);')}">
                  ${existingReq.status === 'ACCEPTED' ? '✓ Exchange Accepted' : (existingReq.status === 'DECLINED' ? '✕ Request Declined' : '⏳ Exchange Sent')}
                </div>
              ` : `
                <button class="btn-primary" style="flex-grow:1; justify-content:center; font-size:0.85rem;" onclick="openSendExchangeCustomModal(${tr.id}, '${tr.fullName}', '${tr.skillsTaught || ''}')">
                  Send Exchange Request ➔
                </button>
              `}
              <button class="btn-secondary" style="font-size:0.85rem; padding:0.5rem 0.85rem;" onclick="openTrainerProfileModal(${tr.id})">
                Profile
              </button>
            </div>
          </div>
        `;
      }).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">👨‍🏫</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Trainers Registered Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Create Trainer accounts or switch to <strong>Trainer Mode</strong> at the top to configure your mentor profile and offer skills.
          </p>
          <button class="btn-primary" onclick="switchActiveRole('TRAINER')">Switch to Trainer Mode ➔</button>
        </div>
      `}
    </div>

    <!-- Real-Time Chat Area -->
    <div class="section-card">
      <div class="section-header-wrap">
        <div>
          <h3 style="font-size:1.2rem;">Mentorship Direct Messages</h3>
          <p style="font-size:0.82rem;">Real-time conversation unlocks once a trainer accepts your mentorship request.</p>
        </div>
      </div>

      ${activeChatExchange ? `
        <div class="chat-window-card">
          <div class="chat-header">
            <div>
              <strong>${activeChatExchange.trainerName}</strong>
              <span style="font-size:0.78rem; color:var(--emerald); margin-left:0.5rem; font-weight:700;">● Active Channel</span>
            </div>
            <span style="font-size:0.8rem; color:var(--slate-500);">Skill: ${activeChatExchange.skillRequested}</span>
          </div>

          <div class="chat-body-scroll" id="trainee-chat-body">
            ${messages.map(m => `
              <div class="chat-bubble ${m.senderId === state.currentUser.id ? 'mine' : 'theirs'}">
                <div style="font-size:0.72rem; opacity:0.8; margin-bottom:0.2rem;">${m.senderName} • ${m.sentAt}</div>
                <div>${m.messageText}</div>
              </div>
            `).join('')}
          </div>

          <div class="chat-input-bar">
            <input type="text" id="trainee-chat-input" class="chat-input-field" placeholder="Type your mentorship message..." onkeypress="if(event.key==='Enter') sendTraineeChatMessage(${activeChatExchange.id}, ${activeChatExchange.trainerId})">
            <button class="btn-primary" onclick="sendTraineeChatMessage(${activeChatExchange.id}, ${activeChatExchange.trainerId})">Send ➔</button>
          </div>
        </div>
      ` : `
        <div style="text-align:center; padding:2.5rem; background:var(--slate-50); border:1px dashed var(--border-soft); border-radius:var(--radius-lg);">
          <div style="font-size:1.8rem; margin-bottom:0.4rem;">🔒</div>
          <h4 style="margin-bottom:0.3rem;">Mentorship Chat is Locked</h4>
          <p style="font-size:0.85rem; max-width:480px; margin:0 auto;">
            Send an exchange request to a trainer above. When they accept, your 1-on-1 mentorship chat channel will activate here automatically.
          </p>
        </div>
      `}
    </div>
  `;
}

function openSendExchangeCustomModal(trainerId, trainerName, skillsTaught) {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <h3 style="font-size:1.3rem;">Send Skill Exchange Request</h3>
      <p style="font-size:0.85rem; color:var(--slate-600);">Requesting mentorship from <strong>${trainerName}</strong></p>
    </div>

    <form onsubmit="handleSendExchangeCustomSubmit(event, ${trainerId}, '${trainerName}')">
      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Skill You Want to Learn (from Trainer)</label>
        <input type="text" id="exchange-skill-learn" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL, Python, System Design" value="${skillsTaught.split(',')[0] || ''}">
      </div>

      <div style="margin-bottom:1.25rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Skill You Are Ready to Teach / Offer in Return</label>
        <input type="text" id="exchange-skill-teach" required class="chat-input-field" style="width:100%;" placeholder="e.g. UI/UX Design, Excel Modeling, Java" value="Business Presentation">
      </div>

      <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">Send Exchange Request ➔</button>
      </div>
    </form>
  `);
}

function handleSendExchangeCustomSubmit(e, trainerId, trainerName) {
  e.preventDefault();
  const learnSkill = document.getElementById("exchange-skill-learn").value.trim();
  const teachSkill = document.getElementById("exchange-skill-teach").value.trim();

  const newReq = {
    id: Date.now(),
    traineeId: state.currentUser.id,
    traineeName: state.currentUser.fullName,
    trainerId: trainerId,
    trainerName: trainerName,
    skillRequested: learnSkill,
    skillOffered: teachSkill,
    status: "PENDING",
    createdAt: new Date().toISOString().split("T")[0]
  };

  state.skillExchangeRequests.push(newReq);
  closeModal();
  triggerRealtimeNotification("Skill Exchange Sent", `Mentorship proposal sent to ${trainerName} for ${learnSkill}`, "success");
  setTraineeTab("trainers");
  saveStateToStorage();
}

function sendTraineeChatMessage(exchangeId, trainerId) {
  const input = document.getElementById("trainee-chat-input");
  if (!input || !input.value.trim()) return;

  const text = input.value.trim();
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  state.chatMessages.push({
    id: Date.now(),
    exchangeId: exchangeId,
    senderId: state.currentUser.id,
    senderName: state.currentUser.fullName,
    receiverId: trainerId,
    messageText: text,
    sentAt: timeStr
  });

  input.value = "";
  setTraineeTab("trainers");
  saveStateToStorage();
}

// ─── SCHEDULE & NOTES ────────────────────────────────────────────────────────
function renderCalendarWithNotesView() {
  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Schedule & Planner</h2>
        <p style="font-size:0.88rem;">Manage your active sessions and maintain your personal notes & checklist.</p>
      </div>
    </div>

    <div class="calendar-layout-grid">
      <div class="section-card" style="margin-bottom:0;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.25rem;">
          <h3 style="font-size:1.15rem;">October 2026</h3>
          <span style="font-size:0.8rem; font-weight:700; color:var(--primary); background:var(--primary-light); padding:0.25rem 0.6rem; border-radius:var(--radius-full);">
            Current Month
          </span>
        </div>

        <div class="calendar-grid">
          <div class="calendar-day-head">Sun</div>
          <div class="calendar-day-head">Mon</div>
          <div class="calendar-day-head">Tue</div>
          <div class="calendar-day-head">Wed</div>
          <div class="calendar-day-head">Thu</div>
          <div class="calendar-day-head">Fri</div>
          <div class="calendar-day-head">Sat</div>

          <div class="calendar-day-cell">27</div>
          <div class="calendar-day-cell">28</div>
          <div class="calendar-day-cell">29</div>
          <div class="calendar-day-cell">30</div>
          <div class="calendar-day-cell active has-event">1</div>
          <div class="calendar-day-cell active has-event">2</div>
          <div class="calendar-day-cell">3</div>
          <div class="calendar-day-cell">4</div>
          <div class="calendar-day-cell">5</div>
          <div class="calendar-day-cell">6</div>
          <div class="calendar-day-cell">7</div>
          <div class="calendar-day-cell">8</div>
          <div class="calendar-day-cell">9</div>
          <div class="calendar-day-cell">10</div>
        </div>

        <div style="margin-top:1.5rem; border-top:1px solid var(--border-soft); padding-top:1rem;">
          <div style="font-size:0.85rem; font-weight:700; margin-bottom:0.5rem;">Upcoming Mentorship Sessions:</div>
          ${state.trainingSessions.length > 0 ? state.trainingSessions.map(s => `
            <div style="display:flex; justify-content:space-between; align-items:center; background:var(--slate-50); padding:0.6rem 0.9rem; border-radius:var(--radius-sm); margin-bottom:0.4rem; font-size:0.84rem;">
              <div>
                <strong>${s.topic}</strong>
                <div style="color:var(--slate-500); font-size:0.78rem;">${s.sessionTime}</div>
              </div>
              <a href="${s.meetingLink}" target="_blank" class="btn-primary" style="padding:0.3rem 0.65rem; font-size:0.75rem;">Join Meet</a>
            </div>
          `).join('') : `
            <div style="font-size:0.85rem; color:var(--slate-500); font-style:italic;">No active sessions scheduled yet.</div>
          `}
        </div>
      </div>

      <div class="notes-editor-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
          <div style="font-weight:800; font-size:1rem; color:#92400E; display:flex; align-items:center; gap:0.4rem;">
            <span>📝</span> Study Notes & Tasks
          </div>
          <span style="font-size:0.75rem; color:#B45309; font-weight:700;">${state.notesList.length} items</span>
        </div>

        <div style="display:flex; gap:0.5rem; margin-bottom:1rem;">
          <input type="text" id="new-note-input" class="chat-input-field" placeholder="Type a new goal/note point..." style="flex-grow:1; font-size:0.85rem;" onkeypress="if(event.key==='Enter') addNewNotePoint()">
          <button class="btn-primary" style="padding:0.4rem 0.8rem; font-size:0.82rem;" onclick="addNewNotePoint()">+ Add</button>
        </div>

        <div style="display:flex; flex-direction:column; gap:0.5rem; max-height:260px; overflow-y:auto;">
          ${state.notesList.map(n => `
            <div class="notes-item-row">
              <span style="color:var(--slate-800); line-height:1.4;">• ${n.text}</span>
              <button class="btn-danger" style="padding:0.2rem 0.5rem; font-size:0.72rem; border-radius:4px; margin-left:0.5rem;" onclick="deleteNotePoint(${n.id})">
                Delete ✕
              </button>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function addNewNotePoint() {
  const input = document.getElementById("new-note-input");
  if (!input || !input.value.trim()) return;

  state.notesList.push({
    id: Date.now(),
    text: input.value.trim()
  });

  input.value = "";
  showToast("New note added!", "success");
  setTraineeTab("calendar");
  saveStateToStorage();
}

function deleteNotePoint(noteId) {
  state.notesList = state.notesList.filter(n => n.id !== noteId);
  showToast("Note point removed.", "normal");
  setTraineeTab("calendar");
  saveStateToStorage();
}

// ─── ASSESSMENTS VIEW ────────────────────────────────────────────────────────
function renderTraineeAssessmentsView() {
  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Technical Assessments & AI Evaluation</h2>
        <p style="font-size:0.88rem;">Passing verified assessments dynamically updates your competency profile in real time.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(360px, 1fr)); gap:1.5rem; margin-bottom:2rem;">
      ${state.assessments.length > 0 ? state.assessments.map(a => `
        <div class="section-card" style="margin-bottom:0;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.75rem;">
            <span class="gap-severity-badge low">${a.category || 'Technical'}</span>
            <span style="font-size:0.8rem; font-weight:700; color:var(--slate-500);">⏱ ${a.duration} mins</span>
          </div>

          <h3 style="font-size:1.15rem; margin-bottom:0.4rem;">${a.title}</h3>
          <p style="font-size:0.85rem; margin-bottom:1rem; color:var(--slate-600);">
            Target Competency: <strong>${a.skillName} (Level ${a.targetProficiency})</strong> • Passing Score: <strong>${a.passingScore}%</strong>
          </p>

          <button class="btn-primary" style="width:100%; justify-content:center;" onclick="startAssessmentModal(${a.id})">
            Take Assessment ➔
          </button>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">📝</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Assessments Created Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Trainers can create MCQ assessments from their dashboard to evaluate learners.
          </p>
        </div>
      `}
    </div>

    ${state.assessmentSubmissions.length > 0 ? `
      <div class="section-card">
        <div class="section-card-title" style="margin-bottom:1rem;">Your Verified Assessment Results</div>
        <div style="display:flex; flex-direction:column; gap:1rem;">
          ${state.assessmentSubmissions.map(sub => `
            <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1.25rem;">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
                <h4 style="font-size:1.05rem;">${sub.assessmentTitle}</h4>
                <span class="gap-severity-badge ${sub.passed ? 'low' : 'high'}">${sub.passed ? 'PASSED ✓' : 'NEEDS PRACTICE'}</span>
              </div>
              <div style="font-size:0.88rem; color:var(--slate-700); margin-bottom:0.5rem;">
                Score: <strong>${sub.scorePercentage}%</strong> (${sub.correctCount}/${sub.totalQuestions} questions correct)
              </div>
              <p style="font-size:0.85rem; color:var(--slate-600); margin-bottom:0.75rem;">${sub.aiEvaluationNotes}</p>
              <button class="btn-secondary" style="font-size:0.8rem; padding:0.35rem 0.75rem;" onclick="viewSubmissionBreakdownModal(${sub.id})">
                View Question-by-Question Review ℹ
              </button>
            </div>
          `).join('')}
        </div>
      </div>
    ` : ''}
  `;
}

function startAssessmentModal(assessmentId) {
  const a = state.assessments.find(x => x.id === assessmentId);
  if (!a) return;
  state.currentAssessment = a;

  openModal(`
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <div>
        <span class="gap-severity-badge low">${a.skillName}</span>
        <h3 style="font-size:1.3rem; margin-top:0.25rem;">${a.title}</h3>
      </div>
      <div style="font-size:1.1rem; font-weight:800; color:var(--rose);">
        ⏱ ${a.duration}:00
      </div>
    </div>

    <form id="assessment-exam-form">
      ${a.questions.map((q, idx) => `
        <div style="margin-bottom:1.5rem; background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1.25rem;">
          <div style="font-weight:700; font-size:0.95rem; margin-bottom:0.75rem; color:var(--slate-900);">
            ${idx + 1}. ${q.question}
          </div>
          <div style="display:flex; flex-direction:column; gap:0.5rem;">
            ${q.options.map((opt, oIdx) => {
              const letter = ["A", "B", "C", "D"][oIdx];
              return `
                <label style="display:flex; align-items:center; gap:0.6rem; padding:0.6rem 0.85rem; background:#fff; border:1px solid var(--border-soft); border-radius:var(--radius-sm); cursor:pointer; font-size:0.88rem;">
                  <input type="radio" name="q_${q.id}" value="${letter}" required>
                  <span><strong>${letter}.</strong> ${opt}</span>
                </label>
              `;
            }).join('')}
          </div>
        </div>
      `).join('')}

      <div style="display:flex; justify-content:flex-end; gap:0.75rem; margin-top:1.5rem;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="button" class="btn-primary" onclick="submitAssessmentExam(${a.id})">Submit Assessment ➔</button>
      </div>
    </form>
  `);
}

function submitAssessmentExam(assessmentId) {
  const a = state.assessments.find(x => x.id === assessmentId);
  if (!a) return;

  const form = document.getElementById("assessment-exam-form");
  const formData = new FormData(form);
  
  let correctCount = 0;
  const reviews = [];

  a.questions.forEach(q => {
    const selected = formData.get(`q_${q.id}`);
    const isCorrect = selected === q.correctOption;
    if (isCorrect) correctCount++;
    reviews.push({
      question: q.question,
      selected: selected || "None",
      correct: q.correctOption,
      isCorrect: isCorrect,
      explanation: q.explanation || "Standard domain concept."
    });
  });

  const scorePct = Math.round((correctCount / a.questions.length) * 100);
  const passed = scorePct >= a.passingScore;

  const submission = {
    id: Date.now(),
    assessmentId: a.id,
    assessmentTitle: a.title,
    skillName: a.skillName,
    scorePercentage: scorePct,
    correctCount: correctCount,
    totalQuestions: a.questions.length,
    passed: passed,
    aiEvaluationNotes: passed 
      ? `Strong demonstration of competence in ${a.skillName}. Recommended proficiency target unlocked.`
      : `Scored ${scorePct}%. Review ${a.skillName} material in Knowledge Hub and retake assessment.`,
    reviews: reviews
  };

  state.assessmentSubmissions.unshift(submission);

  if (passed) {
    let userComp = state.userCompetencies.find(uc => uc.skill.toLowerCase() === a.skillName.toLowerCase());
    const prev = userComp ? userComp.current : 1;
    if (userComp) {
      userComp.current = Math.max(userComp.current, a.targetProficiency);
      userComp.evidence = `Passed ${a.title} (${scorePct}%)`;
    } else {
      userComp = { skill: a.skillName, current: a.targetProficiency, evidence: `Passed ${a.title} (${scorePct}%)`, confidence: 0.95 };
      state.userCompetencies.push(userComp);
    }

    state.competencyHistory.unshift({
      skill: a.skillName,
      prev: prev,
      curr: userComp.current,
      event: `Passed ${a.title}`,
      score: scorePct,
      date: new Date().toISOString().split("T")[0]
    });

    const certCode = `CAP-${a.skillName.toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    state.certificates.push({
      id: Date.now(),
      code: certCode,
      title: `${a.skillName} Proficiency Certification`,
      score: scorePct,
      grade: scorePct >= 90 ? "Distinction A+" : "Certified Professional",
      issueDate: new Date().toLocaleDateString(),
      issuer: "CAPACITY CONNECT ENTERPRISE ACADEMY"
    });

    triggerRealtimeNotification("Certificate Awarded!", `Passed ${a.title} (${scorePct}%). Credential: ${certCode}`, "success");
  } else {
    triggerRealtimeNotification("Assessment Completed", `Scored ${scorePct}% on ${a.title}.`, "normal");
  }

  closeModal();
  setTraineeTab("assessments");
  saveStateToStorage();
}

function viewSubmissionBreakdownModal(subId) {
  const sub = state.assessmentSubmissions.find(s => s.id === subId);
  if (!sub) return;

  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <span class="gap-severity-badge ${sub.passed ? 'low' : 'high'}">${sub.passed ? 'PASSED ✓' : 'NEEDS PRACTICE'}</span>
      <h3 style="font-size:1.3rem; margin-top:0.35rem;">${sub.assessmentTitle}</h3>
      <div style="font-size:0.9rem; color:var(--slate-600); margin-top:0.25rem;">
        Final Score: <strong>${sub.scorePercentage}%</strong> • Correct: <strong>${sub.correctCount} / ${sub.totalQuestions}</strong>
      </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:1rem;">
      ${sub.reviews.map((r, i) => `
        <div class="question-review-card ${r.isCorrect ? 'correct' : 'incorrect'}">
          <div style="font-weight:700; font-size:0.95rem; margin-bottom:0.4rem;">
            ${i + 1}. ${r.question}
          </div>
          <div style="font-size:0.85rem; margin-bottom:0.4rem;">
            Your Answer: <strong>Option ${r.selected}</strong> ${r.isCorrect ? '✓ (Correct)' : '✕ (Incorrect)'}
            ${!r.isCorrect ? `• Correct Answer: <strong>Option ${r.correct}</strong>` : ''}
          </div>
          <div style="font-size:0.82rem; color:var(--slate-700); background:rgba(255,255,255,0.7); padding:0.5rem 0.75rem; border-radius:var(--radius-sm);">
            💡 <strong>Explanation:</strong> ${r.explanation}
          </div>
        </div>
      `).join('')}
    </div>

    <div style="margin-top:1.5rem; text-align:right;">
      <button class="btn-primary" onclick="closeModal()">Done</button>
    </div>
  `);
}

// ─── KNOWLEDGE HUB ───────────────────────────────────────────────────────────
function renderKnowledgeHubView() {
  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Knowledge Hub</h2>
        <p style="font-size:0.88rem;">Access, view, and download technical handbooks and guides that open cleanly in any web browser.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.knowledgeResources.length > 0 ? state.knowledgeResources.map(res => `
        <div class="section-card" style="margin-bottom:0; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.75rem;">
              <span class="gap-severity-badge low">${res.resourceType || 'HANDBOOK'}</span>
              <span style="font-size:0.78rem; font-weight:700; color:var(--slate-500);">${res.fileSizeKb || 15} KB</span>
            </div>
            <h3 style="font-size:1.15rem; margin-bottom:0.4rem;">${res.title}</h3>
            <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
              Skill: <strong>${res.skillName}</strong> • Author: <strong>${res.uploadedByName || 'Trainer'}</strong>
            </div>
            <div style="font-size:0.78rem; font-family:var(--font-mono); color:var(--slate-500); background:var(--slate-100); padding:0.3rem 0.6rem; border-radius:4px; margin-bottom:1rem; display:inline-block;">
              🌐 ${res.title.replace(/\s+/g, '_')}_Guide.html
            </div>
          </div>

          <div style="display:flex; gap:0.5rem; margin-top:1rem;">
            <button class="btn-primary" style="flex-grow:1; justify-content:center; font-size:0.85rem;" onclick="openAndDownloadResource(${res.id})">
              Open & Download (HTML Doc) 📥
            </button>
          </div>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">📚</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Knowledge Resources Uploaded Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Switch to <strong>Trainer Mode</strong> to upload guides, cheat sheets, and references.
          </p>
          <button class="btn-primary" onclick="switchActiveRole('TRAINER')">Switch to Trainer Mode ➔</button>
        </div>
      `}
    </div>
  `;
}

function openAndDownloadResource(resourceId) {
  const res = state.knowledgeResources.find(r => r.id === resourceId);
  if (!res) return;

  res.downloadCount = (res.downloadCount || 0) + 1;
  saveStateToStorage();

  if (res.fileData && res.fileName) {
    // Binary file or local attachment: download original file directly
    const tempLink = document.createElement("a");
    tempLink.href = res.fileData;
    tempLink.download = res.fileName;
    document.body.appendChild(tempLink);
    tempLink.click();
    document.body.removeChild(tempLink);

    openModal(`
      <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
        <span class="gap-severity-badge low">${res.resourceType || 'DOCUMENT'}</span>
        <h3 style="font-size:1.3rem; margin-top:0.35rem;">${res.title}</h3>
        <div style="font-size:0.85rem; color:var(--slate-500);">Downloaded as <strong>${res.fileName}</strong> (${res.fileSizeKb || 25} KB)</div>
      </div>

      <div style="background:var(--slate-50); border:1px solid var(--border-soft); padding:1.5rem; border-radius:var(--radius-md); font-size:0.9rem; line-height:1.6; max-height:340px; overflow-y:auto; color:var(--slate-800);">
        <div style="display:flex; align-items:center; gap:0.75rem; margin-bottom:1rem; padding:0.75rem 1rem; background:#fff; border:1px solid var(--border-soft); border-radius:var(--radius-sm);">
          <span style="font-size:1.8rem;">📄</span>
          <div>
            <div style="font-weight:700; color:var(--slate-900);">${res.fileName}</div>
            <div style="font-size:0.78rem; color:var(--slate-500);">Author: <strong>${res.uploadedByName}</strong> • Skill: <strong>${res.skillName}</strong></div>
          </div>
        </div>
        <p style="white-space:pre-wrap; margin:0; line-height:1.6;">${res.fileContent}</p>
      </div>

      <div style="margin-top:1.5rem; display:flex; justify-content:space-between; align-items:center;">
        <span style="font-size:0.82rem; color:var(--emerald); font-weight:700;">✓ File downloaded to your computer</span>
        <button class="btn-primary" onclick="closeModal()">Done</button>
      </div>
    `);
    showToast(`Downloaded "${res.fileName}" successfully.`, "success");
    return;
  }

  // Text / Guide content: generate styled HTML handbook
  const htmlFormattedContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${res.title} — CAPACITY CONNECT Knowledge Hub</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 860px; margin: 40px auto; padding: 0 24px; line-height: 1.6; color: #1E293B; background: #F8FAFC; }
    .doc-card { background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 12px; padding: 36px; box-shadow: 0 4px 14px rgba(15,23,42,0.06); }
    .tag { display: inline-block; background: #EEF2FF; color: #4F46E5; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 6px; text-transform: uppercase; margin-bottom: 12px; }
    h1 { color: #0F172A; margin: 0 0 8px 0; font-size: 26px; }
    .meta { font-size: 13px; color: #64748B; margin-bottom: 24px; border-bottom: 1px solid #E2E8F0; padding-bottom: 16px; }
    pre { background: #0F172A; color: #F8FAFC; padding: 18px; border-radius: 8px; overflow-x: auto; font-family: 'Courier New', Courier, monospace; font-size: 14px; white-space: pre-wrap; }
    .print-btn { background: #4F46E5; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: bold; margin-bottom: 20px; }
  </style>
</head>
<body>
  <div class="doc-card">
    <button class="print-btn" onclick="window.print()">🖨️ Print / Save as PDF</button>
    <div class="tag">${res.resourceType || 'DOCUMENT'}</div>
    <h1>${res.title}</h1>
    <div class="meta">Skill: <strong>${res.skillName}</strong> | Author: <strong>${res.uploadedByName || 'Trainer'}</strong> | CAPACITY CONNECT Knowledge Hub</div>
    <div style="font-size: 15px; line-height: 1.7; white-space: pre-wrap;">${res.fileContent}</div>
  </div>
</body>
</html>`;

  const fileName = `${res.title.replace(/[^a-zA-Z0-9]/g, '_')}_Handbook.html`;
  const blob = new Blob([htmlFormattedContent], { type: "text/html;charset=utf-8" });
  const downloadUrl = URL.createObjectURL(blob);
  const tempLink = document.createElement("a");
  tempLink.href = downloadUrl;
  tempLink.download = fileName;
  document.body.appendChild(tempLink);
  tempLink.click();
  document.body.removeChild(tempLink);
  URL.revokeObjectURL(downloadUrl);

  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <span class="gap-severity-badge low">${res.resourceType || 'DOCUMENT'}</span>
      <h3 style="font-size:1.3rem; margin-top:0.35rem;">${res.title}</h3>
      <div style="font-size:0.85rem; color:var(--slate-500);">Downloaded as <strong>${fileName}</strong> (Opens directly in web browser)</div>
    </div>

    <div style="background:var(--slate-50); border:1px solid var(--border-soft); padding:1.5rem; border-radius:var(--radius-md); font-size:0.9rem; line-height:1.6; max-height:340px; overflow-y:auto; white-space:pre-wrap; color:var(--slate-800);">${res.fileContent}</div>

    <div style="margin-top:1.5rem; display:flex; justify-content:space-between; align-items:center;">
      <span style="font-size:0.82rem; color:var(--emerald); font-weight:700;">✓ HTML document downloaded to your PC</span>
      <button class="btn-primary" onclick="closeModal()">Done</button>
    </div>
  `);

  showToast(`Downloaded "${fileName}" successfully.`, "success");
}

function renderCertificatesView() {
  return `
    <button class="back-to-dash-btn" onclick="setTraineeTab('overview')">
      ← Back to Control Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Official Digital Certifications</h2>
        <p style="font-size:0.88rem;">Verifiable enterprise credentials awarded upon demonstrating proven competency mastery.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(360px, 1fr)); gap:1.5rem;">
      ${state.certificates.length > 0 ? state.certificates.map(cert => `
        <div class="section-card" style="margin-bottom:0; border-top:4px solid var(--amber);">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.75rem;">
            <span style="font-size:0.78rem; font-weight:800; color:var(--amber); font-family:var(--font-mono);">${cert.code}</span>
            <span class="gap-severity-badge low">VERIFIED ✓</span>
          </div>

          <h3 style="font-size:1.2rem; margin-bottom:0.4rem;">${cert.title}</h3>
          <div style="font-size:0.88rem; color:var(--slate-700); margin-bottom:0.25rem;">
            Score: <strong>${cert.score}%</strong> (${cert.grade})
          </div>
          <div style="font-size:0.8rem; color:var(--slate-500); margin-bottom:1.5rem;">
            Issued on ${cert.issueDate} • ${cert.issuer}
          </div>

          <button class="btn-primary" style="width:100%; justify-content:center;" onclick="downloadCertificateCanvasOnly('${cert.code}')">
            Download Certificate (PNG) 📥
          </button>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">🏆</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Certificates Earned Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Pass assessments with 75%+ scores to earn official verifiable certificates.
          </p>
        </div>
      `}
    </div>
  `;
}

function downloadCertificateCanvasOnly(code) {
  const cert = state.certificates.find(c => c.code === code);
  if (!cert) return;
  
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 800;
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, 1200, 800);

  ctx.strokeStyle = "#D97706";
  ctx.lineWidth = 14;
  ctx.strokeRect(40, 40, 1120, 720);
  ctx.lineWidth = 4;
  ctx.strokeRect(55, 55, 1090, 690);

  ctx.fillStyle = "#4F46E5";
  ctx.font = "bold 28px 'Plus Jakarta Sans', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("CAPACITY CONNECT ENTERPRISE ACADEMY", 600, 130);

  ctx.fillStyle = "#0F172A";
  ctx.font = "bold 46px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText("CERTIFICATE OF COMPETENCY", 600, 200);

  ctx.fillStyle = "#64748B";
  ctx.font = "22px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText("This officially certifies that", 600, 260);

  ctx.fillStyle = "#4F46E5";
  ctx.font = "bold 52px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText(state.currentUser.fullName, 600, 330);

  ctx.fillStyle = "#334155";
  ctx.font = "22px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText(`has successfully passed all formal assessments with ${cert.grade} (${cert.score}%)`, 600, 390);
  ctx.fillText("and demonstrated verified industry competency in:", 600, 425);

  ctx.fillStyle = "#0F172A";
  ctx.font = "bold 34px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText(cert.title, 600, 480);

  ctx.fillStyle = "#64748B";
  ctx.font = "18px 'Plus Jakarta Sans', sans-serif";
  ctx.fillText(`Credential ID: ${cert.code} • Verified on ${cert.issueDate}`, 600, 560);

  const pngUrl = canvas.toDataURL("image/png");
  const dl = document.createElement("a");
  dl.href = pngUrl;
  dl.download = `Certificate_${cert.code}.png`;
  document.body.appendChild(dl);
  dl.click();
  document.body.removeChild(dl);
  showToast("Certificate downloaded successfully!", "success");
}

// ============================================================================
// 3. TRAINER DASHBOARD (MENTOR & TRAINER CONTROL PANEL)
// ============================================================================
function renderTrainerDashboard(container) {
  container.innerHTML = `
    <div class="dashboard-container" id="trainer-dashboard-container">
      ${renderTrainerTabContent()}
    </div>
  `;
}

function setTrainerTab(tabName) {
  state.currentTab = tabName;
  const container = document.getElementById("trainer-dashboard-container");
  if (container) {
    container.innerHTML = renderTrainerTabContent();
  }
}

function renderTrainerTabContent() {
  switch (state.currentTab) {
    case "requests":
      return renderTrainerRequestsView();
    case "courses":
      return renderTrainerCoursesView();
    case "knowledge-hub":
      return renderTrainerKnowledgeHubView();
    case "assessments":
      return renderTrainerAssessmentsView();
    default:
      return renderTrainerModularOverview();
  }
}

function renderTrainerModularOverview() {
  const myPendingRequests = state.skillExchangeRequests.filter(r => r.trainerId === (state.currentUser ? state.currentUser.id : 0) && r.status === "PENDING");
  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? "Good morning" : (hour < 17 ? "Good afternoon" : "Good evening");

  return `
    <!-- Distinct Trainer Header -->
    <div class="dashboard-welcome-header" style="border-left: 4px solid var(--amber);">
      <div>
        <div style="font-size:0.8rem; font-weight:800; color:var(--amber); text-transform:uppercase; margin-bottom:0.2rem;">
          👨‍🏫 Mentor & Trainer Control Center
        </div>
        <div class="greeting-text">${timeGreeting}, ${state.currentUser.fullName}</div>
        <p style="font-size:0.92rem; color:var(--slate-600); margin-bottom:0.4rem;">
          Expertise: <strong>${state.currentUser.primaryExpertise || 'Domain Mentor'}</strong> • Skills: ${state.currentUser.skillsTaught || 'Technical Skills'}
        </p>
      </div>
      <div style="display:flex; gap:0.5rem;">
        <button class="btn-secondary" onclick="openProfileModal()">
          Edit Trainer Profile
        </button>
        <button class="btn-primary" onclick="openCreateCourseModal()">
          + Create Course
        </button>
      </div>
    </div>

    <!-- Trainer Metric Cards -->
    <div class="metric-cards-grid-4">
      <div class="metric-card">
        <div class="metric-icon-box amber">⏳</div>
        <div>
          <div class="metric-title">Pending Requests</div>
          <div class="metric-val">${myPendingRequests.length}</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box emerald">📚</div>
        <div>
          <div class="metric-title">My Courses</div>
          <div class="metric-val">${state.courses.length}</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box indigo">📂</div>
        <div>
          <div class="metric-title">Knowledge Guides</div>
          <div class="metric-val">${state.knowledgeResources.length}</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box rose">📝</div>
        <div>
          <div class="metric-title">Assessments</div>
          <div class="metric-val">${state.assessments.length}</div>
        </div>
      </div>
    </div>

    <!-- Trainer Capabilities Grid -->
    <h3 style="font-size:1.2rem; margin-bottom:1.25rem;">Trainer Control Center</h3>
    <div class="capability-grid">

      <div class="capability-card" onclick="setTrainerTab('requests')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--amber); background:var(--amber-light);">🤝</div>
            <div class="capability-card-title">Skill Exchange Requests</div>
          </div>
          <div class="capability-status-line" style="color:var(--amber);">
            ${myPendingRequests.length} trainees waiting for response
          </div>
          <div class="capability-card-desc">
            Review incoming mentorship proposals, accept to unlock live 1-on-1 chat.
          </div>
        </div>
        <div class="capability-action-btn">
          Manage Requests ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTrainerTab('courses')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--primary); background:var(--primary-light);">📚</div>
            <div class="capability-card-title">Course Management</div>
          </div>
          <div class="capability-status-line">
            ${state.courses.length} published courses
          </div>
          <div class="capability-card-desc">
            Create, edit, and publish modular courses with structured reading concepts.
          </div>
        </div>
        <div class="capability-action-btn">
          Manage Courses ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTrainerTab('knowledge-hub')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--emerald); background:var(--emerald-light);">📂</div>
            <div class="capability-card-title">Knowledge Hub Uploads</div>
          </div>
          <div class="capability-status-line" style="color:var(--emerald);">
            ${state.knowledgeResources.length} active documents
          </div>
          <div class="capability-card-desc">
            Upload technical guides, cheatsheets, and reference handbooks.
          </div>
        </div>
        <div class="capability-action-btn">
          Upload Resources ➔
        </div>
      </div>

      <div class="capability-card" onclick="setTrainerTab('assessments')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--rose); background:var(--rose-light);">📝</div>
            <div class="capability-card-title">Assessment Creator</div>
          </div>
          <div class="capability-status-line" style="color:var(--rose);">
            ${state.assessments.length} active tests
          </div>
          <div class="capability-card-desc">
            Design MCQ tests with answer keys for automatic competency grading.
          </div>
        </div>
        <div class="capability-action-btn">
          Create Assessment ➔
        </div>
      </div>

    </div>
  `;
}

function renderTrainerRequestsView() {
  const requests = state.skillExchangeRequests;

  return `
    <button class="back-to-dash-btn" onclick="setTrainerTab('overview')">
      ← Back to Trainer Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Skill Exchange Proposals</h2>
        <p style="font-size:0.88rem;">Accepting a request unlocks direct chat with the learner.</p>
      </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:1rem;">
      ${requests.length > 0 ? requests.map(req => `
        <div class="section-card" style="margin-bottom:0;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.75rem;">
            <div>
              <h3 style="font-size:1.15rem;">Request from: <strong>${req.traineeName}</strong></h3>
              <div style="font-size:0.82rem; color:var(--slate-500); margin-top:0.2rem;">Submitted on ${req.createdAt}</div>
            </div>
            <span class="gap-severity-badge ${req.status === 'ACCEPTED' ? 'low' : (req.status === 'DECLINED' ? 'high' : 'medium')}">
              ${req.status}
            </span>
          </div>

          <div style="background:var(--slate-50); padding:0.85rem; border-radius:var(--radius-sm); font-size:0.85rem; margin-bottom:1rem;">
            <div style="margin-bottom:0.3rem;">Learner wants to learn: <strong style="color:var(--primary);">${req.skillRequested}</strong></div>
            <div>Learner offers to teach in return: <strong style="color:var(--emerald);">${req.skillOffered}</strong></div>
          </div>

          ${req.status === 'PENDING' ? `
            <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
              <button class="btn-danger" onclick="declineExchangeRequest(${req.id})">Decline ✕</button>
              <button class="btn-primary" onclick="acceptExchangeRequest(${req.id})">Accept & Unlock Chat ✓</button>
            </div>
          ` : `
            <div style="font-size:0.82rem; color:var(--slate-600); font-weight:700;">
              ${req.status === 'ACCEPTED' ? '✓ Mentorship active. Chat is unlocked.' : '✕ Request was declined.'}
            </div>
          `}
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem; background:var(--slate-50); border:1px dashed var(--border-soft); border-radius:var(--radius-lg);">
          <div style="font-size:2rem; margin-bottom:0.5rem;">📬</div>
          <h4>No Requests Yet</h4>
          <p style="font-size:0.85rem; color:var(--slate-500);">When trainees send you skill exchange requests, they will appear here.</p>
        </div>
      `}
    </div>
  `;
}

function acceptExchangeRequest(reqId) {
  const req = state.skillExchangeRequests.find(r => r.id === reqId);
  if (req) {
    req.status = "ACCEPTED";
    state.chatActiveExchangeId = req.id;
    triggerRealtimeNotification("Exchange Accepted!", `You accepted ${req.traineeName}'s mentorship proposal. Chat unlocked!`, "success");
    setTrainerTab("requests");
    saveStateToStorage();
  }
}

function declineExchangeRequest(reqId) {
  const req = state.skillExchangeRequests.find(r => r.id === reqId);
  if (req) {
    req.status = "DECLINED";
    showToast(`Exchange declined.`, "normal");
    setTrainerTab("requests");
    saveStateToStorage();
  }
}

function renderTrainerCoursesView() {
  return `
    <button class="back-to-dash-btn" onclick="setTrainerTab('overview')">
      ← Back to Trainer Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">My Courses</h2>
        <p style="font-size:0.88rem;">Manage your published courses and reading concepts.</p>
      </div>
      <div>
        <button class="btn-primary" onclick="openCreateCourseModal()">
          + Create New Course
        </button>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.courses.length > 0 ? state.courses.map(c => `
        <div class="section-card" style="margin-bottom:0; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <span class="gap-severity-badge low">${c.difficulty || 'GENERAL'}</span>
            <h3 style="font-size:1.15rem; margin:0.4rem 0 0.25rem 0;">${c.title}</h3>
            <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
              Skill: <strong>${c.skillName}</strong> • Category: ${c.category}
            </div>
            <p style="font-size:0.85rem; line-height:1.45; margin-bottom:1rem;">${c.description}</p>
          </div>

          <div style="display:flex; justify-content:flex-end; gap:0.5rem; border-top:1px solid var(--border-soft); padding-top:0.75rem;">
            <button class="btn-danger" onclick="deleteTrainerCourse(${c.id})">Delete 🗑</button>
          </div>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">📚</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Courses Published Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Click the button below to create and publish your first course.
          </p>
          <button class="btn-primary" onclick="openCreateCourseModal()">+ Create Course ➔</button>
        </div>
      `}
    </div>
  `;
}

function openCreateCourseModal() {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <h3 style="font-size:1.3rem;">Create New Course</h3>
      <p style="font-size:0.85rem; color:var(--slate-600);">Publish structured learning concepts for trainees.</p>
    </div>

    <form onsubmit="handleCreateCourseSubmit(event)">
      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Course Title</label>
        <input type="text" id="new-course-title" required class="chat-input-field" style="width:100%;" placeholder="e.g. Advanced SQL Queries & Query Execution Plans">
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Target Competency / Skill</label>
          <input type="text" id="new-course-skill" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL">
        </div>
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Category</label>
          <input type="text" id="new-course-category" required class="chat-input-field" style="width:100%;" placeholder="e.g. Database & Analytics">
        </div>
      </div>

      <div style="margin-bottom:1.25rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Course Description & Reading Notes</label>
        <textarea id="new-course-desc" required class="chat-input-field" style="width:100%; height:100px;" placeholder="Provide conceptual notes, syntax walkthroughs, and practice guidelines..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">Publish Course ➔</button>
      </div>
    </form>
  `);
}

function handleCreateCourseSubmit(e) {
  e.preventDefault();
  const title = document.getElementById("new-course-title").value.trim();
  const skill = document.getElementById("new-course-skill").value.trim();
  const category = document.getElementById("new-course-category").value.trim();
  const desc = document.getElementById("new-course-desc").value.trim();

  const newCourse = {
    id: Date.now(),
    trainerId: state.currentUser.id,
    trainerName: state.currentUser.fullName,
    title: title,
    skillName: skill,
    category: category,
    difficulty: "INTERMEDIATE",
    description: desc,
    estimatedHours: 8,
    totalLessons: 4,
    completedLessons: 0,
    progress: 0,
    enrolled: false
  };

  state.courses.push(newCourse);
  closeModal();
  triggerRealtimeNotification("New Course Published", `"${title}" is now active in the platform catalog.`, "success");
  setTrainerTab("courses");
  saveStateToStorage();
}

function deleteTrainerCourse(courseId) {
  state.courses = state.courses.filter(c => c.id !== courseId);
  showToast("Course deleted.", "normal");
  setTrainerTab("courses");
  saveStateToStorage();
}

function renderTrainerKnowledgeHubView() {
  return `
    <button class="back-to-dash-btn" onclick="setTrainerTab('overview')">
      ← Back to Trainer Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Knowledge Hub</h2>
        <p style="font-size:0.88rem;">Upload documentation, cheatsheets, or handbook guides that trainees can download and view directly.</p>
      </div>
      <div>
        <button class="btn-primary" onclick="openTrainerUploadResourceModal()">
          + Upload New Resource
        </button>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.knowledgeResources.length > 0 ? state.knowledgeResources.map(res => `
        <div class="section-card" style="margin-bottom:0;">
          <span class="gap-severity-badge low">${res.resourceType || 'DOCUMENT'}</span>
          <h3 style="font-size:1.15rem; margin:0.4rem 0 0.25rem 0;">${res.title}</h3>
          <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
            Skill: <strong>${res.skillName}</strong>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-soft); padding-top:0.75rem; margin-top:0.75rem;">
            <button class="btn-danger" style="font-size:0.8rem;" onclick="deleteTrainerResource(${res.id})">Delete 🗑</button>
            <button class="btn-primary" style="font-size:0.8rem; padding:0.35rem 0.75rem;" onclick="openAndDownloadResource(${res.id})">
              Preview & Download
            </button>
          </div>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">📂</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Resources Uploaded Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Upload handbooks and study notes for your trainees.
          </p>
          <button class="btn-primary" onclick="openTrainerUploadResourceModal()">+ Upload Resource ➔</button>
        </div>
      `}
    </div>
  `;
}

function openTrainerUploadResourceModal() {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <h3 style="font-size:1.3rem;">Upload Knowledge Resource</h3>
      <p style="font-size:0.85rem; color:var(--slate-600);">Upload text, handbook notes, or select a file from your device.</p>
    </div>

    <form onsubmit="handleTrainerUploadResourceSubmit(event)">
      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Resource Title</label>
        <input type="text" id="new-res-title" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL Window Functions & CTE Master Guide">
      </div>

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Target Competency / Skill</label>
        <input type="text" id="new-res-skill" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL">
      </div>

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Pick Local File (Optional)</label>
        <input type="file" id="new-res-fileinput" class="chat-input-field" style="width:100%;" onchange="handleResourceFilePick(event)">
      </div>

      <div style="margin-bottom:1.25rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Resource Content (Text / Notes / Explanations)</label>
        <textarea id="new-res-content" required class="chat-input-field" style="width:100%; height:120px;" placeholder="# Enter guide content..."></textarea>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">Upload to Knowledge Hub ➔</button>
      </div>
    </form>
  `);
}

let pickedResourceFile = null;

function handleResourceFilePick(e) {
  const file = e.target.files[0];
  if (!file) return;

  pickedResourceFile = {
    name: file.name,
    type: file.type || "application/octet-stream",
    sizeKb: Math.max(1, Math.round(file.size / 1024)),
    dataUrl: null
  };

  const isTextLike = file.type.startsWith("text/") || file.name.endsWith(".txt") || file.name.endsWith(".md") || file.name.endsWith(".json");

  const reader = new FileReader();
  reader.onload = function(evt) {
    pickedResourceFile.dataUrl = evt.target.result;

    const titleInput = document.getElementById("new-res-title");
    if (titleInput && !titleInput.value) {
      titleInput.value = file.name.replace(/\.[^/.]+$/, "");
    }

    const contentTextarea = document.getElementById("new-res-content");
    if (contentTextarea) {
      if (isTextLike) {
        try {
          contentTextarea.value = atob(evt.target.result.split(',')[1]);
        } catch(err) {
          contentTextarea.value = `# ${file.name}\n\nTechnical resource documentation attached.`;
        }
      } else {
        contentTextarea.value = `Attached Document: ${file.name} (${pickedResourceFile.sizeKb} KB)\n\nThis is a verified presentation/document file for trainees. Downloading this resource delivers the exact ${file.name.split('.').pop().toUpperCase()} file.`;
      }
    }
  };
  reader.readAsDataURL(file);
}

function handleTrainerUploadResourceSubmit(e) {
  e.preventDefault();
  const title = document.getElementById("new-res-title").value.trim();
  const skill = document.getElementById("new-res-skill").value.trim();
  const content = document.getElementById("new-res-content").value.trim();

  let fileData = null;
  let fileName = null;
  let fileMime = "text/html";
  let fileSizeKb = Math.max(12, Math.round(content.length / 1024));

  if (pickedResourceFile && pickedResourceFile.dataUrl) {
    fileData = pickedResourceFile.dataUrl;
    fileName = pickedResourceFile.name;
    fileMime = pickedResourceFile.type;
    fileSizeKb = pickedResourceFile.sizeKb;
  }

  const newResource = {
    id: Date.now(),
    uploadedById: state.currentUser ? state.currentUser.id : 101,
    uploadedByName: state.currentUser ? state.currentUser.fullName : "Trainer",
    title: title,
    skillName: skill,
    category: "Technical Handbook",
    resourceType: fileName ? (fileName.split('.').pop().toUpperCase() + " DOCUMENT") : "HANDBOOK",
    fileContent: content,
    fileName: fileName,
    fileData: fileData,
    fileMime: fileMime,
    fileSizeKb: fileSizeKb,
    downloadCount: 0
  };

  state.knowledgeResources.push(newResource);
  pickedResourceFile = null;
  closeModal();
  triggerRealtimeNotification("New Handbook Available", `"${title}" was added to Knowledge Hub.`, "success");
  if (state.currentUser && state.currentUser.activeRole === "TRAINER") {
    setTrainerTab("knowledge-hub");
  } else if (state.currentUser && state.currentUser.activeRole === "ADMIN") {
    setAdminTab("knowledge-hub");
  }
  saveStateToStorage();
}

function deleteTrainerResource(resId) {
  state.knowledgeResources = state.knowledgeResources.filter(r => r.id !== resId);
  showToast("Resource deleted.", "normal");
  setTrainerTab("knowledge-hub");
  saveStateToStorage();
}

function renderTrainerAssessmentsView() {
  return `
    <button class="back-to-dash-btn" onclick="setTrainerTab('overview')">
      ← Back to Trainer Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Assessment Management</h2>
        <p style="font-size:0.88rem;">Create MCQs with answer keys to automatically grade trainee competencies.</p>
      </div>
      <div>
        <button class="btn-primary" onclick="openCreateAssessmentModal()">
          + Create Assessment
        </button>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.assessments.length > 0 ? state.assessments.map(a => `
        <div class="section-card" style="margin-bottom:0;">
          <span class="gap-severity-badge low">${a.skillName}</span>
          <h3 style="font-size:1.15rem; margin:0.4rem 0 0.25rem 0;">${a.title}</h3>
          <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
            Questions: <strong>${a.questions.length}</strong> • Passing Score: <strong>${a.passingScore}%</strong>
          </div>
          <button class="btn-danger" style="font-size:0.8rem; margin-top:0.5rem;" onclick="deleteTrainerAssessment(${a.id})">Delete 🗑</button>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <div style="font-size:2.5rem; margin-bottom:0.5rem;">📝</div>
          <h3 style="font-size:1.2rem; margin-bottom:0.35rem;">No Assessments Created Yet</h3>
          <p style="font-size:0.88rem; color:var(--slate-500); max-width:440px; margin:0 auto 1.25rem auto;">
            Click below to create an assessment for your learners.
          </p>
          <button class="btn-primary" onclick="openCreateAssessmentModal()">+ Create Assessment ➔</button>
        </div>
      `}
    </div>
  `;
}

function openCreateAssessmentModal() {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <h3 style="font-size:1.3rem;">Create New Assessment</h3>
    </div>

    <form onsubmit="handleCreateAssessmentSubmit(event)">
      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Assessment Title</label>
        <input type="text" id="new-exam-title" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL Queries & Joins Proficiency Test">
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Target Competency / Skill</label>
          <input type="text" id="new-exam-skill" required class="chat-input-field" style="width:100%;" placeholder="e.g. SQL">
        </div>
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Target Proficiency Level (1-5)</label>
          <select id="new-exam-target-level" class="chat-input-field" style="width:100%;">
            <option value="2">Level 2 — Basic</option>
            <option value="3" selected>Level 3 — Intermediate</option>
            <option value="4">Level 4 — Advanced</option>
            <option value="5">Level 5 — Expert</option>
          </select>
        </div>
      </div>

      <div style="border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1rem; margin-bottom:1rem; background:var(--slate-50);">
        <strong style="font-size:0.9rem; display:block; margin-bottom:0.5rem;">Question 1 (MCQ)</strong>
        <input type="text" id="q1-text" required class="chat-input-field" style="width:100%; margin-bottom:0.5rem;" placeholder="Type question...">
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.5rem; margin-bottom:0.5rem;">
          <input type="text" id="q1-a" required class="chat-input-field" placeholder="Option A">
          <input type="text" id="q1-b" required class="chat-input-field" placeholder="Option B">
          <input type="text" id="q1-c" required class="chat-input-field" placeholder="Option C">
          <input type="text" id="q1-d" required class="chat-input-field" placeholder="Option D">
        </div>
        <div style="display:flex; align-items:center; gap:0.5rem;">
          <label style="font-size:0.8rem; font-weight:700;">Correct Answer Key:</label>
          <select id="q1-key" class="chat-input-field">
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="C">C</option>
            <option value="D">D</option>
          </select>
        </div>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">Save & Publish Assessment ➔</button>
      </div>
    </form>
  `);
}

function handleCreateAssessmentSubmit(e) {
  e.preventDefault();
  const title = document.getElementById("new-exam-title").value.trim();
  const skill = document.getElementById("new-exam-skill").value.trim();
  const targetLevel = parseInt(document.getElementById("new-exam-target-level").value, 10);

  const q1Text = document.getElementById("q1-text").value.trim();
  const q1A = document.getElementById("q1-a").value.trim();
  const q1B = document.getElementById("q1-b").value.trim();
  const q1C = document.getElementById("q1-c").value.trim();
  const q1D = document.getElementById("q1-d").value.trim();
  const q1Key = document.getElementById("q1-key").value;

  const newAssessment = {
    id: Date.now(),
    trainerId: state.currentUser.id,
    title: title,
    skillName: skill,
    duration: 15,
    passingScore: 75,
    targetProficiency: targetLevel,
    category: "Technical Assessment",
    questions: [
      {
        id: 1,
        question: q1Text,
        options: [q1A, q1B, q1C, q1D],
        correctOption: q1Key,
        explanation: `The correct answer is Option ${q1Key}.`
      }
    ]
  };

  state.assessments.push(newAssessment);
  closeModal();
  triggerRealtimeNotification("Assessment Ready", `"${title}" is now open for trainee evaluation.`, "success");
  setTrainerTab("assessments");
  saveStateToStorage();
}

function deleteTrainerAssessment(examId) {
  state.assessments = state.assessments.filter(a => a.id !== examId);
  showToast("Assessment deleted.", "normal");
  setTrainerTab("assessments");
  saveStateToStorage();
}

// ============================================================================
// 4. ADMIN DASHBOARD (EXECUTIVE GOVERNANCE & CO-ADMIN VERIFICATION)
// ============================================================================
function renderAdminDashboard(container) {
  container.innerHTML = `
    <div class="dashboard-container" id="admin-dashboard-container">
      ${renderAdminTabContent()}
    </div>
  `;
}

function setAdminTab(tabName) {
  state.currentTab = tabName;
  const container = document.getElementById("admin-dashboard-container");
  if (container) {
    container.innerHTML = renderAdminTabContent();
  }
}

function renderAdminTabContent() {
  switch (state.currentTab) {
    case "users":
      return renderAdminUserMgmtView();
    case "courses":
      return renderAdminCourseMgmtView();
    case "knowledge-hub":
      return renderAdminKnowledgeHubView();
    default:
      return renderAdminModularOverview();
  }
}

function renderAdminModularOverview() {
  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? "Good morning" : (hour < 17 ? "Good afternoon" : "Good evening");
  const traineeCount = state.allUsers.filter(u => u.role === "TRAINEE").length;
  const trainerCount = state.allUsers.filter(u => u.role === "TRAINER").length;
  const pendingCoAdmin = state.coAdminRequests.filter(r => r.status === "PENDING").length;

  return `
    <!-- Distinct Executive Admin Header -->
    <div class="dashboard-welcome-header" style="background: linear-gradient(135deg, #1E1B4B 0%, #312E81 100%); color: #FFFFFF; border-radius: var(--radius-lg); padding: 2rem; border-left: 6px solid #6366F1;">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; width:100%; flex-wrap:wrap; gap:1rem;">
        <div>
          <div style="font-size:0.8rem; font-weight:800; color:#A5B4FC; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:0.35rem;">
            🛡️ Platform Governance & System Administration
          </div>
          <div style="font-size:1.85rem; font-weight:800; margin-bottom:0.4rem; letter-spacing:-0.02em;">
            ${timeGreeting}, ${state.currentUser.fullName}
          </div>
          <p style="font-size:0.92rem; color:#C7D2FE; max-width:680px; line-height:1.5;">
            Master Administrator console active for <strong>gayathri@gmail.com</strong>. You hold full authority to moderate courses, manage users, and authorize Co-Administrators.
          </p>
        </div>
        <div style="background:rgba(255,255,255,0.12); backdrop-filter:blur(8px); padding:0.6rem 1rem; border-radius:var(--radius-md); border:1px solid rgba(255,255,255,0.2); font-size:0.82rem; font-weight:700;">
          <span style="color:#34D399; margin-right:0.3rem;">●</span> MASTER ACCESS
        </div>
      </div>
    </div>

    <!-- Co-Admin Authorization Banner -->
    ${pendingCoAdmin > 0 ? `
      <div style="background:#FEF3C7; border:1px solid #FCD34D; border-radius:var(--radius-md); padding:1rem 1.25rem; margin-top:1.5rem; display:flex; justify-content:space-between; align-items:center;">
        <div style="display:flex; align-items:center; gap:0.75rem;">
          <span style="font-size:1.6rem;">🔑</span>
          <div>
            <strong style="color:#92400E; font-size:0.95rem;">Co-Admin Authorization Requested!</strong>
            <div style="font-size:0.85rem; color:#78350F;">
              ${pendingCoAdmin} user(s) are requesting Co-Admin authorization codes.
            </div>
          </div>
        </div>
        <button class="btn-primary" style="padding:0.45rem 0.95rem; font-size:0.82rem;" onclick="setAdminTab('users')">
          View 4-Digit Security Codes ➔
        </button>
      </div>
    ` : ''}

    <!-- 4 Executive Metric Cards -->
    <div class="metric-cards-grid-4" style="margin-top:1.5rem;">
      <div class="metric-card">
        <div class="metric-icon-box indigo">👥</div>
        <div>
          <div class="metric-title">Total Users</div>
          <div class="metric-val">${state.allUsers.length}</div>
          <div style="font-size:0.75rem; color:var(--slate-500); margin-top:0.2rem;">${traineeCount} Trainees • ${trainerCount} Trainers</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box emerald">⚡</div>
        <div>
          <div class="metric-title">Organizational Index</div>
          <div class="metric-val">84.6%</div>
          <div style="font-size:0.75rem; color:var(--emerald); margin-top:0.2rem;">+4.2% competency growth</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box amber">📚</div>
        <div>
          <div class="metric-title">Learning Ecosystem</div>
          <div class="metric-val">${state.courses.length + state.knowledgeResources.length}</div>
          <div style="font-size:0.75rem; color:var(--slate-500); margin-top:0.2rem;">${state.courses.length} Courses • ${state.knowledgeResources.length} Handbooks</div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon-box rose">🔑</div>
        <div>
          <div class="metric-title">Co-Admin Access</div>
          <div class="metric-val">${pendingCoAdmin}</div>
          <div style="font-size:0.75rem; color:var(--rose); margin-top:0.2rem;">Pending Authorization</div>
        </div>
      </div>
    </div>

    <!-- Top Organizational Competency Deficiencies -->
    <div class="section-card" style="margin-top:1.5rem;">
      <div class="section-card-title" style="margin-bottom:0.35rem;">Organizational Competency Benchmark Trajectory</div>
      <p style="font-size:0.85rem; color:var(--slate-600); margin-bottom:1.25rem;">Aggregated real-time proficiency across all active learners.</p>
      
      <div style="display:flex; flex-direction:column; gap:0.85rem;">
        <div>
          <div style="display:flex; justify-content:space-between; font-size:0.85rem; font-weight:700; margin-bottom:0.3rem;">
            <span>SQL Database Optimization & Joins</span>
            <span style="color:var(--primary);">Level 3.4 / 4.0 (85% Target Met)</span>
          </div>
          <div class="progress-bar-container"><div class="progress-fill" style="width:85%;"></div></div>
        </div>

        <div>
          <div style="display:flex; justify-content:space-between; font-size:0.85rem; font-weight:700; margin-bottom:0.3rem;">
            <span>Python Data Automation & Scripting</span>
            <span style="color:var(--emerald);">Level 2.8 / 3.0 (93% Target Met)</span>
          </div>
          <div class="progress-bar-container"><div class="progress-fill" style="width:93%; background:var(--emerald);"></div></div>
        </div>

        <div>
          <div style="display:flex; justify-content:space-between; font-size:0.85rem; font-weight:700; margin-bottom:0.3rem;">
            <span>Power BI & Business Intelligence DAX</span>
            <span style="color:var(--amber);">Level 2.1 / 3.0 (70% Target Met)</span>
          </div>
          <div class="progress-bar-container"><div class="progress-fill" style="width:70%; background:var(--amber);"></div></div>
        </div>
      </div>
    </div>

    <!-- Administrative Action Grid -->
    <h3 style="font-size:1.2rem; margin:1.5rem 0 1.25rem 0;">Administrative Control Modules</h3>
    <div class="capability-grid">

      <div class="capability-card" onclick="setAdminTab('users')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--primary); background:var(--primary-light);">👥</div>
            <div class="capability-card-title">User Governance & Co-Admin Codes</div>
          </div>
          <div class="capability-status-line">
            ${state.allUsers.length} registered users • ${pendingCoAdmin} pending authorization codes
          </div>
          <div class="capability-card-desc">
            Manage account permissions, generate 4-digit Co-Admin codes, and delete users.
          </div>
        </div>
        <div class="capability-action-btn">
          Manage Users ➔
        </div>
      </div>

      <div class="capability-card" onclick="setAdminTab('courses')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--emerald); background:var(--emerald-light);">📚</div>
            <div class="capability-card-title">Course Moderation</div>
          </div>
          <div class="capability-status-line" style="color:var(--emerald);">
            ${state.courses.length} courses published
          </div>
          <div class="capability-card-desc">
            Review and delete courses published by any trainer across the organization.
          </div>
        </div>
        <div class="capability-action-btn">
          Manage Courses ➔
        </div>
      </div>

      <div class="capability-card" onclick="setAdminTab('knowledge-hub')">
        <div>
          <div class="capability-card-header">
            <div class="capability-icon-pill" style="color:var(--amber); background:var(--amber-light);">📂</div>
            <div class="capability-card-title">Knowledge Hub Moderation</div>
          </div>
          <div class="capability-status-line" style="color:var(--amber);">
            ${state.knowledgeResources.length} active documents
          </div>
          <div class="capability-card-desc">
            Full administrative authority to inspect, edit, or delete any uploaded handbook.
          </div>
        </div>
        <div class="capability-action-btn">
          Moderate Knowledge Hub ➔
        </div>
      </div>

    </div>
  `;
}

// ─── USER MANAGEMENT (INCLUDES CO-ADMIN 4-DIGIT VERIFICATION CODES) ───────────
function renderAdminUserMgmtView() {
  const pendingRequests = state.coAdminRequests.filter(r => r.status === "PENDING");

  return `
    <button class="back-to-dash-btn" onclick="setAdminTab('overview')">
      ← Back to Admin Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">User Management & Access Governance</h2>
        <p style="font-size:0.88rem;">Master Admin: <strong>K. GAYATHRI SRIVALLI</strong> • Authorize Co-Admins using secure 4-digit codes.</p>
      </div>
    </div>

    <!-- Co-Admin Authorization Codes Section -->
    <div class="section-card" style="margin-bottom:2rem; border-left:4px solid var(--primary);">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
        <div>
          <h3 style="font-size:1.2rem; color:var(--slate-900);">🔑 Co-Admin Access Requests & 4-Digit Security Codes</h3>
          <p style="font-size:0.84rem; color:var(--slate-600);">
            Share this 4-digit verification code with the user to authorize them as a Co-Administrator.
          </p>
        </div>
        <span class="gap-severity-badge ${pendingRequests.length > 0 ? 'medium' : 'low'}">
          ${pendingRequests.length} Pending
        </span>
      </div>

      ${pendingRequests.length > 0 ? `
        <div style="display:flex; flex-direction:column; gap:1rem;">
          ${pendingRequests.map(req => `
            <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1.25rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
              <div>
                <strong style="font-size:1.05rem; color:var(--slate-900);">${req.fullName}</strong>
                <div style="font-size:0.85rem; color:var(--slate-600);">${req.email} • Requested at ${req.requestedAt}</div>
                <div style="font-size:0.8rem; color:var(--primary); font-weight:700; margin-top:0.25rem;">Role Requested: Co-Administrator</div>
              </div>

              <div style="display:flex; align-items:center; gap:1.25rem;">
                <div style="text-align:center;">
                  <span style="font-size:0.75rem; font-weight:800; color:var(--slate-500); text-transform:uppercase;">Security PIN Code:</span>
                  <div class="pin-code-display" style="margin:0.25rem 0;">
                    ${req.code.split('').map(d => `<span class="pin-digit-box">${d}</span>`).join('')}
                  </div>
                </div>

                <div style="display:flex; flex-direction:column; gap:0.4rem;">
                  <button class="btn-secondary" style="font-size:0.8rem; padding:0.4rem 0.75rem;" onclick="copyCoAdminCode('${req.code}')">
                    📋 Copy Code
                  </button>
                  <button class="btn-primary" style="font-size:0.8rem; padding:0.4rem 0.75rem;" onclick="directApproveCoAdmin(${req.id})">
                    Approve Directly ✓
                  </button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      ` : `
        <div style="text-align:center; padding:1.5rem; background:var(--slate-50); border-radius:var(--radius-md); font-size:0.88rem; color:var(--slate-500);">
          No pending Co-Admin requests. When someone requests admin access, their 4-digit authorization code will appear here.
        </div>
      `}
    </div>

    <!-- Registered Users Table -->
    <div class="section-card">
      <div class="section-card-title" style="margin-bottom:1rem;">All Registered Platform Users</div>
      <div style="overflow-x:auto;">
        <table style="width:100%; border-collapse:collapse; font-size:0.9rem; text-align:left;">
          <thead>
            <tr style="border-bottom:2px solid var(--border-soft); color:var(--slate-500); font-size:0.78rem; text-transform:uppercase;">
              <th style="padding:0.75rem;">Name</th>
              <th style="padding:0.75rem;">Email</th>
              <th style="padding:0.75rem;">Role</th>
              <th style="padding:0.75rem; text-align:right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${state.allUsers.map(user => `
              <tr style="border-bottom:1px solid var(--border-soft);">
                <td style="padding:1rem; font-weight:700;">
                  ${user.fullName}
                  ${user.isMasterAdmin ? '<span style="font-size:0.7rem; background:#4F46E5; color:#fff; padding:0.15rem 0.4rem; border-radius:4px; margin-left:0.4rem;">MASTER ADMIN</span>' : ''}
                </td>
                <td style="padding:1rem; color:var(--slate-600);">${user.email}</td>
                <td style="padding:1rem;">
                  <span class="gap-severity-badge ${user.role.includes('ADMIN') ? 'high' : (user.role === 'TRAINER' ? 'medium' : 'low')}">
                    ${user.role}
                  </span>
                </td>
                <td style="padding:1rem; text-align:right;">
                  ${!user.isMasterAdmin ? `
                    <button class="btn-danger" onclick="adminDeleteUser(${user.id}, '${user.fullName}')">
                      Delete Account 🗑
                    </button>
                  ` : `
                    <span style="font-size:0.8rem; color:var(--slate-400); font-weight:700;">Master Protected</span>
                  `}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function copyCoAdminCode(code) {
  navigator.clipboard.writeText(code);
  showToast(`Code ${code} copied! Share with prospective Co-Admin.`, "success");
}

function directApproveCoAdmin(reqId) {
  const req = state.coAdminRequests.find(r => r.id === reqId);
  if (req) {
    req.status = "APPROVED";
    const user = state.allUsers.find(u => u.id === req.userId);
    if (user) {
      user.role = "CO-ADMIN";
      user.isCoAdmin = true;
    }
    triggerRealtimeNotification("Co-Admin Approved", `${req.fullName} was granted Co-Admin access.`, "success");
    setAdminTab("users");
    saveStateToStorage();
  }
}

function adminDeleteUser(userId, name) {
  if (confirm(`Delete account for "${name}"? This action cannot be undone.`)) {
    state.allUsers = state.allUsers.filter(u => u.id !== userId);
    state.trainers = state.trainers.filter(t => t.id !== userId);
    state.coAdminRequests = state.coAdminRequests.filter(r => r.userId !== userId);
    showToast(`Account for "${name}" deleted.`, "normal");
    setAdminTab("users");
    saveStateToStorage();
  }
}

function renderAdminCourseMgmtView() {
  return `
    <button class="back-to-dash-btn" onclick="setAdminTab('overview')">
      ← Back to Admin Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Course Moderation</h2>
        <p style="font-size:0.88rem;">Review and delete any course published by trainers.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.courses.length > 0 ? state.courses.map(c => `
        <div class="section-card" style="margin-bottom:0; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <span class="gap-severity-badge low">${c.category}</span>
            <h3 style="font-size:1.15rem; margin:0.4rem 0 0.25rem 0;">${c.title}</h3>
            <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
              Trainer: <strong>${c.trainerName}</strong> • Skill: <strong>${c.skillName}</strong>
            </div>
            <p style="font-size:0.85rem; line-height:1.45; margin-bottom:1rem;">${c.description}</p>
          </div>

          <div style="border-top:1px solid var(--border-soft); padding-top:1rem; text-align:right;">
            <button class="btn-danger" style="width:100%; justify-content:center;" onclick="adminDeleteCourse(${c.id}, '${c.title}')">
              Delete Course 🗑
            </button>
          </div>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <p style="color:var(--slate-500);">No courses to moderate.</p>
        </div>
      `}
    </div>
  `;
}

function adminDeleteCourse(courseId, title) {
  if (confirm(`Delete course "${title}"?`)) {
    state.courses = state.courses.filter(c => c.id !== courseId);
    showToast(`Course "${title}" removed.`, "normal");
    setAdminTab("courses");
    saveStateToStorage();
  }
}

function renderAdminKnowledgeHubView() {
  return `
    <button class="back-to-dash-btn" onclick="setAdminTab('overview')">
      ← Back to Admin Dashboard
    </button>

    <div class="dashboard-welcome-header">
      <div>
        <h2 style="font-size:1.5rem; margin-bottom:0.25rem;">Knowledge Hub Moderation</h2>
        <p style="font-size:0.88rem;">Moderate technical documentation and handbook files.</p>
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:1.5rem;">
      ${state.knowledgeResources.length > 0 ? state.knowledgeResources.map(res => `
        <div class="section-card" style="margin-bottom:0; display:flex; flex-direction:column; justify-content:space-between;">
          <div>
            <span class="gap-severity-badge low">${res.resourceType || 'DOCUMENT'}</span>
            <h3 style="font-size:1.15rem; margin:0.4rem 0 0.25rem 0;">${res.title}</h3>
            <div style="font-size:0.82rem; color:var(--slate-600); margin-bottom:0.5rem;">
              Author: <strong>${res.uploadedByName}</strong> • Skill: <strong>${res.skillName}</strong>
            </div>
          </div>

          <div style="border-top:1px solid var(--border-soft); padding-top:1rem; text-align:right;">
            <button class="btn-danger" style="width:100%; justify-content:center;" onclick="adminDeleteResource(${res.id}, '${res.title}')">
              Delete Resource 🗑
            </button>
          </div>
        </div>
      `).join('') : `
        <div style="text-align:center; padding:3rem 1.5rem; background:var(--bg-card); border:1px dashed var(--border-soft); border-radius:var(--radius-lg); grid-column: 1 / -1;">
          <p style="color:var(--slate-500);">No knowledge resources to moderate.</p>
        </div>
      `}
    </div>
  `;
}

function adminDeleteResource(resId, title) {
  if (confirm(`Delete knowledge resource "${title}"?`)) {
    state.knowledgeResources = state.knowledgeResources.filter(r => r.id !== resId);
    showToast(`Resource "${title}" deleted.`, "normal");
    setAdminTab("knowledge-hub");
    saveStateToStorage();
  }
}

// ============================================================================
// MODALS & DIALOGS (WITH FUNCTIONAL MACOS TRAFFIC LIGHTS)
// ============================================================================
function openModal(htmlContent) {
  const modalBody = document.getElementById("modal-body");
  const modalOverlay = document.getElementById("modal-overlay");
  const modalContent = document.getElementById("main-modal-content");
  if (modalBody && modalOverlay) {
    if (modalContent) {
      modalContent.classList.remove("fullscreen", "minimized");
    }
    modalBody.innerHTML = htmlContent;
    modalOverlay.style.display = "flex";
  }
}

function closeModal() {
  const modalOverlay = document.getElementById("modal-overlay");
  const modalContent = document.getElementById("main-modal-content");
  if (modalContent) {
    modalContent.classList.remove("fullscreen", "minimized");
  }
  if (modalOverlay) modalOverlay.style.display = "none";
}

function toggleMinimizeModal() {
  const modalContent = document.getElementById("main-modal-content");
  if (modalContent) {
    modalContent.classList.toggle("minimized");
    showToast(modalContent.classList.contains("minimized") ? "Window Minimized" : "Window Restored", "normal");
  }
}

function toggleFullscreenModal() {
  const modalContent = document.getElementById("main-modal-content");
  if (modalContent) {
    modalContent.classList.toggle("fullscreen");
    showToast(modalContent.classList.contains("fullscreen") ? "Fullscreen Mode" : "Normal Mode", "normal");
  }
}

// ─── AUTH MODAL ─────────────────────────────────────────────────────────────
function openAuthModal(mode) {
  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem; text-align:center;">
      <h2 style="font-size:1.6rem; margin-bottom:0.25rem;">
        ${mode === 'signup' ? 'Create Your Account' : 'Sign In to CAPACITY CONNECT'}
      </h2>
      <p style="font-size:0.88rem; color:var(--slate-600);">
        ${mode === 'signup' ? 'Enter your details to create your personalized secure account.' : 'Access your personalized dashboard.'}
      </p>
    </div>

    <form onsubmit="handleAuthSubmit(event, '${mode}')">
      ${mode === 'signup' ? `
        <div style="margin-bottom:1rem;">
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Full Name</label>
          <input type="text" id="auth-name" required class="chat-input-field" style="width:100%;" placeholder="e.g. K. GAYATHRI SRIVALLI">
        </div>
      ` : ''}

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Email Address (Gmail / Corporate)</label>
        <input type="email" id="auth-email" required class="chat-input-field" style="width:100%;" placeholder="e.g. gayathri@gmail.com">
      </div>

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Password</label>
        <input type="password" id="auth-password" required class="chat-input-field" style="width:100%;" placeholder="Design your password">
      </div>

      ${mode === 'signup' ? `
        <div style="margin-bottom:1.25rem;">
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Account Role</label>
          <select id="auth-role" class="chat-input-field" style="width:100%;">
            <option value="TRAINEE" selected>Trainee / Learner</option>
            <option value="TRAINER">Trainer / Mentor</option>
            <option value="ADMIN">System Administrator</option>
          </select>
        </div>
      ` : ''}

      ${mode === 'signin' ? `
        <div style="margin-bottom:1.25rem; padding:0.75rem 1rem; background:rgba(99,102,241,0.08); border:1px solid rgba(99,102,241,0.25); border-radius:var(--radius-md); text-align:center;">
          <div style="font-size:0.78rem; font-weight:700; color:var(--primary); margin-bottom:0.35rem; text-transform:uppercase;">Master Administrator Login</div>
          <button type="button" class="btn-secondary" style="font-size:0.82rem; padding:0.4rem 0.8rem; width:100%; justify-content:center;" onclick="quickFillMasterAdmin()">
            👑 Fast-Fill Master Admin (K. GAYATHRI SRIVALLI)
          </button>
        </div>
      ` : ''}

      <button type="submit" class="btn-primary" style="width:100%; justify-content:center; padding:0.8rem; font-size:1rem;">
        ${mode === 'signup' ? 'Create Account & Enter Platform ➔' : 'Sign In ➔'}
      </button>

      <div style="text-align:center; margin-top:1.25rem; font-size:0.85rem; color:var(--slate-600);">
        ${mode === 'signup' ? `
          Already have an account? <a href="javascript:void(0)" onclick="openAuthModal('signin')">Sign In</a>
        ` : `
          New here? <a href="javascript:void(0)" onclick="openAuthModal('signup')">Create Your Account</a>
        `}
      </div>
    </form>
  `);
}

function quickFillMasterAdmin() {
  const email = document.getElementById("auth-email");
  const pwd = document.getElementById("auth-password");
  if (email) email.value = "gayathri@gmail.com";
  if (pwd) pwd.value = "Admin@123";
}

function handleAuthSubmit(e, mode) {
  e.preventDefault();
  const email = document.getElementById("auth-email").value.trim();
  
  if (mode === "signup") {
    const name = document.getElementById("auth-name").value.trim();
    const role = document.getElementById("auth-role").value;
    const userId = Date.now();

    const isGayathri = email.toLowerCase() === "gayathri@gmail.com";
    const hasExistingAdmin = state.allUsers.some(u => u.role === "ADMIN" || u.isMasterAdmin);

    if (role === "ADMIN" && hasExistingAdmin && !isGayathri) {
      const code = Math.floor(1000 + Math.random() * 9000).toString();
      const req = {
        id: userId,
        userId: userId,
        fullName: name,
        email: email,
        code: code,
        status: "PENDING",
        requestedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      // Register the applicant as a base user in allUsers
      const pendingUser = {
        id: userId,
        fullName: name,
        email: email,
        primaryRole: "TRAINEE",
        activeRole: "TRAINEE",
        isMasterAdmin: false,
        isCoAdmin: false,
        isAdmin: false,
        avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
        bio: "Learner & Applicant.",
        careerScore: 25,
        streak: 1,
        learningProgress: 0
      };
      state.currentUser = pendingUser;
      state.allUsers.push({ id: userId, fullName: name, email: email, role: "TRAINEE", isMasterAdmin: false, isCoAdmin: false });

      state.coAdminRequests.unshift(req);
      
      // Notification stored for Master Admin
      state.notifications.unshift({
        id: Date.now(),
        type: "alert",
        title: "New Co-Admin Request",
        desc: `${name} (${email}) requested Co-Admin access (PIN: ${code})`,
        time: "Just now",
        read: false
      });

      // User gets notice WITHOUT revealing the PIN
      showToast("Co-Admin request registered. Ask Master Admin K. GAYATHRI SRIVALLI for your 4-digit approval code.", "normal");

      openCoAdminPinEntryModal(req.id, code);
      saveStateToStorage();
      return;
    }

    const isMaster = (role === "ADMIN" && !hasExistingAdmin) || isGayathri;

    const newUser = {
      id: userId,
      fullName: name,
      email: email,
      primaryRole: role,
      activeRole: role,
      isMasterAdmin: isMaster,
      isCoAdmin: false,
      isAdmin: role === "ADMIN" || isMaster,
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
      bio: role === "TRAINER" ? "Senior Mentor & Subject Matter Expert." : (role === "ADMIN" ? "Master System Administrator." : "Passionate learner."),
      skillsTaught: role === "TRAINER" ? "Technical Problem Solving" : "",
      skillsWants: role === "TRAINER" ? "Leadership & Public Speaking" : "",
      primaryExpertise: role === "TRAINER" ? "Domain Expert" : "",
      experienceYears: role === "TRAINER" ? 5 : 1,
      rating: 5.0,
      careerScore: 25,
      streak: 1,
      learningProgress: 10
    };

    state.currentUser = newUser;
    state.allUsers.push({ id: userId, fullName: name, email: email, role: role, isMasterAdmin: isMaster, isCoAdmin: false });

    if (role === "TRAINER") {
      state.trainers.push({
        id: userId,
        fullName: name,
        avatarUrl: newUser.avatarUrl,
        primaryExpertise: "Domain Expert",
        skillsTaught: "Technical Problem Solving",
        skillsWants: "Leadership & Public Speaking",
        experienceYears: 5,
        rating: 5.0,
        availabilityStatus: "Available",
        bio: newUser.bio
      });
    }

    closeModal();
    triggerRealtimeNotification("Account Created", `Welcome to CAPACITY CONNECT, ${name}!`, "success");
    showView(role.toLowerCase());
    saveStateToStorage();
  } else {
    const isGayathri = email.toLowerCase() === "gayathri@gmail.com";
    let existing = state.allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (isGayathri) {
      state.currentUser = masterAdminUser;
      showView("admin");
    } else if (existing) {
      state.currentUser = {
        id: existing.id,
        fullName: existing.fullName,
        email: existing.email,
        primaryRole: existing.role,
        activeRole: existing.role,
        isMasterAdmin: !!existing.isMasterAdmin,
        isCoAdmin: !!existing.isCoAdmin,
        isAdmin: existing.role.includes("ADMIN"),
        avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
        bio: "User profile.",
        careerScore: 30,
        streak: 1,
        learningProgress: 20
      };
      showView(state.currentUser.activeRole.toLowerCase());
    } else {
      state.currentUser = {
        id: Date.now(),
        fullName: email.split('@')[0],
        email: email,
        primaryRole: "TRAINEE",
        activeRole: "TRAINEE",
        isMasterAdmin: false,
        isCoAdmin: false,
        isAdmin: false,
        avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
        bio: "Learner.",
        careerScore: 20,
        streak: 1,
        learningProgress: 0
      };
      state.allUsers.push({ id: state.currentUser.id, fullName: state.currentUser.fullName, email: email, role: "TRAINEE", isMasterAdmin: false });
      showView("trainee");
    }
    closeModal();
    triggerRealtimeNotification("Signed In", `Welcome back, ${state.currentUser.fullName}!`, "success");
    saveStateToStorage();
  }
}

// ─── PROFILE MODAL ───────────────────────────────────────────────────────────
function openProfileModal() {
  if (!state.currentUser) return;
  const user = state.currentUser;
  const isTrainer = user.activeRole === "TRAINER";

  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem; text-align:center;">
      <h3 style="font-size:1.4rem;">Edit Your Profile & Skills</h3>
      <p style="font-size:0.85rem; color:var(--slate-600);">Upload your photo, write your bio, and declare your skills.</p>
    </div>

    <form onsubmit="handleSaveProfileSubmit(event)">
      <div style="display:flex; align-items:center; gap:1.25rem; margin-bottom:1.5rem; background:var(--slate-50); padding:1rem; border-radius:var(--radius-md); border:1px solid var(--border-soft);">
        <img id="profile-preview-img" src="${user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" style="width:72px; height:72px; border-radius:50%; object-fit:cover; border:2px solid var(--primary);">
        <div style="flex-grow:1;">
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.35rem;">Upload Profile Photo (Local Image File)</label>
          <input type="file" id="profile-photo-file-input" accept="image/*" class="chat-input-field" style="width:100%; font-size:0.8rem;" onchange="handleProfilePhotoFileChange(event)">
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Full Name</label>
          <input type="text" id="profile-name-input" value="${user.fullName}" required class="chat-input-field" style="width:100%;">
        </div>
        <div>
          <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Email Address</label>
          <input type="email" id="profile-email-input" value="${user.email}" required class="chat-input-field" style="width:100%;">
        </div>
      </div>

      <div style="margin-bottom:1rem;">
        <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">About Me / Bio</label>
        <textarea id="profile-bio-input" class="chat-input-field" style="width:100%; height:75px;" placeholder="Describe your background, learning aspirations, or teaching expertise...">${user.bio || ''}</textarea>
      </div>

      ${!isTrainer ? `
        <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1rem; margin-bottom:1.25rem;">
          <label style="font-size:0.82rem; font-weight:800; display:block; margin-bottom:0.4rem; color:var(--slate-900);">
            Skills You Currently Possess & Proficiency (Level 1 to 5)
          </label>
          <p style="font-size:0.78rem; color:var(--slate-600); margin-bottom:0.75rem;">
            Add your current skills to calculate real-time AI Skill Gaps against organizational benchmarks.
          </p>

          <div style="display:flex; gap:0.5rem; margin-bottom:0.75rem;">
            <input type="text" id="add-skill-name" class="chat-input-field" style="flex-grow:1;" placeholder="Skill Name (e.g. SQL, Python, Excel)">
            <select id="add-skill-level" class="chat-input-field" style="width:130px;">
              <option value="1">Level 1 (Beginner)</option>
              <option value="2">Level 2 (Basic)</option>
              <option value="3" selected>Level 3 (Intermediate)</option>
              <option value="4">Level 4 (Advanced)</option>
              <option value="5">Level 5 (Expert)</option>
            </select>
            <button type="button" class="btn-primary" onclick="addCompetencyFromProfile()">+ Add</button>
          </div>

          <div id="profile-skills-tags-container" style="display:flex; flex-wrap:wrap; gap:0.4rem;">
            ${state.userCompetencies.map(c => `
              <span style="background:#fff; border:1px solid var(--border-soft); border-radius:var(--radius-full); padding:0.25rem 0.65rem; font-size:0.8rem; display:inline-flex; align-items:center; gap:0.4rem;">
                <strong>${c.skill}</strong>: Level ${c.current}/5
                <span style="cursor:pointer; color:var(--rose); font-weight:bold;" onclick="removeCompetencyFromProfile('${c.skill}')">✕</span>
              </span>
            `).join('')}
          </div>
        </div>
      ` : `
        <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1rem; margin-bottom:1.25rem;">
          <div style="margin-bottom:0.75rem;">
            <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Primary Expertise Area</label>
            <input type="text" id="profile-trainer-expertise" value="${user.primaryExpertise || ''}" class="chat-input-field" style="width:100%;" placeholder="e.g. Database Architecture & SQL Optimization">
          </div>
          <div style="margin-bottom:0.75rem;">
            <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Skills You Teach (comma-separated)</label>
            <input type="text" id="profile-trainer-taught" value="${user.skillsTaught || ''}" class="chat-input-field" style="width:100%;" placeholder="e.g. SQL, PostgreSQL, Data Modeling">
          </div>
          <div>
            <label style="font-size:0.82rem; font-weight:700; display:block; margin-bottom:0.25rem;">Skills You Wish to Learn in Return (for Exchange)</label>
            <input type="text" id="profile-trainer-wants" value="${user.skillsWants || ''}" class="chat-input-field" style="width:100%;" placeholder="e.g. Public Speaking, UI Design">
          </div>
        </div>
      `}

      <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1.5rem;">
        <button type="button" class="btn-secondary" onclick="closeModal(); handleLogout();">Log Out</button>
        <div style="display:flex; gap:0.5rem;">
          <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
          <button type="submit" class="btn-primary">Save Profile Changes ➔</button>
        </div>
      </div>
    </form>
  `);
}

function handleProfilePhotoFileChange(e) {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function(evt) {
      const dataUrl = evt.target.result;
      document.getElementById("profile-preview-img").src = dataUrl;
      state.currentUser.avatarUrl = dataUrl;
    };
    reader.readAsDataURL(file);
  }
}

function addCompetencyFromProfile() {
  const nameInput = document.getElementById("add-skill-name");
  const levelSelect = document.getElementById("add-skill-level");
  if (!nameInput || !nameInput.value.trim()) return;

  const skillName = nameInput.value.trim();
  const level = parseInt(levelSelect.value, 10);

  let comp = state.userCompetencies.find(c => c.skill.toLowerCase() === skillName.toLowerCase());
  if (comp) {
    comp.current = level;
  } else {
    state.userCompetencies.push({
      skill: skillName,
      current: level,
      evidence: "Self-Reported in Profile",
      confidence: 0.90
    });
  }

  nameInput.value = "";
  openProfileModal();
  saveStateToStorage();
}

function removeCompetencyFromProfile(skillName) {
  state.userCompetencies = state.userCompetencies.filter(c => c.skill.toLowerCase() !== skillName.toLowerCase());
  openProfileModal();
  saveStateToStorage();
}

function handleSaveProfileSubmit(e) {
  e.preventDefault();
  const name = document.getElementById("profile-name-input").value.trim();
  const email = document.getElementById("profile-email-input").value.trim();
  const bio = document.getElementById("profile-bio-input").value.trim();

  state.currentUser.fullName = name;
  state.currentUser.email = email;
  state.currentUser.bio = bio;

  const expInput = document.getElementById("profile-trainer-expertise");
  const taughtInput = document.getElementById("profile-trainer-taught");
  const wantsInput = document.getElementById("profile-trainer-wants");

  if (expInput) state.currentUser.primaryExpertise = expInput.value.trim();
  if (taughtInput) state.currentUser.skillsTaught = taughtInput.value.trim();
  if (wantsInput) state.currentUser.skillsWants = wantsInput.value.trim();

  let tr = state.trainers.find(t => t.id === state.currentUser.id);
  if (tr) {
    tr.fullName = name;
    tr.avatarUrl = state.currentUser.avatarUrl;
    tr.bio = bio;
    if (expInput) tr.primaryExpertise = expInput.value.trim();
    if (taughtInput) tr.skillsTaught = taughtInput.value.trim();
    if (wantsInput) tr.skillsWants = wantsInput.value.trim();
  }

  closeModal();
  renderNavigation();
  triggerRealtimeNotification("Profile Updated", "Your profile photo, bio, and competencies were updated.", "success");
  showView(state.currentUser.activeRole.toLowerCase());
  saveStateToStorage();
}

function handleLogout() {
  state.currentUser = null;
  localStorage.removeItem(STORAGE_KEY);
  showToast("Logged out successfully.", "normal");
  showView("landing");
}

function openExplainableSkillDetailModal(skillName) {
  const analysis = calculateSkillGapEngine();
  const item = analysis.items.find(i => i.skill === skillName);
  if (!item) return;

  openModal(`
    <div style="border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <span class="gap-severity-badge ${item.severity === 'Critical' ? 'high' : 'medium'}">${item.priority} PRIORITY</span>
      <h3 style="font-size:1.35rem; margin-top:0.35rem;">${item.skill} — Explainable AI Analysis</h3>
    </div>

    <div style="background:var(--slate-50); border:1px solid var(--border-soft); border-radius:var(--radius-md); padding:1.25rem; margin-bottom:1.25rem;">
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem; font-size:0.9rem;">
        <div>Current Proficiency: <strong>Level ${item.current}/5</strong></div>
        <div>Required Benchmark: <strong style="color:var(--primary);">Level ${item.required}/5</strong></div>
        <div>Importance Weight: <strong>${item.importance}</strong></div>
        <div>Calculated Gap: <strong style="color:var(--rose);">${item.gap} Levels</strong></div>
      </div>
      <p style="font-size:0.88rem; line-height:1.6; color:var(--slate-800);">${item.reason}</p>
    </div>

    <div style="background:var(--primary-light); border:1px solid var(--primary-border); border-radius:var(--radius-md); padding:1.25rem; margin-bottom:1.5rem;">
      <h4 style="font-size:0.95rem; color:var(--primary); margin-bottom:0.4rem;">Recommended Learning Action</h4>
      <p style="font-size:0.86rem; color:var(--slate-800);">${item.recommendedAction}</p>
    </div>

    <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
      <button class="btn-secondary" onclick="closeModal()">Close</button>
      <button class="btn-primary" onclick="closeModal(); setTraineeTab('trainers');">Find Mentor for ${item.skill} ➔</button>
    </div>
  `);
}

function openTrainerProfileModal(trainerId) {
  const tr = state.trainers.find(t => t.id === trainerId);
  if (!tr) return;

  openModal(`
    <div style="display:flex; align-items:center; gap:1.25rem; border-bottom:1px solid var(--border-soft); padding-bottom:1rem; margin-bottom:1.5rem;">
      <img src="${tr.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'}" style="width:64px; height:64px; border-radius:50%; object-fit:cover;">
      <div>
        <h3 style="font-size:1.3rem;">${tr.fullName}</h3>
        <div style="font-size:0.85rem; color:var(--slate-600);">${tr.primaryExpertise || 'Mentor'}</div>
        <div style="font-size:0.8rem; font-weight:700; color:var(--amber);">★ ${tr.rating || 5.0} Rating • ${tr.experienceYears || 1}+ Years Experience</div>
      </div>
    </div>

    <p style="font-size:0.9rem; line-height:1.6; margin-bottom:1.25rem;">${tr.bio || 'Mentor profile.'}</p>

    <div style="background:var(--slate-50); padding:1rem; border-radius:var(--radius-md); font-size:0.85rem; margin-bottom:1.5rem;">
      <div style="margin-bottom:0.4rem;"><strong>Expertise & Taught Skills:</strong> ${tr.skillsTaught || 'General'}</div>
      <div style="margin-bottom:0.4rem;"><strong>Reciprocal Skill Interest:</strong> ${tr.skillsWants || 'General'}</div>
      <div><strong>Availability:</strong> ${tr.availabilityStatus || 'Available'}</div>
    </div>

    <div style="display:flex; justify-content:flex-end; gap:0.75rem;">
      <button class="btn-secondary" onclick="closeModal()">Close</button>
      <button class="btn-primary" onclick="closeModal(); openSendExchangeCustomModal(${tr.id}, '${tr.fullName}', '${tr.skillsTaught || ''}');">
        Send Mentorship Request ➔
      </button>
    </div>
  `);
}

// ─── COMMAND PALETTE & NOTIFICATIONS ─────────────────────────────────────────
function toggleCmdPalette() {
  const overlay = document.getElementById("cmd-palette-overlay");
  if (!overlay) return;
  const isHidden = overlay.style.display === "none" || !overlay.style.display;
  overlay.style.display = isHidden ? "flex" : "none";
  if (isHidden) {
    const input = document.getElementById("cmd-input");
    if (input) { input.value = ""; input.focus(); filterCmdResults(); }
  }
}

function handleCmdOverlayClick(e) {
  if (e.target.id === "cmd-palette-overlay") toggleCmdPalette();
}

function filterCmdResults() {
  const input = document.getElementById("cmd-input");
  const container = document.getElementById("cmd-results");
  if (!container || !input) return;

  const q = input.value.toLowerCase().trim();
  const actions = [
    { title: "Analyze Competency Gaps", category: "Skill Engine", action: () => { toggleCmdPalette(); showView('trainee'); setTraineeTab('skill-gap'); } },
    { title: "Browse Knowledge Hub Resources", category: "Learning", action: () => { toggleCmdPalette(); showView('trainee'); setTraineeTab('knowledge-hub'); } },
    { title: "Switch to Trainer Dashboard", category: "Roles", action: () => { toggleCmdPalette(); switchActiveRole('TRAINER'); } },
    { title: "Switch to Admin Dashboard", category: "Roles", action: () => { toggleCmdPalette(); handleAdminRoleSwitch(); } },
    { title: "Edit My Profile & Skills", category: "Profile", action: () => { toggleCmdPalette(); openProfileModal(); } }
  ];

  const matches = actions.filter(a => a.title.toLowerCase().includes(q) || a.category.toLowerCase().includes(q));

  container.innerHTML = matches.map((m, idx) => `
    <div class="cmd-item ${idx === 0 ? 'selected' : ''}" onclick="state.cmdActions[${idx}]()">
      <span>${m.title}</span>
      <span style="font-size:0.75rem; color:var(--slate-400);">${m.category}</span>
    </div>
  `).join('');

  state.cmdActions = matches.map(m => m.action);
}

function handleCmdKeyDown(e) {
  if (e.key === "Escape") toggleCmdPalette();
  if (e.key === "Enter" && state.cmdActions && state.cmdActions.length > 0) {
    state.cmdActions[0]();
  }
}

function toggleNotifPopover() {
  const popover = document.getElementById("notif-center-popover");
  if (!popover) return;
  const isHidden = popover.style.display === "none" || !popover.style.display;
  
  if (isHidden) {
    popover.innerHTML = `
      <div style="padding:1rem 1.25rem; border-bottom:1px solid var(--border-soft); display:flex; justify-content:space-between; align-items:center; background:var(--slate-50);">
        <strong style="font-size:0.95rem;">🔔 Real-Time Notifications</strong>
        <button class="btn-secondary" style="font-size:0.74rem; padding:0.2rem 0.5rem;" onclick="markAllNotifsRead()">Mark all read</button>
      </div>
      <div style="max-height:280px; overflow-y:auto; padding:0.5rem 0;">
        ${state.notifications.length > 0 ? state.notifications.map(n => `
          <div style="padding:0.75rem 1.25rem; border-bottom:1px solid var(--border-soft); ${!n.read ? 'background:#F0FDF4;' : ''}">
            <div style="display:flex; justify-content:space-between; font-size:0.85rem; font-weight:700; margin-bottom:0.2rem;">
              <span>${n.title}</span>
              <span style="font-size:0.74rem; color:var(--slate-400); font-weight:normal;">${n.time}</span>
            </div>
            <p style="font-size:0.8rem; line-height:1.4; color:var(--slate-600);">${n.desc}</p>
          </div>
        `).join('') : `
          <div style="padding:1.5rem; text-align:center; color:var(--slate-500); font-size:0.85rem;">No new notifications.</div>
        `}
      </div>
    `;
    popover.style.display = "block";
  } else {
    popover.style.display = "none";
  }
}

function markAllNotifsRead() {
  state.notifications.forEach(n => n.read = true);
  renderNavigation();
  toggleNotifPopover();
  showToast("All notifications marked as read.", "normal");
  saveStateToStorage();
}

function showToast(msg, type) {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast-msg";
  toast.innerHTML = `<span>${type === 'success' ? '✓' : (type === 'alert' ? '🔑' : '✦')}</span> <span>${msg}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    if (toast.parentNode) toast.parentNode.removeChild(toast);
  }, 3500);
}

document.addEventListener("keydown", (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
    e.preventDefault();
    toggleCmdPalette();
  }
});

document.addEventListener("DOMContentLoaded", () => {
  showView("landing");
});
