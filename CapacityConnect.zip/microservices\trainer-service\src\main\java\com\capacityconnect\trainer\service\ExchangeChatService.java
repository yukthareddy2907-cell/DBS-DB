package com.capacityconnect.trainer.service;

import com.capacityconnect.trainer.dto.TrainerDtos.ExchangeRequestDto;
import com.capacityconnect.trainer.dto.TrainerDtos.SendChatMessageRequest;
import com.capacityconnect.trainer.model.ChatMessage;
import com.capacityconnect.trainer.model.SkillExchangeRequest;
import com.capacityconnect.trainer.repository.ChatMessageRepository;
import com.capacityconnect.trainer.repository.SkillExchangeRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] Relational Skill Exchange Lifecycle & Real-Time Chat System
 * =============================================================================
 */
@Service
public class ExchangeChatService {

    private final SkillExchangeRequestRepository exchangeRepository;
    private final ChatMessageRepository chatMessageRepository;

    @Autowired
    public ExchangeChatService(SkillExchangeRequestRepository exchangeRepository,
                               ChatMessageRepository chatMessageRepository) {
        this.exchangeRepository = exchangeRepository;
        this.chatMessageRepository = chatMessageRepository;
    }

    public List<SkillExchangeRequest> getAllRequests() {
        return exchangeRepository.findAll();
    }

    public List<SkillExchangeRequest> getRequestsForTrainer(Long trainerId) {
        return exchangeRepository.findByTrainerIdOrderByCreatedAtDesc(trainerId);
    }

    public List<SkillExchangeRequest> getRequestsForTrainee(Long traineeId) {
        return exchangeRepository.findByTraineeIdOrderByCreatedAtDesc(traineeId);
    }

    @Transactional
    public SkillExchangeRequest createRequest(ExchangeRequestDto dto) {
        SkillExchangeRequest request = SkillExchangeRequest.builder()
                .traineeId(dto.getTraineeId())
                .traineeName(dto.getTraineeName())
                .trainerId(dto.getTrainerId())
                .trainerName(dto.getTrainerName())
                .skillRequested(dto.getSkillRequested())
                .skillOffered(dto.getSkillOffered() != null ? dto.getSkillOffered() : "Reciprocal Mentorship")
                .status(SkillExchangeRequest.ExchangeStatus.PENDING)
                .build();

        return exchangeRepository.save(request);
    }

    @Transactional
    public SkillExchangeRequest acceptRequest(Long exchangeId) {
        SkillExchangeRequest request = exchangeRepository.findById(exchangeId)
                .orElseThrow(() -> new IllegalArgumentException("Exchange request " + exchangeId + " not found."));

        request.setStatus(SkillExchangeRequest.ExchangeStatus.ACCEPTED);
        SkillExchangeRequest saved = exchangeRepository.save(request);

        // Send welcome opening message
        ChatMessage welcomeMsg = ChatMessage.builder()
                .exchange(saved)
                .senderId(saved.getTrainerId())
                .senderName(saved.getTrainerName())
                .receiverId(saved.getTraineeId())
                .messageText("Hello " + saved.getTraineeName() + "! I have accepted your mentorship request for " 
                        + saved.getSkillRequested() + ". Let's collaborate to accelerate your competency growth.")
                .build();
        chatMessageRepository.save(welcomeMsg);

        return saved;
    }

    @Transactional
    public SkillExchangeRequest declineRequest(Long exchangeId, String reason) {
        SkillExchangeRequest request = exchangeRepository.findById(exchangeId)
                .orElseThrow(() -> new IllegalArgumentException("Exchange request " + exchangeId + " not found."));

        request.setStatus(SkillExchangeRequest.ExchangeStatus.DECLINED);
        request.setDeclineReason(reason != null && !reason.isBlank() ? reason : "Schedule full at this time.");
        return exchangeRepository.save(request);
    }

    public List<ChatMessage> getMessagesForExchange(Long exchangeId) {
        return chatMessageRepository.findByExchangeIdOrderBySentAtAsc(exchangeId);
    }

    @Transactional
    public ChatMessage sendMessage(SendChatMessageRequest request) {
        SkillExchangeRequest exchange = exchangeRepository.findById(request.getExchangeId())
                .orElseThrow(() -> new IllegalArgumentException("Exchange with ID " + request.getExchangeId() + " not found."));

        if (exchange.getStatus() != SkillExchangeRequest.ExchangeStatus.ACCEPTED) {
            throw new IllegalStateException("Chat is unlocked only after the trainer has accepted the exchange request.");
        }

        ChatMessage message = ChatMessage.builder()
                .exchange(exchange)
                .senderId(request.getSenderId())
                .senderName(request.getSenderName())
                .receiverId(request.getReceiverId())
                .messageText(request.getMessageText())
                .build();

        return chatMessageRepository.save(message);
    }
}
