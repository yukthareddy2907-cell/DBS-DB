package com.capacityconnect.skill.model;

import jakarta.persistence.*;
import lombok.*;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Role Competencies (Required Level 1-5 + Weight)
 * =============================================================================
 */
@Entity
@Table(name = "role_competencies", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"role_id", "competency_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleCompetency {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private RoleFramework role;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "competency_id", nullable = false)
    private Competency competency;

    @Column(name = "required_proficiency", nullable = false)
    private int requiredProficiency; // 1 = Beginner, 2 = Basic, 3 = Intermediate, 4 = Advanced, 5 = Expert

    @Enumerated(EnumType.STRING)
    @Column(name = "importance_weight", nullable = false)
    @Builder.Default
    private ImportanceWeight importanceWeight = ImportanceWeight.HIGH;

    @Column(name = "weight_multiplier", nullable = false)
    @Builder.Default
    private double weightMultiplier = 1.0;

    public enum ImportanceWeight {
        HIGH, MEDIUM, LOW
    }
}
