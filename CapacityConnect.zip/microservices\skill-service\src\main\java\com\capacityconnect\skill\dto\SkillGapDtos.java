package com.capacityconnect.skill.dto;

import lombok.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] Structured REST API Data Transfer Objects for AI Skill-Gap Analysis
 * =============================================================================
 */
public class SkillGapDtos {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SkillGapItem {
        private String skillName;
        private String category;
        private int currentProficiency; // 1-5 scale
        private int requiredProficiency; // 1-5 scale
        private int gap; // required - current
        private String severity; // "Meets Requirement", "Low", "Moderate", "Critical"
        private String priority; // "HIGH", "MEDIUM", "LOW"
        private double roleWeight;
        private String evidence;
        private String reason;
        private String recommendedAction;
        private String estimatedImprovement;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LearningPathStage {
        private int stage;
        private String skill;
        private String stageTitle;
        private String description;
        private String practicalActivity;
        private int estimatedHours;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SkillGapAnalysisResponse {
        private Long userId;
        private String targetRole;
        private int overallReadiness; // Weighted percentage (e.g. 68%)
        private int totalGapsCount;
        private String explainableAiSummary;
        private List<SkillGapItem> priorityGaps;
        private List<SkillGapItem> allCompetencies;
        private List<LearningPathStage> personalizedLearningPath;
        private List<Map<String, Object>> recommendedTrainers; // Sourced via REST from Trainer Service [CO5]
        private List<CompetencyHistoryDto> recentProgressHistory;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateCompetencyRequest {
        private Long userId;
        private String skillName;
        private int newProficiency;
        private String triggerEvent;
        private Double assessmentScore;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CompetencyHistoryDto {
        private String skillName;
        private int previousLevel;
        private int newLevel;
        private String triggerEvent;
        private Double assessmentScore;
        private LocalDateTime recordedAt;
    }
}
