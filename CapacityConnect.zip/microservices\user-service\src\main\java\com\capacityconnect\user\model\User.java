package com.capacityconnect.user.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Normalized User Entity with Indexing & Timestamps
 * [CO4] Domain Entity for Independent User Microservice
 * =============================================================================
 */
@Entity
@Table(name = "users", indexes = {
    @Index(name = "idx_user_email", columnList = "email"),
    @Index(name = "idx_user_roles", columnList = "is_trainee, is_trainer, is_admin")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "avatar_url", length = 500)
    private String avatarUrl;

    @Enumerated(EnumType.STRING)
    @Column(name = "primary_role", nullable = false)
    @Builder.Default
    private Role primaryRole = Role.TRAINEE;

    @Column(name = "is_trainee", nullable = false)
    @Builder.Default
    private boolean isTrainee = true;

    @Column(name = "is_trainer", nullable = false)
    @Builder.Default
    private boolean isTrainer = false;

    @Column(name = "is_admin", nullable = false)
    @Builder.Default
    private boolean isAdmin = false;

    @Column(name = "is_approved", nullable = false)
    @Builder.Default
    private boolean isApproved = true;

    @Column(name = "account_status", nullable = false)
    @Builder.Default
    private String accountStatus = "ACTIVE";

    @Column(name = "target_role", length = 150)
    @Builder.Default
    private String targetRole = "Data Analyst";

    @Column(name = "department", length = 100)
    @Builder.Default
    private String department = "Data & Analytics";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.avatarUrl == null || this.avatarUrl.isBlank()) {
            this.avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150";
        }
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum Role {
        TRAINEE, TRAINER, ADMIN
    }
}
