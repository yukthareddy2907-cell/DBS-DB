-- ============================================================================
-- CAPACITY CONNECT — AI-Powered Organizational Capacity Building Platform
-- Complete MySQL 8.0+ Workbench Schema & Multi-Database Microservices Setup
-- Clean Database Schema (Ready for Real User Accounts & Custom Creation)
-- ============================================================================
-- Course Outcomes Mapped:
-- [CO1] Normalised relational schemas, complex joins, transactions, indexes
-- [CO2] Polyglot data integration patterns & structured document schemas
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. USER SERVICE DATABASE (Port 8081)
-- ----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS capacity_user_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE capacity_user_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS user_profiles;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- Users Table [CO1]
CREATE TABLE users (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  full_name      VARCHAR(150) NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  avatar_url     LONGTEXT NULL,
  primary_role   ENUM('TRAINEE','TRAINER','ADMIN') NOT NULL DEFAULT 'TRAINEE',
  is_trainee     BOOLEAN NOT NULL DEFAULT TRUE,
  is_trainer     BOOLEAN NOT NULL DEFAULT FALSE,
  is_admin       BOOLEAN NOT NULL DEFAULT FALSE,
  is_approved    BOOLEAN NOT NULL DEFAULT TRUE,
  account_status ENUM('ACTIVE','PENDING','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
  target_role    VARCHAR(150) DEFAULT 'Data Analyst',
  department     VARCHAR(100) DEFAULT 'General',
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_roles (is_trainee, is_trainer, is_admin)
) ENGINE=InnoDB;

-- User Profiles Table [CO1]
CREATE TABLE user_profiles (
  user_id                BIGINT PRIMARY KEY,
  bio                    TEXT NULL,
  expertise              VARCHAR(500) NULL,
  qualifications         VARCHAR(500) NULL,
  experience_years       INT DEFAULT 1,
  department             VARCHAR(100) DEFAULT 'General',
  career_readiness_score INT DEFAULT 20,
  learning_streak_days   INT DEFAULT 1,
  learning_progress_rate INT DEFAULT 0,
  xp_points              INT DEFAULT 100,
  current_level          INT DEFAULT 1,
  created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- ----------------------------------------------------------------------------
-- 2. SKILL SERVICE DATABASE (Port 8082)
-- ----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS capacity_skill_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE capacity_skill_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS competency_history;
DROP TABLE IF EXISTS user_competencies;
DROP TABLE IF EXISTS role_competencies;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS competencies;
SET FOREIGN_KEY_CHECKS = 1;

-- Competencies Benchmark Table (1-5 Proficiency Scale) [CO1]
CREATE TABLE competencies (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(100) NOT NULL UNIQUE,
  category         VARCHAR(100) NOT NULL,
  description      TEXT NOT NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Target Roles Table [CO1]
CREATE TABLE roles (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  role_name        VARCHAR(150) NOT NULL UNIQUE,
  department       VARCHAR(100) NOT NULL,
  description      TEXT NOT NULL,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Role Competency Requirements & Importance Weights [CO1]
CREATE TABLE role_competencies (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  role_id             BIGINT NOT NULL,
  competency_id       BIGINT NOT NULL,
  required_proficiency INT NOT NULL CHECK (required_proficiency BETWEEN 1 AND 5),
  importance_weight   ENUM('HIGH','MEDIUM','LOW') NOT NULL DEFAULT 'HIGH',
  weight_multiplier   DECIMAL(3,2) NOT NULL DEFAULT 1.00,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE CASCADE,
  UNIQUE KEY uk_role_competency (role_id, competency_id)
) ENGINE=InnoDB;

-- User Competencies (Populated dynamically as users add skills or take exams) [CO1]
CREATE TABLE user_competencies (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id             BIGINT NOT NULL,
  competency_id       BIGINT NOT NULL,
  current_proficiency INT NOT NULL CHECK (current_proficiency BETWEEN 1 AND 5),
  evidence            VARCHAR(255) DEFAULT 'Self-Reported in Profile',
  confidence_score    DECIMAL(3,2) DEFAULT 0.85,
  last_assessed_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE CASCADE,
  UNIQUE KEY uk_user_competency (user_id, competency_id)
) ENGINE=InnoDB;

-- Competency History for Closed Feedback Loop & Progress Tracking [CO1]
CREATE TABLE competency_history (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id             BIGINT NOT NULL,
  competency_id       BIGINT NOT NULL,
  previous_level      INT NOT NULL,
  new_level           INT NOT NULL,
  trigger_event       VARCHAR(150) NOT NULL,
  assessment_score    DECIMAL(5,2) NULL,
  recorded_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Benchmark Competency Frameworks [CO1]
INSERT INTO competencies (id, name, category, description) VALUES
(1, 'SQL', 'Database & Querying', 'Relational database design, multi-table joins, aggregations, window functions, and indexing.'),
(2, 'Python', 'Programming & Scripting', 'Core Python programming, data manipulation with Pandas, NumPy, and automation scripts.'),
(3, 'Statistics', 'Mathematics & Analytics', 'Descriptive & inferential statistics, probability distributions, hypothesis testing, and regression.'),
(4, 'Excel', 'Data Modeling & Spreadsheets', 'Advanced formulas (XLOOKUP, INDEX/MATCH), Pivot Tables, Power Query, and financial modeling.'),
(5, 'Power BI', 'Business Intelligence & BI', 'Data modeling in Power BI, DAX measures, relational star schemas, and interactive dashboarding.'),
(6, 'Data Visualization', 'Storytelling & Design', 'Visual hierarchy, chart selection principles, dashboard UX, and executive reporting.'),
(7, 'Machine Learning', 'AI & Modeling', 'Supervised and unsupervised learning, scikit-learn, model validation, and feature engineering.'),
(8, 'Java Spring Boot', 'Backend Engineering', 'REST APIs, dependency injection, JPA/Hibernate, security, and enterprise architecture.');

-- Benchmark Roles [CO1]
INSERT INTO roles (id, role_name, department, description) VALUES
(1, 'Data Analyst', 'Business Intelligence', 'Analyzes organizational data, designs dashboards, crafts SQL queries, and provides data-driven business insights.'),
(2, 'Full-Stack Software Engineer', 'Engineering', 'Develops end-to-end web applications with modern frontends, robust backend microservices, and databases.'),
(3, 'AI/ML Engineer', 'Artificial Intelligence', 'Builds, trains, evaluates, and deploys predictive machine learning models and intelligent data pipelines.');

-- Benchmark Role Requirements for 'Data Analyst' [CO1]
INSERT INTO role_competencies (role_id, competency_id, required_proficiency, importance_weight, weight_multiplier) VALUES
(1, 1, 4, 'HIGH', 1.30),    -- SQL: Required 4 (Advanced)
(1, 2, 3, 'MEDIUM', 1.00),  -- Python: Required 3 (Intermediate)
(1, 3, 4, 'HIGH', 1.25),    -- Statistics: Required 4 (Advanced)
(1, 4, 4, 'HIGH', 1.10),    -- Excel: Required 4 (Advanced)
(1, 5, 3, 'HIGH', 1.20),    -- Power BI: Required 3 (Intermediate)
(1, 6, 3, 'MEDIUM', 1.00);  -- Data Visualization: Required 3 (Intermediate)


-- ----------------------------------------------------------------------------
-- 3. TRAINER & LEARNING SERVICE DATABASE (Port 8083)
-- ----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS capacity_trainer_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE capacity_trainer_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS calendar_notes;
DROP TABLE IF EXISTS training_sessions;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS skill_exchange_requests;
DROP TABLE IF EXISTS assessment_submissions;
DROP TABLE IF EXISTS assessment_questions;
DROP TABLE IF EXISTS assessments;
DROP TABLE IF EXISTS knowledge_resources;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS trainer_profiles;
SET FOREIGN_KEY_CHECKS = 1;

-- Trainer Profiles Table [CO1]
CREATE TABLE trainer_profiles (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id             BIGINT NOT NULL UNIQUE,
  full_name           VARCHAR(150) NOT NULL,
  email               VARCHAR(150) NOT NULL,
  avatar_url          LONGTEXT NULL,
  primary_expertise   VARCHAR(200) NOT NULL,
  skills_taught       VARCHAR(500) NOT NULL,
  skills_wants        VARCHAR(500) NULL,
  experience_years    INT DEFAULT 3,
  rating              DECIMAL(3,2) DEFAULT 5.00,
  availability_status VARCHAR(100) DEFAULT 'Available',
  bio                 TEXT NOT NULL,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Courses Table (Trainer Created / Uploaded) [CO1]
CREATE TABLE courses (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainer_id          BIGINT NOT NULL,
  trainer_name        VARCHAR(150) NOT NULL,
  title               VARCHAR(200) NOT NULL,
  skill_name          VARCHAR(100) NOT NULL,
  category            VARCHAR(100) NOT NULL,
  difficulty          ENUM('BEGINNER','INTERMEDIATE','ADVANCED') DEFAULT 'INTERMEDIATE',
  description         TEXT NOT NULL,
  estimated_hours     INT DEFAULT 8,
  total_lessons       INT DEFAULT 4,
  is_published        BOOLEAN DEFAULT TRUE,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Knowledge Hub Resources [CO1]
CREATE TABLE knowledge_resources (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  uploaded_by_id      BIGINT NOT NULL,
  uploaded_by_name    VARCHAR(150) NOT NULL,
  title               VARCHAR(200) NOT NULL,
  skill_name          VARCHAR(100) NOT NULL,
  category            VARCHAR(100) NOT NULL,
  resource_type       ENUM('DOCUMENT','CHEATSHEET','PROJECT_CODE','GUIDE','HANDBOOK') DEFAULT 'HANDBOOK',
  file_content        LONGTEXT NOT NULL,
  file_size_kb        INT DEFAULT 15,
  download_count      INT DEFAULT 0,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Assessments Table (MCQs with Server Answer Keys) [CO1]
CREATE TABLE assessments (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainer_id          BIGINT NOT NULL,
  title               VARCHAR(200) NOT NULL,
  skill_name          VARCHAR(100) NOT NULL,
  target_role         VARCHAR(150) NOT NULL DEFAULT 'Data Analyst',
  duration_minutes    INT DEFAULT 20,
  passing_score       INT DEFAULT 75,
  target_proficiency  INT DEFAULT 3,
  category            VARCHAR(100) DEFAULT 'Technical Assessment',
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Assessment Questions Table [CO1]
CREATE TABLE assessment_questions (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  assessment_id       BIGINT NOT NULL,
  question_text       TEXT NOT NULL,
  option_a            VARCHAR(300) NOT NULL,
  option_b            VARCHAR(300) NOT NULL,
  option_c            VARCHAR(300) NOT NULL,
  option_d            VARCHAR(300) NOT NULL,
  correct_option      CHAR(1) NOT NULL CHECK (correct_option IN ('A','B','C','D')),
  explanation         TEXT NOT NULL,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Assessment Submissions & AI Evaluation Results [CO1]
CREATE TABLE assessment_submissions (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  assessment_id       BIGINT NOT NULL,
  user_id             BIGINT NOT NULL,
  user_name           VARCHAR(150) NOT NULL,
  score_percentage    DECIMAL(5,2) NOT NULL,
  passed              BOOLEAN NOT NULL,
  total_questions     INT NOT NULL,
  correct_count       INT NOT NULL,
  detailed_breakdown  JSON NOT NULL,
  ai_evaluation_notes TEXT NOT NULL,
  submitted_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Skill Exchange Requests [CO1]
CREATE TABLE skill_exchange_requests (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainee_id          BIGINT NOT NULL,
  trainee_name        VARCHAR(150) NOT NULL,
  trainer_id          BIGINT NOT NULL,
  trainer_name        VARCHAR(150) NOT NULL,
  skill_requested     VARCHAR(100) NOT NULL,
  skill_offered       VARCHAR(100) NOT NULL,
  status              ENUM('PENDING','ACCEPTED','DECLINED') NOT NULL DEFAULT 'PENDING',
  decline_reason      VARCHAR(255) NULL,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Real-Time Chat Messages (Active Only When Exchange Accepted) [CO1]
CREATE TABLE chat_messages (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  exchange_id         BIGINT NOT NULL,
  sender_id           BIGINT NOT NULL,
  sender_name         VARCHAR(150) NOT NULL,
  receiver_id         BIGINT NOT NULL,
  message_text        TEXT NOT NULL,
  sent_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_read             BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (exchange_id) REFERENCES skill_exchange_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Training Sessions [CO1]
CREATE TABLE training_sessions (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainer_id          BIGINT NOT NULL,
  trainee_id          BIGINT NOT NULL,
  trainee_name        VARCHAR(150) NOT NULL,
  topic               VARCHAR(200) NOT NULL,
  session_time        VARCHAR(100) NOT NULL,
  status              ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
  meeting_link        VARCHAR(255) DEFAULT 'https://meet.google.com/cap-conn-learn',
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Calendar Notes Box [CO1]
CREATE TABLE calendar_notes (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id             BIGINT NOT NULL,
  note_content        TEXT NOT NULL,
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================================
-- End of Clean MySQL Workbench Multi-Database Setup Script
-- ============================================================================
