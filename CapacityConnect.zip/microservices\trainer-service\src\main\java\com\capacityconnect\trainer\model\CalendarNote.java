package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Aesthetic Notes Box Entity (Side of Calendar)
 * =============================================================================
 */
@Entity
@Table(name = "calendar_notes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalendarNote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;

    @Column(name = "note_content", columnDefinition = "TEXT", nullable = false)
    private String noteContent;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
