package com.capacityconnect.trainer.service;

import com.capacityconnect.trainer.dto.TrainerDtos.CreateKnowledgeResourceRequest;
import com.capacityconnect.trainer.model.KnowledgeResource;
import com.capacityconnect.trainer.repository.KnowledgeResourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] Relational Knowledge Hub Service with Real File Content Management
 * =============================================================================
 */
@Service
public class KnowledgeHubService {

    private final KnowledgeResourceRepository knowledgeResourceRepository;

    @Autowired
    public KnowledgeHubService(KnowledgeResourceRepository knowledgeResourceRepository) {
        this.knowledgeResourceRepository = knowledgeResourceRepository;
    }

    public List<KnowledgeResource> getAllResources() {
        return knowledgeResourceRepository.findAll();
    }

    public Optional<KnowledgeResource> getResourceById(Long id) {
        return knowledgeResourceRepository.findById(id);
    }

    public List<KnowledgeResource> getResourcesBySkill(String skillName) {
        return knowledgeResourceRepository.findBySkillName(skillName);
    }

    @Transactional
    public KnowledgeResource uploadResource(CreateKnowledgeResourceRequest request) {
        KnowledgeResource.ResourceType type = KnowledgeResource.ResourceType.DOCUMENT;
        if (request.getResourceType() != null) {
            try {
                type = KnowledgeResource.ResourceType.valueOf(request.getResourceType().toUpperCase());
            } catch (Exception ignored) {}
        }

        KnowledgeResource resource = KnowledgeResource.builder()
                .uploadedById(request.getUploadedById() != null ? request.getUploadedById() : 2L)
                .uploadedByName(request.getUploadedByName() != null ? request.getUploadedByName() : "Dr. Aris Vance")
                .title(request.getTitle())
                .skillName(request.getSkillName())
                .category(request.getCategory() != null ? request.getCategory() : "Technical Documentation")
                .resourceType(type)
                .fileName(request.getFileName() != null ? request.getFileName() : "resource_guide.md")
                .fileContent(request.getFileContent() != null ? request.getFileContent() : "# Resource Guide\n\nContent uploaded by trainer.")
                .fileSizeKb(request.getFileSizeKb() > 0 ? request.getFileSizeKb() : 120)
                .downloadCount(0)
                .build();

        return knowledgeResourceRepository.save(resource);
    }

    @Transactional
    public KnowledgeResource updateResource(Long id, CreateKnowledgeResourceRequest request) {
        KnowledgeResource resource = knowledgeResourceRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Resource with ID " + id + " not found."));

        if (request.getTitle() != null) resource.setTitle(request.getTitle());
        if (request.getSkillName() != null) resource.setSkillName(request.getSkillName());
        if (request.getCategory() != null) resource.setCategory(request.getCategory());
        if (request.getFileContent() != null) resource.setFileContent(request.getFileContent());

        return knowledgeResourceRepository.save(resource);
    }

    @Transactional
    public void deleteResource(Long id) {
        if (!knowledgeResourceRepository.existsById(id)) {
            throw new IllegalArgumentException("Resource with ID " + id + " not found.");
        }
        knowledgeResourceRepository.deleteById(id);
    }

    @Transactional
    public KnowledgeResource recordDownload(Long id) {
        KnowledgeResource resource = knowledgeResourceRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Resource with ID " + id + " not found."));
        resource.setDownloadCount(resource.getDownloadCount() + 1);
        return knowledgeResourceRepository.save(resource);
    }
}
