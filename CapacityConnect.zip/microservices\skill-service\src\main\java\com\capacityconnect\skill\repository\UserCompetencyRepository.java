package com.capacityconnect.skill.repository;

import com.capacityconnect.skill.model.UserCompetency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Queries for User Competencies & Organizational Aggregations
 * =============================================================================
 */
@Repository
public interface UserCompetencyRepository extends JpaRepository<UserCompetency, Long> {

    List<UserCompetency> findByUserId(Long userId);

    Optional<UserCompetency> findByUserIdAndCompetencyId(Long userId, Long competencyId);

    @Query("SELECT uc.competency.name, COUNT(uc) FROM UserCompetency uc WHERE uc.currentProficiency < 4 GROUP BY uc.competency.name ORDER BY COUNT(uc) DESC")
    List<Object[]> findTopOrganizationalSkillGaps();
}
