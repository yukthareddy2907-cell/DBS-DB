-- ============================================================================
-- CAPACITY CONNECT — AI-Powered Organizational Capacity Building Platform
-- Comprehensive Seed / Sample Dataset for MySQL Workbench
-- ============================================================================

USE capacity_connect_db;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE feedback;
TRUNCATE TABLE ai_insights;
TRUNCATE TABLE notifications;
TRUNCATE TABLE knowledge_resources;
TRUNCATE TABLE certificates;
TRUNCATE TABLE assessment_submissions;
TRUNCATE TABLE assessment_questions;
TRUNCATE TABLE assessments;
TRUNCATE TABLE training_sessions;
TRUNCATE TABLE chat_messages;
TRUNCATE TABLE skill_exchange_requests;
TRUNCATE TABLE course_enrollments;
TRUNCATE TABLE course_competencies;
TRUNCATE TABLE courses;
TRUNCATE TABLE competency_records;
TRUNCATE TABLE competencies;
TRUNCATE TABLE user_skills;
TRUNCATE TABLE user_profiles;
TRUNCATE TABLE users;

SET FOREIGN_KEY_CHECKS = 1;

-- ─── 1. USERS ────────────────────────────────────────────────────────────────
-- Demo Accounts:
--   1. Admin:   admin@capacityconnect.org   (Admin + Trainer + Trainee privileges)
--   2. Trainer: aris.vance@techcorp.io      (Trainer + Trainee)
--   3. Trainer: elena.rostova@designhub.com (Trainer)
--   4. Trainee: marcus.chen@student.edu     (Trainee + Trainer: Multi-role demo!)
--   5. Trainee: sophia.patel@global.org     (Trainee)
INSERT INTO users (id, full_name, email, password_hash, avatar_url, primary_role, is_trainee, is_trainer, is_admin, is_approved, account_status, target_role, department)
VALUES 
(1, 'Admin Gayatri Rao', 'admin@capacityconnect.org', '$2a$10$e8w3p7b1r0...adminhash', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', 'ADMIN', TRUE, TRUE, TRUE, TRUE, 'ACTIVE', 'Chief Capacity Officer', 'Executive Leadership'),
(2, 'Dr. Aris Vance', 'aris.vance@techcorp.io', '$2a$10$e8w3p7b1r0...trainerhash', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', 'TRAINER', TRUE, TRUE, FALSE, TRUE, 'ACTIVE', 'Principal Backend Architect', 'Core Engineering'),
(3, 'Elena Rostova', 'elena.rostova@designhub.com', '$2a$10$e8w3p7b1r0...trainerhash2', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', 'TRAINER', FALSE, TRUE, FALSE, TRUE, 'ACTIVE', 'AI Research Director', 'Applied AI Lab'),
(4, 'Marcus Chen', 'marcus.chen@student.edu', '$2a$10$e8w3p7b1r0...traineehash', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', 'TRAINEE', TRUE, TRUE, FALSE, TRUE, 'ACTIVE', 'Senior Enterprise Java Engineer', 'Software Development'),
(5, 'Sophia Patel', 'sophia.patel@global.org', '$2a$10$e8w3p7b1r0...traineehash2', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150', 'TRAINEE', TRUE, FALSE, FALSE, TRUE, 'ACTIVE', 'Data Analytics Specialist', 'Data & Business Intelligence');

-- ─── 2. USER PROFILES ────────────────────────────────────────────────────────
INSERT INTO user_profiles (user_id, bio, expertise, qualifications, experience_years, department, performance_rating, career_readiness_score, overall_competency, learning_streak_days, xp_points, current_level, total_completed_courses, training_completion_rate)
VALUES
(1, 'Chief Capacity Officer & Platform Enterprise Architect. Specializing in cloud modernization, talent pipelines, and organizational AI competency.', 'Enterprise Architecture, Cloud Governance, Strategy, Leadership', 'Ph.D. in Computer Science, TOGAF Certified Master Architect', 14, 'Executive Leadership', 4.95, 98, 95, 45, 8400, 12, 18, 96),
(2, 'Senior Java & Distributed Systems Specialist. Passionate about enterprise Spring Boot microservices, high-throughput caching, and Latin dance.', 'Enterprise Java, Spring Boot, Microservices, Kafka, MySQL Tuning', 'M.S. Software Systems, Oracle Certified Java Master', 10, 'Core Engineering', 4.90, 92, 89, 28, 4200, 8, 12, 92),
(3, 'Lead AI Research Scientist & Neural Network Instructor. Specializing in RAG pipelines, fine-tuning, transformer attention layers, and vector search.', 'Deep Learning, PyTorch, LLM Optimization, Vector Embeddings, AWS AI', 'Ph.D. in Machine Learning, MIT PostDoc Fellow', 8, 'Applied AI Lab', 4.88, 90, 87, 19, 3900, 7, 10, 89),
(4, 'Full-Stack Developer trainee & Certified Latin Salsa Dance Instructor. Actively upskilling in Enterprise Spring Boot and Microservices.', 'Full-Stack Web, Modern CSS, Latin / Salsa Dance, Choreography', 'B.Tech in Computer Science, Certified Dance Instructor', 3, 'Software Development', 4.75, 78, 72, 12, 1850, 4, 5, 75),
(5, 'Junior Data Analyst & Business Intelligence Trainee focusing on statistical analysis, data cleaning pipelines, and predictive dashboards.', 'Data Visualization, SQL Analytics, Python Pandas, PowerBI', 'B.S. in Statistics & Applied Mathematics', 2, 'Data Analytics', 4.60, 65, 61, 7, 1200, 3, 3, 60);

-- ─── 3. USER SKILLS ──────────────────────────────────────────────────────────
INSERT INTO user_skills (user_id, skill_name, proficiency_level, current_score, target_score, category, is_teaching, is_learning)
VALUES
(2, 'Java Spring Boot', 'EXPERT', 96, 96, 'Programming', TRUE, FALSE),
(2, 'Microservices Architecture', 'EXPERT', 94, 94, 'Engineering', TRUE, FALSE),
(2, 'Salsa Dancing', 'BEGINNER', 40, 80, 'Arts & Wellness', FALSE, TRUE),
(3, 'Machine Learning & LLMs', 'EXPERT', 95, 95, 'AI & Data', TRUE, FALSE),
(3, 'Cloud Deployment (AWS)', 'ADVANCED', 88, 88, 'DevOps', TRUE, FALSE),
(4, 'Salsa Dance & Choreography', 'EXPERT', 98, 98, 'Arts & Wellness', TRUE, FALSE),
(4, 'Java Spring Boot', 'INTERMEDIATE', 62, 85, 'Programming', FALSE, TRUE),
(4, 'Distributed Systems & JPA', 'INTERMEDIATE', 54, 80, 'Programming', FALSE, TRUE),
(4, 'LLM Prompt Engineering', 'BEGINNER', 45, 75, 'AI & Data', FALSE, TRUE),
(4, 'Cloud Infrastructure & Docker', 'ADVANCED', 90, 85, 'DevOps', FALSE, FALSE),
(5, 'Data Analytics & Pandas', 'BEGINNER', 52, 80, 'Data Science', FALSE, TRUE),
(5, 'SQL Query Optimization', 'BEGINNER', 48, 75, 'Data Science', FALSE, TRUE);

-- ─── 4. COMPETENCIES ────────────────────────────────────────────────────────
INSERT INTO competencies (id, name, category, required_level, required_score, description, mapped_role, org_current_avg, org_gap_severity)
VALUES
(1, 'Distributed Systems & JPA Persistence', 'Engineering', 'LEVEL_3_ADVANCED', 80, 'Ability to architect resilient Spring Boot microservices, manage transactional consistency, and optimize MySQL JPA persistence.', 'Senior Enterprise Java Engineer', 54, 'HIGH'),
(2, 'LLM RAG & Vector Embeddings', 'AI & Data', 'LEVEL_3_ADVANCED', 80, 'Designing retrieval-augmented generation architectures, vector databases, and transformer inference endpoints.', 'AI Application Engineer', 48, 'HIGH'),
(3, 'Cloud Architecture & Kubernetes', 'DevOps', 'LEVEL_2_INTERMEDIATE', 75, 'Containerizing multi-service workloads with Docker, Pod networking, and Kubernetes deployment descriptors.', 'DevOps & Platform Specialist', 78, 'LOW'),
(4, 'Enterprise Data Analytics & SQL Optimization', 'Data Science', 'LEVEL_3_ADVANCED', 80, 'Deep query profiling, B+ tree index tuning, relational data modeling, and automated reporting pipelines.', 'Data Analytics Specialist', 58, 'MEDIUM'),
(5, 'Strategic Peer Knowledge Mentoring', 'Leadership', 'LEVEL_2_INTERMEDIATE', 70, 'Delivering reciprocal skill exchange, structured feedback, and active peer capability elevation.', 'Technical Lead / Mentor', 74, 'LOW');

-- ─── 5. COMPETENCY RECORDS ──────────────────────────────────────────────────
INSERT INTO competency_records (user_id, competency_id, current_level, target_level, priority, status, last_assessed)
VALUES
(4, 1, 54, 80, 'HIGH', 'IDENTIFIED', NOW() - INTERVAL 5 DAY),
(4, 2, 45, 80, 'HIGH', 'LEARNING', NOW() - INTERVAL 12 DAY),
(4, 3, 90, 75, 'LOW', 'TARGET_ACHIEVED', NOW() - INTERVAL 30 DAY),
(4, 4, 62, 80, 'MEDIUM', 'LEARNING', NOW() - INTERVAL 8 DAY),
(5, 4, 52, 80, 'HIGH', 'IDENTIFIED', NOW() - INTERVAL 3 DAY),
(5, 1, 38, 75, 'CRITICAL', 'IDENTIFIED', NOW() - INTERVAL 6 DAY);

-- ─── 6. COURSES ──────────────────────────────────────────────────────────────
INSERT INTO courses (id, title, category, description, trainer_id, duration_hours, total_lessons, difficulty, thumbnail_url, is_public, is_approved, approval_status, passing_score)
VALUES
(1, 'Enterprise Java & Spring Boot Masterclass', 'Programming', 'Comprehensive hands-on course building enterprise-grade REST APIs, MySQL JPA data persistence, transactions, and security.', 2, 16, 10, 'INTERMEDIATE', 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500', TRUE, TRUE, 'APPROVED', 70),
(2, 'Production Machine Learning & LLM Pipelines', 'AI/ML', 'Master fine-tuning, embeddings, vector search, RAG retrieval architectures, and deploying resilient AI inference services.', 3, 20, 12, 'ADVANCED', 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=500', TRUE, TRUE, 'APPROVED', 70),
(3, 'Cloud Infrastructure & Kubernetes Orchestration', 'DevOps', 'Learn container management, CI/CD pipelines, high-availability cloud architecture, and zero-trust security.', 1, 14, 8, 'INTERMEDIATE', 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=500', TRUE, TRUE, 'APPROVED', 75),
(4, 'Modern Data Architecture & SQL Optimization', 'Data Science', 'Deep dive into relational B+ Tree indexes, query execution plans, PostgreSQL/MySQL partitioning, and data pipelines.', 2, 12, 6, 'INTERMEDIATE', 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=500', TRUE, TRUE, 'APPROVED', 70);

-- ─── 7. COURSE COMPETENCY MAPPINGS ──────────────────────────────────────────
INSERT INTO course_competencies (course_id, competency_id)
VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4);

-- ─── 8. COURSE ENROLLMENTS ──────────────────────────────────────────────────
INSERT INTO course_enrollments (course_id, trainee_id, progress_percentage, completed_lessons, status, enrolled_at, completed_at)
VALUES
(1, 4, 75, 7, 'IN_PROGRESS', NOW() - INTERVAL 14 DAY, NULL),
(2, 4, 30, 3, 'IN_PROGRESS', NOW() - INTERVAL 10 DAY, NULL),
(3, 4, 100, 8, 'COMPLETED', NOW() - INTERVAL 40 DAY, NOW() - INTERVAL 30 DAY),
(4, 4, 0, 0, 'ENROLLED', NOW() - INTERVAL 2 DAY, NULL),
(1, 5, 20, 2, 'IN_PROGRESS', NOW() - INTERVAL 4 DAY, NULL),
(4, 5, 50, 3, 'IN_PROGRESS', NOW() - INTERVAL 7 DAY, NULL);

-- ─── 9. SKILL EXCHANGE REQUESTS ─────────────────────────────────────────────
INSERT INTO skill_exchange_requests (id, trainee_id, trainer_id, skill_wanted, skill_offered, message, status, feedback_notes, rating_given)
VALUES
(1, 4, 2, 'Java Spring Boot Microservices', 'Salsa Dance & Choreography', 'Hi Dr. Vance, I would love to learn advanced Java Spring Boot REST APIs and JPA from you! In exchange, I am a certified Latin Dance trainer and would love to teach you Salsa dancing.', 'ACCEPTED', 'Outstanding knowledge exchange! Marcus mastered Spring Data JPA and transactions while teaching Latin footwork with patience and precision.', 5.0),
(2, 5, 3, 'Deep Learning & Neural Networks', 'Public Speaking & Presentation', 'Hello Elena, looking forward to understanding Transformer attention layers in exchange for presentation and pitch deck coaching.', 'PENDING', NULL, NULL);

-- ─── 10. REAL-TIME CHAT MESSAGES ────────────────────────────────────────────
INSERT INTO chat_messages (id, exchange_request_id, sender_id, receiver_id, message_content, is_read, sent_at)
VALUES
(1, 1, 4, 2, 'Hello Dr. Vance! Excited for our skill exchange session this Thursday.', TRUE, NOW() - INTERVAL 2 HOUR),
(2, 1, 2, 4, 'Welcome Marcus! Have you reviewed the Spring Boot REST API starter repository and MySQL connection properties?', TRUE, NOW() - INTERVAL 1 HOUR),
(3, 1, 4, 2, 'Yes! I have tested the endpoints in Postman and set up the schema. Ready for our live session.', TRUE, NOW() - INTERVAL 20 MINUTE),
(4, 1, 2, 4, 'Fantastic. We will cover JPA entity relationships and transactional boundaries first.', FALSE, NOW() - INTERVAL 5 MINUTE);

-- ─── 11. ASSESSMENTS ────────────────────────────────────────────────────────
INSERT INTO assessments (id, title, category, course_id, trainer_id, competency_id, duration_minutes, total_marks, passing_marks, is_active)
VALUES
(1, 'Java Spring Boot & JPA Certification Assessment', 'Programming', 1, 2, 1, 20, 100, 70, TRUE),
(2, 'AI Neural Networks & Optimization Quiz', 'AI/ML', 2, 3, 2, 25, 100, 70, TRUE),
(3, 'Cloud Architecture & Docker Competency Exam', 'DevOps', 3, 1, 3, 15, 100, 75, TRUE),
(4, 'SQL Query Optimization & Indexing Assessment', 'Data Science', 4, 2, 4, 20, 100, 70, TRUE);

-- ─── 12. ASSESSMENT QUESTIONS (Answer keys secret on server!) ───────────────
INSERT INTO assessment_questions (assessment_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks, skill_tag, explanation)
VALUES
(1, 'Which annotation in Spring Boot is used to mark a class as a RESTful web service controller?', '@Controller', '@RestController', '@Service', '@Component', 'B', 25, 'Spring Boot Fundamentals', '@RestController combines @Controller and @ResponseBody, automatically serializing return values to JSON.'),
(1, 'In Spring Data JPA, which interface provides built-in CRUD operations, pagination, and sorting methods?', 'CrudRepository', 'JpaRepository', 'PagingAndSortingRepository', 'Repository', 'B', 25, 'JPA Persistence', 'JpaRepository extends PagingAndSortingRepository and CrudRepository with batch operations and JPA-specific methods.'),
(1, 'What is the default transactional propagation behavior in Spring (@Transactional)?', 'PROPAGATION_REQUIRES_NEW', 'PROPAGATION_REQUIRED', 'PROPAGATION_SUPPORTS', 'PROPAGATION_NEVER', 'B', 25, 'Transaction Management', 'PROPAGATION_REQUIRED joins an existing transaction if available, or creates a new one if none exists.'),
(1, 'In MySQL InnoDB engine, what data structure is primarily used for clustered primary key index lookups?', 'Hash Table', 'B+ Tree', 'LSM Tree', 'Red-Black Tree', 'B', 25, 'Database Indexing', 'InnoDB stores table data physically ordered by primary key in a clustered B+ Tree index structure.'),

(2, 'Which mechanism in Transformer architectures allows processing sequence tokens in parallel?', 'Recurrent hidden states', 'Multi-Head Self-Attention', 'Gradient Clipping', 'Max Pooling', 'B', 50, 'Neural Architecture', 'Self-attention calculates pairwise token relationships without recurrent sequential dependencies.'),
(2, 'What does RAG stand for in modern generative AI architectures?', 'Random Augmented Gradient', 'Retrieval-Augmented Generation', 'Resilient Array Graph', 'Recurrent Attention Gate', 'B', 50, 'RAG Pipelines', 'Retrieval-Augmented Generation enriches LLM prompts with semantic context retrieved from vector databases.'),

(3, 'Which Docker instruction sets the primary executable to run when the container starts?', 'RUN', 'ENTRYPOINT', 'EXPOSE', 'COPY', 'B', 50, 'Docker Containerization', 'ENTRYPOINT specifies the default command executed when the container starts.'),
(3, 'What Kubernetes resource manages replica sets and enables declarative rolling updates for Pods?', 'ConfigMap', 'Deployment', 'Service', 'Ingress', 'B', 50, 'Kubernetes Orchestration', 'A Deployment controller ensures the desired number of Pod replicas and handles zero-downtime rolling updates.');

-- ─── 13. ASSESSMENT SUBMISSIONS ─────────────────────────────────────────────
INSERT INTO assessment_submissions (id, assessment_id, trainee_id, score_obtained, total_marks, percentage, status, strong_areas, weak_areas, ai_evaluation_summary, ai_improvement_tips, submitted_at)
VALUES
(1, 3, 4, 90, 100, 90.00, 'PASSED', 'Docker container networking, Kubernetes Pod lifecycle, Replica management', 'Ingress routing annotations', 'Mastery Level: Exceptional understanding of Docker container networking, Pod lifecycle, and Kubernetes rolling updates.', 'Focus next on Helm chart packaging and dynamic ingress routing optimizations.', NOW() - INTERVAL 30 DAY);

-- ─── 14. CERTIFICATES REGISTRY ──────────────────────────────────────────────
INSERT INTO certificates (id, certificate_code, trainee_id, course_id, assessment_id, title, score, grade, issue_date, issuing_org, verification_url, is_valid)
VALUES
(1, 'CC-CERT-2026-0891', 4, 3, 3, 'Cloud Infrastructure & Kubernetes Certified Architect', 90, 'Distinction', '2026-08-15', 'CAPACITY CONNECT Enterprise Academy', 'https://capacityconnect.org/verify/CC-CERT-2026-0891', TRUE),
(2, 'CC-CERT-2026-0412', 4, 4, 4, 'Advanced Relational Database & SQL Engineering', 84, 'Merit', '2026-07-20', 'CAPACITY CONNECT Enterprise Academy', 'https://capacityconnect.org/verify/CC-CERT-2026-0412', TRUE);

-- ─── 15. TRAINING SESSIONS / CALENDAR ───────────────────────────────────────
INSERT INTO training_sessions (id, trainer_id, trainee_id, title, topic, session_date, start_time, end_time, session_type, status)
VALUES
(1, 2, 4, 'Spring Boot REST & JPA Deep Dive', 'Java Enterprise Architecture', '2026-09-02', '14:00:00', '15:30:00', 'ONE_ON_ONE', 'SCHEDULED'),
(2, 3, 4, 'LLM Prompt Engineering & Embeddings', 'Applied AI Systems', '2026-09-04', '16:00:00', '17:00:00', 'ONE_ON_ONE', 'SCHEDULED'),
(3, 1, NULL, 'Enterprise Cloud Security & Zero Trust Workshop', 'Cloud Security Architecture', '2026-09-08', '10:00:00', '12:00:00', 'WORKSHOP', 'SCHEDULED'),
(4, 2, 5, 'MySQL Index Optimization & Profiling', 'Database Engineering', '2026-09-10', '11:00:00', '12:00:00', 'ONE_ON_ONE', 'SCHEDULED');

-- ─── 16. KNOWLEDGE RESOURCES ────────────────────────────────────────────────
INSERT INTO knowledge_resources (id, title, category, file_name, file_url, file_type, file_size_mb, uploaded_by, is_approved, approval_status, download_count)
VALUES
(1, 'Spring Boot 3.x Production Blueprint & Checklist', 'PROGRAMMING', 'spring_boot_3_blueprint.pdf', 'https://resources.capacityconnect.org/spring_boot_3.pdf', 'PDF', 3.80, 2, TRUE, 'APPROVED', 128),
(2, 'Transformers, RAG & Vector Embeddings Architecture Guide', 'AI_ML', 'llm_rag_architecture_guide.pdf', 'https://resources.capacityconnect.org/llm_rag_guide.pdf', 'PDF', 6.20, 3, TRUE, 'APPROVED', 245),
(3, 'MySQL 8.0 Query Optimization & Indexing Playbook', 'DATA_SCIENCE', 'mysql_query_optimization.pdf', 'https://resources.capacityconnect.org/mysql_optimization.pdf', 'PDF', 2.40, 1, TRUE, 'APPROVED', 94),
(4, 'Agile Capacity Building & Knowledge Exchange Framework', 'MANAGEMENT', 'capacity_exchange_handbook.pdf', 'https://resources.capacityconnect.org/capacity_handbook.pdf', 'PDF', 5.10, 1, TRUE, 'APPROVED', 180);

-- ─── 17. SYSTEM NOTIFICATIONS ───────────────────────────────────────────────
INSERT INTO notifications (id, user_id, title, message, notification_type, is_read)
VALUES
(1, 4, 'Skill Exchange Accepted!', 'Dr. Aris Vance accepted your skill exchange request for Java Spring Boot.', 'SUCCESS', FALSE),
(2, 4, 'Upcoming Assessment Reminder', 'Your Java Spring Boot & JPA Certification Assessment is due in 3 days.', 'REMINDER', FALSE),
(3, 4, 'Certificate Issued', 'Congratulations! Your certificate for Cloud Infrastructure & Kubernetes is ready.', 'NORMAL', TRUE),
(4, 1, 'New Course Submission', 'Dr. Aris Vance submitted a new course "Enterprise Java & Spring Boot" for admin approval.', 'NORMAL', FALSE);

-- ─── 18. AI ORGANIZATIONAL INSIGHTS ─────────────────────────────────────────
INSERT INTO ai_insights (id, metric_title, category, score_value, severity, recommendation, prediction_highlight)
VALUES
(1, 'Cloud & AI Engineering Skill-Gap Index', 'Organizational Competency', '34% Gap Identified', 'HIGH', 'Increase scheduled peer-to-peer exchanges and expand Spring Boot + LLM cohorts across core engineering squads.', 'Predicted +22% faster project delivery velocity if 40 more engineers complete Level 3 certification.'),
(2, 'Trainer Utilization & Capacity Health', 'Resource Utilization', '84% Optimal', 'MEDIUM', 'Allocate 3 additional peer trainers for Distributed Systems to balance mentorship workload.', 'Trainer burnout risk is minimal; optimal peer skill velocity sustained in Q3.'),
(3, 'Assessment Velocity & Readiness Growth', 'Trainee Performance', '+18.4% MoM', 'LOW', 'Hands-on situational MCQs are yielding 94% first-time pass rates and rapid competency retention.', 'Organization-wide career readiness projected to reach 86% average by next month.');

-- ─── 19. FEEDBACK ────────────────────────────────────────────────────────────
INSERT INTO feedback (id, trainee_id, trainer_id, session_id, rating, comment)
VALUES
(1, 4, 2, 1, 5.0, 'Outstanding knowledge exchange! Dr. Vance explained Spring Data JPA and transactions with exceptional clarity. The peer format made complex concepts easy to grasp.');
