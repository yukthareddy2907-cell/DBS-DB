package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.Course;
import com.capacityconnect.trainer.model.KnowledgeResource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] Repositories for Course & Knowledge Resource Entities
 * =============================================================================
 */
@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByIsPublishedTrue();
    List<Course> findByTrainerId(Long trainerId);
}
