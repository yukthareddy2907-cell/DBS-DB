package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.AssessmentSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] JPA Repository for Assessment Submissions & Exam Records
 * =============================================================================
 */
@Repository
public interface AssessmentSubmissionRepository extends JpaRepository<AssessmentSubmission, Long> {
    List<AssessmentSubmission> findByUserIdOrderBySubmittedAtDesc(Long userId);
    List<AssessmentSubmission> findByAssessmentTrainerIdOrderBySubmittedAtDesc(Long trainerId);
}
