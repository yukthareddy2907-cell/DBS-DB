package com.capacityconnect.skill.service;

import com.capacityconnect.skill.client.TrainerServiceClient;
import com.capacityconnect.skill.dto.SkillGapDtos.*;
import com.capacityconnect.skill.model.*;
import com.capacityconnect.skill.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * =============================================================================
 * [CO1] Relational Schema Data Aggregation & Joins
 * [CO3] Deterministic AI Skill-Gap Engine & Explainability Pipeline
 * [CO4] Enterprise Capacity Building Intelligence Service
 * [CO5] Inter-Service REST Coordination with Trainer Microservice (Port 8083)
 * =============================================================================
 */
@Service
public class SkillGapEngineService {

    private final CompetencyRepository competencyRepository;
    private final RoleFrameworkRepository roleFrameworkRepository;
    private final RoleCompetencyRepository roleCompetencyRepository;
    private final UserCompetencyRepository userCompetencyRepository;
    private final CompetencyHistoryRepository competencyHistoryRepository;
    private final TrainerServiceClient trainerServiceClient;

    @Autowired
    public SkillGapEngineService(CompetencyRepository competencyRepository,
                                 RoleFrameworkRepository roleFrameworkRepository,
                                 RoleCompetencyRepository roleCompetencyRepository,
                                 UserCompetencyRepository userCompetencyRepository,
                                 CompetencyHistoryRepository competencyHistoryRepository,
                                 TrainerServiceClient trainerServiceClient) {
        this.competencyRepository = competencyRepository;
        this.roleFrameworkRepository = roleFrameworkRepository;
        this.roleCompetencyRepository = roleCompetencyRepository;
        this.userCompetencyRepository = userCompetencyRepository;
        this.competencyHistoryRepository = competencyHistoryRepository;
        this.trainerServiceClient = trainerServiceClient;
    }

    /**
     * Comprehensive, Data-Driven Skill Gap Analysis for Target Role
     */
    public SkillGapAnalysisResponse analyzeUserSkillGaps(Long userId, String targetRoleName) {
        String roleToAnalyze = (targetRoleName != null && !targetRoleName.isBlank()) 
                ? targetRoleName 
                : "Data Analyst";

        // 1. Retrieve Required Competencies for Target Role [CO1]
        List<RoleCompetency> requiredCompetencies = roleCompetencyRepository.findByRoleName(roleToAnalyze);
        if (requiredCompetencies.isEmpty()) {
            // Fallback to Data Analyst framework if custom role not mapped yet
            requiredCompetencies = roleCompetencyRepository.findByRoleName("Data Analyst");
        }

        // 2. Retrieve Current User Competencies [CO1]
        List<UserCompetency> userCompetencies = userCompetencyRepository.findByUserId(userId);
        Map<String, UserCompetency> userCompMap = userCompetencies.stream()
                .collect(Collectors.toMap(uc -> uc.getCompetency().getName(), uc -> uc, (a, b) -> a));

        List<SkillGapItem> allItems = new ArrayList<>();
        double totalWeightedCurrent = 0.0;
        double totalWeightedRequired = 0.0;
        int totalGapsCount = 0;
        List<String> criticalGapSkillNames = new ArrayList<>();

        // 3. Deterministic Gap Calculation Loop [CO3]
        for (RoleCompetency rc : requiredCompetencies) {
            String skillName = rc.getCompetency().getName();
            int requiredLevel = rc.getRequiredProficiency();
            double weight = rc.getWeightMultiplier();

            UserCompetency userComp = userCompMap.get(skillName);
            int currentLevel = (userComp != null) ? userComp.getCurrentProficiency() : 1;
            String evidence = (userComp != null) ? userComp.getEvidence() : "Initial Diagnostic / Baseline";

            int gap = Math.max(0, requiredLevel - currentLevel);
            String severity;
            String priority;

            if (gap == 0) {
                severity = "Meets Requirement";
                priority = "LOW";
            } else if (gap == 1) {
                severity = "Low";
                priority = (rc.getImportanceWeight() == RoleCompetency.ImportanceWeight.HIGH) ? "MEDIUM" : "LOW";
                totalGapsCount++;
            } else if (gap == 2) {
                severity = "Moderate";
                priority = (rc.getImportanceWeight() == RoleCompetency.ImportanceWeight.LOW) ? "MEDIUM" : "HIGH";
                totalGapsCount++;
                criticalGapSkillNames.add(skillName);
            } else {
                severity = "Critical";
                priority = "HIGH";
                totalGapsCount++;
                criticalGapSkillNames.add(skillName);
            }

            // Weighted readiness accumulation
            totalWeightedCurrent += (Math.min(currentLevel, requiredLevel) * weight);
            totalWeightedRequired += (requiredLevel * weight);

            String reason = generateExplainableReason(skillName, currentLevel, requiredLevel, rc.getImportanceWeight().name(), roleToAnalyze, evidence);
            String action = generateLearningAction(skillName, currentLevel, requiredLevel);
            String estimatedGain = "+" + (gap * 15 + 5) + "% benchmark readiness";

            allItems.add(SkillGapItem.builder()
                    .skillName(skillName)
                    .category(rc.getCompetency().getCategory())
                    .currentProficiency(currentLevel)
                    .requiredProficiency(requiredLevel)
                    .gap(gap)
                    .severity(severity)
                    .priority(priority)
                    .roleWeight(weight)
                    .evidence(evidence)
                    .reason(reason)
                    .recommendedAction(action)
                    .estimatedImprovement(estimatedGain)
                    .build());
        }

        // 4. Calculate Overall Role Readiness Percentage
        int overallReadiness = (totalWeightedRequired > 0)
                ? (int) Math.round((totalWeightedCurrent / totalWeightedRequired) * 100)
                : 68;

        // Sort items by priority (HIGH -> MEDIUM -> LOW) and gap size
        allItems.sort((a, b) -> {
            int pCompare = getPriorityWeight(b.getPriority()) - getPriorityWeight(a.getPriority());
            if (pCompare != 0) return pCompare;
            return b.getGap() - a.getGap();
        });

        List<SkillGapItem> priorityGaps = allItems.stream()
                .filter(item -> item.getGap() > 0)
                .limit(3)
                .collect(Collectors.toList());

        // 5. Generate AI Explainability Narrative
        String explainableSummary = generateComprehensiveSummary(roleToAnalyze, overallReadiness, priorityGaps);

        // 6. Generate Personalized Multi-Stage Learning Path
        List<LearningPathStage> learningPath = generatePersonalizedLearningPath(priorityGaps);

        // 7. [CO5] Inter-Service REST Call: Query Trainer Service for Matching Mentors
        List<Map<String, Object>> recommendedTrainers = trainerServiceClient.getMatchingTrainersForSkills(criticalGapSkillNames);

        // 8. Fetch Progress History [CO1]
        List<CompetencyHistory> historyList = competencyHistoryRepository.findByUserIdOrderByRecordedAtDesc(userId);
        List<CompetencyHistoryDto> historyDtos = historyList.stream().map(h -> CompetencyHistoryDto.builder()
                .skillName(h.getCompetency().getName())
                .previousLevel(h.getPreviousLevel())
                .newLevel(h.getNewLevel())
                .triggerEvent(h.getTriggerEvent())
                .assessmentScore(h.getAssessmentScore())
                .recordedAt(h.getRecordedAt())
                .build()).collect(Collectors.toList());

        return SkillGapAnalysisResponse.builder()
                .userId(userId)
                .targetRole(roleToAnalyze)
                .overallReadiness(overallReadiness)
                .totalGapsCount(totalGapsCount)
                .explainableAiSummary(explainableSummary)
                .priorityGaps(priorityGaps)
                .allCompetencies(allItems)
                .personalizedLearningPath(learningPath)
                .recommendedTrainers(recommendedTrainers)
                .recentProgressHistory(historyDtos)
                .build();
    }

    /**
     * [CO1] Closed Feedback Loop: Update Competency after Assessment / Course
     */
    @Transactional
    public SkillGapAnalysisResponse updateUserCompetency(UpdateCompetencyRequest request) {
        Competency comp = competencyRepository.findByName(request.getSkillName())
                .orElseThrow(() -> new IllegalArgumentException("Competency " + request.getSkillName() + " not found."));

        Optional<UserCompetency> existingOpt = userCompetencyRepository.findByUserIdAndCompetencyId(request.getUserId(), comp.getId());

        int previousLevel = existingOpt.map(UserCompetency::getCurrentProficiency).orElse(1);
        int newLevel = Math.max(1, Math.min(5, request.getNewProficiency()));

        UserCompetency userComp = existingOpt.orElse(UserCompetency.builder()
                .userId(request.getUserId())
                .competency(comp)
                .build());

        userComp.setCurrentProficiency(newLevel);
        userComp.setEvidence((request.getTriggerEvent() != null ? request.getTriggerEvent() : "Verified Assessment") 
                + (request.getAssessmentScore() != null ? " (" + Math.round(request.getAssessmentScore()) + "% Score)" : ""));
        userComp.setConfidenceScore(0.92);
        userCompetencyRepository.save(userComp);

        // Record in History for Progress Tracking
        CompetencyHistory history = CompetencyHistory.builder()
                .userId(request.getUserId())
                .competency(comp)
                .previousLevel(previousLevel)
                .newLevel(newLevel)
                .triggerEvent(request.getTriggerEvent() != null ? request.getTriggerEvent() : "Assessment Evaluation")
                .assessmentScore(request.getAssessmentScore())
                .build();
        competencyHistoryRepository.save(history);

        // Recalculate and return updated closed-loop analysis
        return analyzeUserSkillGaps(request.getUserId(), "Data Analyst");
    }

    private int getPriorityWeight(String priority) {
        if ("HIGH".equalsIgnoreCase(priority)) return 3;
        if ("MEDIUM".equalsIgnoreCase(priority)) return 2;
        return 1;
    }

    private String generateExplainableReason(String skill, int current, int required, String importance, String role, String evidence) {
        return skill + " is currently at Level " + current + "/5 while your selected " + role 
                + " framework requires Level " + required + "/5. " + skill + " is classified as a " 
                + importance + " importance competency. Evidence from " + evidence 
                + " confirms targeted development is needed to close this " + (required - current) + "-level gap.";
    }

    private String generateLearningAction(String skill, int current, int required) {
        if ("SQL".equalsIgnoreCase(skill)) {
            return "Complete Window Functions & Query Execution Plan labs, then schedule a 1-on-1 review with Dr. Aris Vance.";
        } else if ("Power BI".equalsIgnoreCase(skill)) {
            return "Complete DAX Measures & Star Schema Workshop, followed by the Power BI Proficiency Assessment.";
        } else if ("Statistics".equalsIgnoreCase(skill)) {
            return "Study Hypothesis Testing & Confidence Interval modules with interactive problem sets.";
        }
        return "Complete targeted modules in " + skill + " and take the verified competency assessment.";
    }

    private String generateComprehensiveSummary(String role, int readiness, List<SkillGapItem> priorityGaps) {
        if (priorityGaps.isEmpty()) {
            return "Outstanding! You currently meet 100% of the required competency benchmarks for " + role + ". Maintain your skills through advanced capstone challenges.";
        }
        String gapNames = priorityGaps.stream().map(SkillGapItem::getSkillName).collect(Collectors.joining(", "));
        return "Your current role readiness for " + role + " is calculated at " + readiness 
                + "% against our weighted organizational framework. The primary drivers constraining higher readiness are critical gaps in " 
                + gapNames + ". Closing these top priority areas will elevate your readiness above 85%.";
    }

    private List<LearningPathStage> generatePersonalizedLearningPath(List<SkillGapItem> priorityGaps) {
        List<LearningPathStage> path = new ArrayList<>();
        int stageNum = 1;

        for (SkillGapItem gap : priorityGaps) {
            path.add(LearningPathStage.builder()
                    .stage(stageNum++)
                    .skill(gap.getSkillName())
                    .stageTitle(gap.getSkillName() + " Core Fundamentals & Setup")
                    .description("Review foundational syntax, architectural principles, and core design patterns.")
                    .practicalActivity("Complete hands-on interactive guided exercises and syntax check.")
                    .estimatedHours(4)
                    .build());

            path.add(LearningPathStage.builder()
                    .stage(stageNum++)
                    .skill(gap.getSkillName())
                    .stageTitle(gap.getSkillName() + " Advanced Practical Applications")
                    .description("Deep-dive into advanced features, performance optimization, and real datasets.")
                    .practicalActivity("Solve real-world scenario project and verify outputs against benchmark.")
                    .estimatedHours(8)
                    .build());

            path.add(LearningPathStage.builder()
                    .stage(stageNum++)
                    .skill(gap.getSkillName())
                    .stageTitle(gap.getSkillName() + " Competency Certification Assessment")
                    .description("Validate acquired mastery through timed, AI-evaluated technical assessment.")
                    .practicalActivity("Take the official MCQ assessment and achieve 75%+ score.")
                    .estimatedHours(2)
                    .build());
        }

        return path;
    }
}
