package com.capacityconnect.user.controller;

import com.capacityconnect.user.model.User;
import com.capacityconnect.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] REST API Controller for User & Profile Management
 * [CO5] Bounded Context API Endpoint for User Data Querying
 * =============================================================================
 */
@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        return userService.getUserById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}/target-role")
    public ResponseEntity<?> updateTargetRole(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String targetRole = body.get("targetRole");
        if (targetRole == null || targetRole.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "targetRole is required"));
        }
        User updated = userService.updateTargetRole(id, targetRole);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok(Map.of("message", "User with ID " + id + " successfully deleted."));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }
}
