package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Skill Exchange Requests (Pending -> Accepted / Declined)
 * =============================================================================
 */
@Entity
@Table(name = "skill_exchange_requests")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SkillExchangeRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "trainee_id", nullable = false)
    private Long traineeId;

    @Column(name = "trainee_name", nullable = false, length = 150)
    private String traineeName;

    @Column(name = "trainer_id", nullable = false)
    private Long trainerId;

    @Column(name = "trainer_name", nullable = false, length = 150)
    private String trainerName;

    @Column(name = "skill_requested", nullable = false, length = 100)
    private String skillRequested;

    @Column(name = "skill_offered", length = 100)
    @Builder.Default
    private String skillOffered = "Business Presentation & Excel";

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private ExchangeStatus status = ExchangeStatus.PENDING;

    @Column(name = "decline_reason")
    private String declineReason;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum ExchangeStatus {
        PENDING, ACCEPTED, DECLINED
    }
}
