package com.capacityconnect.skill.repository;

import com.capacityconnect.skill.model.RoleFramework;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Repository for Target Roles Framework
 * =============================================================================
 */
@Repository
public interface RoleFrameworkRepository extends JpaRepository<RoleFramework, Long> {
    Optional<RoleFramework> findByRoleName(String roleName);
    boolean existsByRoleName(String roleName);
}
