package com.capacityconnect.skill.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO5] Inter-Service REST Communication Client (Skill Service -> Trainer Service)
 * Calls Trainer Service on Port 8083 to fetch matched trainers for identified gaps.
 * =============================================================================
 */
@Component
public class TrainerServiceClient {

    private final RestTemplate restTemplate;
    private final String trainerServiceUrl;

    @Autowired
    public TrainerServiceClient(RestTemplate restTemplate,
                                @Value("${services.trainer.url:http://localhost:8083/api}") String trainerServiceUrl) {
        this.restTemplate = restTemplate;
        this.trainerServiceUrl = trainerServiceUrl;
    }

    public List<Map<String, Object>> getMatchingTrainersForSkills(List<String> skills) {
        if (skills == null || skills.isEmpty()) {
            return Collections.emptyList();
        }

        try {
            String skillParams = String.join(",", skills);
            String url = trainerServiceUrl + "/trainers/match?skills=" + skillParams;

            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {}
            );

            return response.getBody() != null ? response.getBody() : Collections.emptyList();
        } catch (Exception ex) {
            System.err.println("[CO5 Inter-Service REST Warning] Could not reach Trainer Service at " 
                    + trainerServiceUrl + ": " + ex.getMessage());
            return Collections.emptyList();
        }
    }
}
