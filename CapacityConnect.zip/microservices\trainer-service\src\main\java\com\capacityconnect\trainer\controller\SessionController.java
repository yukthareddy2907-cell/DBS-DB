package com.capacityconnect.trainer.controller;

import com.capacityconnect.trainer.model.CalendarNote;
import com.capacityconnect.trainer.model.TrainingSession;
import com.capacityconnect.trainer.repository.CalendarNoteRepository;
import com.capacityconnect.trainer.repository.TrainingSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] REST Controller for Training Sessions & Side Notes Box
 * =============================================================================
 */
@RestController
@RequestMapping("/sessions")
public class SessionController {

    private final TrainingSessionRepository sessionRepository;
    private final CalendarNoteRepository calendarNoteRepository;

    @Autowired
    public SessionController(TrainingSessionRepository sessionRepository,
                             CalendarNoteRepository calendarNoteRepository) {
        this.sessionRepository = sessionRepository;
        this.calendarNoteRepository = calendarNoteRepository;
    }

    @GetMapping
    public ResponseEntity<List<TrainingSession>> getAllSessions() {
        return ResponseEntity.ok(sessionRepository.findAll());
    }

    @GetMapping("/trainer/{trainerId}")
    public ResponseEntity<List<TrainingSession>> getSessionsForTrainer(@PathVariable Long trainerId) {
        return ResponseEntity.ok(sessionRepository.findByTrainerId(trainerId));
    }

    @GetMapping("/trainee/{traineeId}")
    public ResponseEntity<List<TrainingSession>> getSessionsForTrainee(@PathVariable Long traineeId) {
        return ResponseEntity.ok(sessionRepository.findByTraineeId(traineeId));
    }

    @GetMapping("/notes/{userId}")
    public ResponseEntity<?> getNotesForUser(@PathVariable Long userId) {
        return ResponseEntity.ok(calendarNoteRepository.findByUserId(userId)
                .orElse(CalendarNote.builder()
                        .userId(userId)
                        .noteContent("Personal Study Notes & Goals:\n- Review SQL joins and window functions.\n- Prepare questions for mentorship exchange.")
                        .build()));
    }

    @PostMapping("/notes/{userId}")
    public ResponseEntity<?> saveNotesForUser(@PathVariable Long userId, @RequestBody Map<String, String> body) {
        String content = body.get("noteContent");
        CalendarNote note = calendarNoteRepository.findByUserId(userId)
                .orElse(CalendarNote.builder().userId(userId).build());
        note.setNoteContent(content != null ? content : "");
        CalendarNote saved = calendarNoteRepository.save(note);
        return ResponseEntity.ok(saved);
    }
}
