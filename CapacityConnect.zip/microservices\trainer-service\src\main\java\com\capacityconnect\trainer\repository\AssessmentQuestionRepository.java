package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.AssessmentQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] JPA Repository for Assessment Questions
 * =============================================================================
 */
@Repository
public interface AssessmentQuestionRepository extends JpaRepository<AssessmentQuestion, Long> {
    List<AssessmentQuestion> findByAssessmentId(Long assessmentId);
}
