package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Training Sessions & Calendar Model
 * =============================================================================
 */
@Entity
@Table(name = "training_sessions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainingSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "trainer_id", nullable = false)
    private Long trainerId;

    @Column(name = "trainee_id", nullable = false)
    private Long traineeId;

    @Column(name = "trainee_name", nullable = false, length = 150)
    private String traineeName;

    @Column(nullable = false, length = 200)
    private String topic;

    @Column(name = "session_time", nullable = false, length = 100)
    private String sessionTime;

    @Column(length = 50)
    @Builder.Default
    private String status = "SCHEDULED";

    @Column(name = "meeting_link", length = 255)
    @Builder.Default
    private String meetingLink = "https://meet.google.com/cap-conn-learn";

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
