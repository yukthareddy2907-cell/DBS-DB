-- ============================================================================
-- CAPACITY CONNECT — AI-Powered Organizational Capacity Building Platform
-- Complete MySQL 8.0+ Database Schema for MySQL Workbench
-- ============================================================================

CREATE DATABASE IF NOT EXISTS capacity_connect_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE capacity_connect_db;

SET FOREIGN_KEY_CHECKS = 0;

-- ─── 1. USERS ────────────────────────────────────────────────────────────────
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS ai_insights;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS knowledge_resources;
DROP TABLE IF EXISTS certificates;
DROP TABLE IF EXISTS assessment_submissions;
DROP TABLE IF EXISTS assessment_questions;
DROP TABLE IF EXISTS assessments;
DROP TABLE IF EXISTS training_sessions;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS skill_exchange_requests;
DROP TABLE IF EXISTS course_enrollments;
DROP TABLE IF EXISTS course_competencies;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS competency_records;
DROP TABLE IF EXISTS competencies;
DROP TABLE IF EXISTS user_skills;
DROP TABLE IF EXISTS user_profiles;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  full_name      VARCHAR(150)   NOT NULL,
  email          VARCHAR(150)   NOT NULL UNIQUE,
  password_hash  VARCHAR(255)   NOT NULL,
  avatar_url     VARCHAR(500)   DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  primary_role   ENUM('TRAINEE','TRAINER','ADMIN') NOT NULL DEFAULT 'TRAINEE',
  is_trainee     BOOLEAN        NOT NULL DEFAULT TRUE,
  is_trainer     BOOLEAN        NOT NULL DEFAULT FALSE,
  is_admin       BOOLEAN        NOT NULL DEFAULT FALSE,
  is_approved    BOOLEAN        NOT NULL DEFAULT TRUE,
  account_status ENUM('ACTIVE','PENDING','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
  target_role    VARCHAR(150)   DEFAULT 'Full-Stack Software Engineer',
  department     VARCHAR(100)   DEFAULT 'Engineering & Technology',
  created_at     TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_user_email (email),
  INDEX idx_user_roles (is_trainee, is_trainer, is_admin)
) ENGINE=InnoDB;

-- ─── 2. USER PROFILES ────────────────────────────────────────────────────────
CREATE TABLE user_profiles (
  user_id                BIGINT PRIMARY KEY,
  bio                    TEXT NULL,
  expertise              VARCHAR(500) NULL,
  qualifications         VARCHAR(500) NULL,
  experience_years       INT DEFAULT 0,
  department             VARCHAR(100) DEFAULT 'Engineering & Technology',
  performance_rating     DECIMAL(3,2) DEFAULT 4.80,
  career_readiness_score INT DEFAULT 78,
  overall_competency     INT DEFAULT 72,
  learning_streak_days   INT DEFAULT 12,
  xp_points              INT DEFAULT 1850,
  current_level          INT DEFAULT 4,
  total_completed_courses INT DEFAULT 5,
  training_completion_rate INT DEFAULT 88,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 3. USER SKILLS ──────────────────────────────────────────────────────────
CREATE TABLE user_skills (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id          BIGINT NOT NULL,
  skill_name       VARCHAR(100) NOT NULL,
  proficiency_level ENUM('BEGINNER','INTERMEDIATE','ADVANCED','EXPERT') DEFAULT 'INTERMEDIATE',
  current_score    INT DEFAULT 60,
  target_score     INT DEFAULT 85,
  category         VARCHAR(100) DEFAULT 'General',
  is_teaching      BOOLEAN DEFAULT FALSE,
  is_learning      BOOLEAN DEFAULT TRUE,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_skills (user_id, skill_name)
) ENGINE=InnoDB;

-- ─── 4. COMPETENCIES (Admin-defined Framework) ──────────────────────────────
CREATE TABLE competencies (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(150) NOT NULL,
  category         VARCHAR(100) NOT NULL,
  required_level   ENUM('LEVEL_1_FOUNDATIONAL','LEVEL_2_INTERMEDIATE','LEVEL_3_ADVANCED','LEVEL_4_EXPERT') NOT NULL DEFAULT 'LEVEL_3_ADVANCED',
  required_score   INT DEFAULT 80,
  description      TEXT NOT NULL,
  mapped_role      VARCHAR(150) NOT NULL,
  org_current_avg  INT DEFAULT 58,
  org_gap_severity ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'MEDIUM',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─── 5. COMPETENCY RECORDS (Per-user tracking) ───────────────────────────────
CREATE TABLE competency_records (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id         BIGINT NOT NULL,
  competency_id   BIGINT NOT NULL,
  current_level   INT DEFAULT 54,
  target_level    INT DEFAULT 80,
  gap             INT GENERATED ALWAYS AS (GREATEST(target_level - current_level, 0)) STORED,
  priority        ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'HIGH',
  status          ENUM('IDENTIFIED','LEARNING','REASSESSMENT','IMPROVED','TARGET_ACHIEVED') DEFAULT 'IDENTIFIED',
  last_assessed   TIMESTAMP NULL,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE CASCADE,
  UNIQUE KEY uq_user_comp (user_id, competency_id)
) ENGINE=InnoDB;

-- ─── 6. COURSES ──────────────────────────────────────────────────────────────
CREATE TABLE courses (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  title           VARCHAR(200) NOT NULL,
  category        VARCHAR(100) NOT NULL,
  description     TEXT NOT NULL,
  trainer_id      BIGINT NOT NULL,
  duration_hours  INT DEFAULT 16,
  total_lessons   INT DEFAULT 10,
  difficulty      ENUM('BEGINNER','INTERMEDIATE','ADVANCED') DEFAULT 'INTERMEDIATE',
  thumbnail_url   VARCHAR(500) DEFAULT 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500',
  is_public       BOOLEAN DEFAULT TRUE,
  is_approved     BOOLEAN DEFAULT TRUE,
  approval_status ENUM('PENDING','APPROVED','REJECTED') DEFAULT 'APPROVED',
  passing_score   INT DEFAULT 70,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 7. COURSE-COMPETENCY MAPPINGS ──────────────────────────────────────────
CREATE TABLE course_competencies (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  course_id       BIGINT NOT NULL,
  competency_id   BIGINT NOT NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE CASCADE,
  UNIQUE KEY uq_course_comp (course_id, competency_id)
) ENGINE=InnoDB;

-- ─── 8. COURSE ENROLLMENTS ──────────────────────────────────────────────────
CREATE TABLE course_enrollments (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  course_id           BIGINT NOT NULL,
  trainee_id          BIGINT NOT NULL,
  progress_percentage INT DEFAULT 0,
  completed_lessons   INT DEFAULT 0,
  status              ENUM('ENROLLED','IN_PROGRESS','COMPLETED') DEFAULT 'ENROLLED',
  enrolled_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at        TIMESTAMP NULL,
  last_accessed_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_trainee_course (course_id, trainee_id),
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 9. SKILL EXCHANGE REQUESTS ─────────────────────────────────────────────
CREATE TABLE skill_exchange_requests (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainee_id      BIGINT NOT NULL,
  trainer_id      BIGINT NOT NULL,
  skill_wanted    VARCHAR(100) NOT NULL,
  skill_offered   VARCHAR(100) NOT NULL,
  message         TEXT NOT NULL,
  status          ENUM('PENDING','ACCEPTED','DECLINED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  feedback_notes  TEXT NULL,
  rating_given    DECIMAL(2,1) NULL,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 10. REAL-TIME CHAT MESSAGES ────────────────────────────────────────────
CREATE TABLE chat_messages (
  id                   BIGINT AUTO_INCREMENT PRIMARY KEY,
  exchange_request_id  BIGINT NOT NULL,
  sender_id            BIGINT NOT NULL,
  receiver_id          BIGINT NOT NULL,
  message_content      TEXT NOT NULL,
  is_read              BOOLEAN DEFAULT FALSE,
  sent_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (exchange_request_id) REFERENCES skill_exchange_requests(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_chat_convo (exchange_request_id, sent_at)
) ENGINE=InnoDB;

-- ─── 11. ASSESSMENTS ────────────────────────────────────────────────────────
CREATE TABLE assessments (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  title            VARCHAR(200) NOT NULL,
  category         VARCHAR(100) NOT NULL,
  course_id        BIGINT NULL,
  trainer_id       BIGINT NOT NULL,
  competency_id    BIGINT NULL,
  duration_minutes INT DEFAULT 20,
  total_marks      INT DEFAULT 100,
  passing_marks    INT DEFAULT 70,
  is_active        BOOLEAN DEFAULT TRUE,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
  FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (competency_id) REFERENCES competencies(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── 12. ASSESSMENT QUESTIONS (Answer keys secret on server) ────────────────
CREATE TABLE assessment_questions (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  assessment_id   BIGINT NOT NULL,
  question_text   TEXT NOT NULL,
  option_a        VARCHAR(500) NOT NULL,
  option_b        VARCHAR(500) NOT NULL,
  option_c        VARCHAR(500) NOT NULL,
  option_d        VARCHAR(500) NOT NULL,
  correct_option  ENUM('A','B','C','D') NOT NULL,
  marks           INT DEFAULT 25,
  skill_tag       VARCHAR(100) NULL,
  explanation     TEXT NULL,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 13. ASSESSMENT SUBMISSIONS & INSTANT AI EVALUATION ─────────────────────
CREATE TABLE assessment_submissions (
  id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
  assessment_id         BIGINT NOT NULL,
  trainee_id            BIGINT NOT NULL,
  score_obtained        INT NOT NULL,
  total_marks           INT NOT NULL,
  percentage            DECIMAL(5,2) NOT NULL,
  status                ENUM('SUBMITTED','EVALUATED','PASSED','FAILED') DEFAULT 'EVALUATED',
  strong_areas          TEXT NULL,
  weak_areas            TEXT NULL,
  ai_evaluation_summary TEXT NULL,
  ai_improvement_tips   TEXT NULL,
  submitted_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 14. CERTIFICATES REGISTRY ──────────────────────────────────────────────
CREATE TABLE certificates (
  id                BIGINT AUTO_INCREMENT PRIMARY KEY,
  certificate_code  VARCHAR(100) NOT NULL UNIQUE,
  trainee_id        BIGINT NOT NULL,
  course_id         BIGINT NULL,
  assessment_id     BIGINT NULL,
  title             VARCHAR(200) NOT NULL,
  score             INT DEFAULT 90,
  grade             VARCHAR(30) DEFAULT 'Distinction',
  issue_date        DATE NOT NULL,
  issuing_org       VARCHAR(200) DEFAULT 'CAPACITY CONNECT Enterprise Academy',
  verification_url  VARCHAR(300) NOT NULL,
  is_valid          BOOLEAN DEFAULT TRUE,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
  FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE SET NULL,
  INDEX idx_cert_code (certificate_code),
  INDEX idx_cert_trainee (trainee_id)
) ENGINE=InnoDB;

-- ─── 15. TRAINING SESSIONS & CALENDAR ───────────────────────────────────────
CREATE TABLE training_sessions (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainer_id    BIGINT NOT NULL,
  trainee_id    BIGINT NULL,
  title         VARCHAR(200) NOT NULL,
  topic         VARCHAR(150) NOT NULL,
  session_date  DATE NOT NULL,
  start_time    TIME NOT NULL,
  end_time      TIME NOT NULL,
  meeting_link  VARCHAR(300) DEFAULT 'https://meet.capacityconnect.internal/session',
  session_type  ENUM('ONE_ON_ONE','GROUP','WORKSHOP') DEFAULT 'ONE_ON_ONE',
  status        ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
  FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ─── 16. KNOWLEDGE HUB PUBLIC RESOURCES ─────────────────────────────────────
CREATE TABLE knowledge_resources (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  title           VARCHAR(200) NOT NULL,
  category        ENUM('ALL_SKILLS','AI_ML','PROGRAMMING','DATA_SCIENCE','MANAGEMENT','OTHER') DEFAULT 'PROGRAMMING',
  file_name       VARCHAR(255) NOT NULL,
  file_url        VARCHAR(500) NOT NULL,
  file_type       VARCHAR(50) DEFAULT 'PDF',
  file_size_mb    DECIMAL(5,2) DEFAULT 4.50,
  uploaded_by     BIGINT NOT NULL,
  is_approved     BOOLEAN DEFAULT TRUE,
  approval_status ENUM('PENDING','APPROVED','REJECTED') DEFAULT 'APPROVED',
  download_count  INT DEFAULT 42,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─── 17. SYSTEM NOTIFICATIONS ───────────────────────────────────────────────
CREATE TABLE notifications (
  id                BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id           BIGINT NOT NULL,
  title             VARCHAR(150) NOT NULL,
  message           TEXT NOT NULL,
  notification_type ENUM('NORMAL','SUCCESS','REMINDER','WARNING') DEFAULT 'NORMAL',
  link_url          VARCHAR(300) NULL,
  is_read           BOOLEAN DEFAULT FALSE,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, is_read)
) ENGINE=InnoDB;

-- ─── 18. AI ORGANIZATIONAL INSIGHTS ─────────────────────────────────────────
CREATE TABLE ai_insights (
  id                   BIGINT AUTO_INCREMENT PRIMARY KEY,
  metric_title         VARCHAR(200) NOT NULL,
  category             VARCHAR(100) NOT NULL,
  score_value          VARCHAR(50) NOT NULL,
  severity             ENUM('LOW','MEDIUM','HIGH','CRITICAL') DEFAULT 'MEDIUM',
  recommendation       TEXT NOT NULL,
  prediction_highlight VARCHAR(500) NOT NULL,
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─── 19. FEEDBACK ────────────────────────────────────────────────────────────
CREATE TABLE feedback (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  trainee_id    BIGINT NOT NULL,
  trainer_id    BIGINT NOT NULL,
  session_id    BIGINT NULL,
  rating        DECIMAL(2,1) NOT NULL DEFAULT 5.0,
  comment       TEXT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (trainee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE SET NULL
) ENGINE=InnoDB;
