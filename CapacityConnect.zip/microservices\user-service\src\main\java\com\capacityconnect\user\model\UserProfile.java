package com.capacityconnect.user.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Database Normalization: 1-to-1 User Profile Table
 * =============================================================================
 */
@Entity
@Table(name = "user_profiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfile {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @Column(columnDefinition = "TEXT")
    private String bio;

    @Column(length = 500)
    private String expertise;

    @Column(length = 500)
    private String qualifications;

    @Column(name = "experience_years")
    @Builder.Default
    private int experienceYears = 2;

    @Column(length = 100)
    @Builder.Default
    private String department = "Data & Analytics";

    @Column(name = "career_readiness_score")
    @Builder.Default
    private int careerReadinessScore = 68;

    @Column(name = "learning_streak_days")
    @Builder.Default
    private int learningStreakDays = 5;

    @Column(name = "learning_progress_rate")
    @Builder.Default
    private int learningProgressRate = 62;

    @Column(name = "xp_points")
    @Builder.Default
    private int xpPoints = 1420;

    @Column(name = "current_level")
    @Builder.Default
    private int currentLevel = 3;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
