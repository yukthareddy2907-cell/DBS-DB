package com.capacityconnect.trainer.controller;

import com.capacityconnect.trainer.dto.TrainerDtos.CreateKnowledgeResourceRequest;
import com.capacityconnect.trainer.model.KnowledgeResource;
import com.capacityconnect.trainer.service.KnowledgeHubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] REST Controller for Knowledge Hub Resources
 * =============================================================================
 */
@RestController
@RequestMapping("/resources")
public class KnowledgeHubController {

    private final KnowledgeHubService knowledgeHubService;

    @Autowired
    public KnowledgeHubController(KnowledgeHubService knowledgeHubService) {
        this.knowledgeHubService = knowledgeHubService;
    }

    @GetMapping
    public ResponseEntity<List<KnowledgeResource>> getAllResources() {
        return ResponseEntity.ok(knowledgeHubService.getAllResources());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getResourceById(@PathVariable Long id) {
        return knowledgeHubService.getResourceById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> uploadResource(@RequestBody CreateKnowledgeResourceRequest request) {
        try {
            KnowledgeResource resource = knowledgeHubService.uploadResource(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(resource);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateResource(@PathVariable Long id, @RequestBody CreateKnowledgeResourceRequest request) {
        try {
            KnowledgeResource updated = knowledgeHubService.updateResource(id, request);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteResource(@PathVariable Long id) {
        try {
            knowledgeHubService.deleteResource(id);
            return ResponseEntity.ok(Map.of("message", "Resource with ID " + id + " deleted successfully."));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PostMapping("/{id}/download")
    public ResponseEntity<?> recordDownload(@PathVariable Long id) {
        try {
            KnowledgeResource resource = knowledgeHubService.recordDownload(id);
            return ResponseEntity.ok(resource);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }
}
