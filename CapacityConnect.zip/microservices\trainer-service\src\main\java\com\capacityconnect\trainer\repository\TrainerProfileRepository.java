package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Repositories for Trainer Domain & Relational Queries
 * =============================================================================
 */
@Repository
public interface TrainerProfileRepository extends JpaRepository<TrainerProfile, Long> {
    Optional<TrainerProfile> findByUserId(Long userId);
    
    @Query("SELECT t FROM TrainerProfile t WHERE LOWER(t.skillsTaught) LIKE LOWER(CONCAT('%', :skill, '%'))")
    List<TrainerProfile> findBySkillTaught(@Param("skill") String skill);
}
