package com.capacityconnect.trainer.service;

import com.capacityconnect.trainer.model.TrainerProfile;
import com.capacityconnect.trainer.repository.TrainerProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * =============================================================================
 * [CO1] JPA Queries & Matching Algorithms for Trainer Mentorship
 * [CO4] Trainer Service Business Logic
 * [CO5] Bounded Context API Provider for Skill Service Inter-Service REST Calls
 * =============================================================================
 */
@Service
public class TrainerService {

    private final TrainerProfileRepository trainerProfileRepository;

    @Autowired
    public TrainerService(TrainerProfileRepository trainerProfileRepository) {
        this.trainerProfileRepository = trainerProfileRepository;
    }

    public List<TrainerProfile> getAllTrainers() {
        return trainerProfileRepository.findAll();
    }

    public Optional<TrainerProfile> getTrainerById(Long id) {
        return trainerProfileRepository.findById(id);
    }

    public Optional<TrainerProfile> getTrainerByUserId(Long userId) {
        return trainerProfileRepository.findByUserId(userId);
    }

    /**
     * [CO5] Match Trainers based on list of identified skill gaps
     */
    public List<Map<String, Object>> matchTrainersForSkills(List<String> skills) {
        List<TrainerProfile> all = trainerProfileRepository.findAll();
        List<Map<String, Object>> matches = new ArrayList<>();

        for (TrainerProfile t : all) {
            List<String> matchedSkills = new ArrayList<>();
            for (String skill : skills) {
                if (t.getSkillsTaught() != null && t.getSkillsTaught().toLowerCase().contains(skill.toLowerCase().trim())) {
                    matchedSkills.add(skill);
                }
            }

            if (!matchedSkills.isEmpty() || skills.isEmpty()) {
                Map<String, Object> map = new HashMap<>();
                map.put("id", t.getId());
                map.put("userId", t.getUserId());
                map.put("fullName", t.getFullName());
                map.put("email", t.getEmail());
                map.put("avatarUrl", t.getAvatarUrl());
                map.put("primaryExpertise", t.getPrimaryExpertise());
                map.put("skillsTaught", t.getSkillsTaught());
                map.put("skillsWants", t.getSkillsWants());
                map.put("rating", t.getRating());
                map.put("experienceYears", t.getExperienceYears());
                map.put("availabilityStatus", t.getAvailabilityStatus());
                map.put("bio", t.getBio());
                map.put("matchedSkills", matchedSkills);
                map.put("matchReason", "Expert mentor in " + String.join(", ", matchedSkills) + " with " + t.getRating() + "/5.0 verified rating");
                matches.add(map);
            }
        }

        return matches;
    }
}
