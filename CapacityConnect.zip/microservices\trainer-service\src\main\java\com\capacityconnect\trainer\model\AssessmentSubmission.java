package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Assessment Submissions Entity with Score & AI Evaluation Breakdown
 * [CO2] Document/JSON Persistence for Question-by-Question Evaluation Review
 * =============================================================================
 */
@Entity
@Table(name = "assessment_submissions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssessmentSubmission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "assessment_id", nullable = false)
    private Assessment assessment;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "user_name", nullable = false, length = 150)
    private String userName;

    @Column(name = "score_percentage", nullable = false)
    private double scorePercentage;

    @Column(nullable = false)
    private boolean passed;

    @Column(name = "total_questions", nullable = false)
    private int totalQuestions;

    @Column(name = "correct_count", nullable = false)
    private int correctCount;

    @Column(name = "detailed_breakdown", columnDefinition = "LONGTEXT", nullable = false)
    private String detailedBreakdownJson; // [CO2] JSON containing question-by-question review

    @Column(name = "ai_evaluation_notes", columnDefinition = "TEXT", nullable = false)
    private String aiEvaluationNotes;

    @Column(name = "submitted_at", updatable = false)
    private LocalDateTime submittedAt;

    @PrePersist
    protected void onCreate() {
        this.submittedAt = LocalDateTime.now();
    }
}
