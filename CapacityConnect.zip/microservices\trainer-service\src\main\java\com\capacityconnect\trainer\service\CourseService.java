package com.capacityconnect.trainer.service;

import com.capacityconnect.trainer.dto.TrainerDtos.CreateCourseRequest;
import com.capacityconnect.trainer.model.Course;
import com.capacityconnect.trainer.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] Relational Course Management (CRUD for Trainers & Admins)
 * =============================================================================
 */
@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    public List<Course> getAllPublishedCourses() {
        return courseRepository.findByIsPublishedTrue();
    }

    public List<Course> getCoursesByTrainer(Long trainerId) {
        return courseRepository.findByTrainerId(trainerId);
    }

    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    @Transactional
    public Course createCourse(CreateCourseRequest request) {
        Course.Difficulty diff = Course.Difficulty.INTERMEDIATE;
        if (request.getDifficulty() != null) {
            try {
                diff = Course.Difficulty.valueOf(request.getDifficulty().toUpperCase());
            } catch (Exception ignored) {}
        }

        Course course = Course.builder()
                .trainerId(request.getTrainerId() != null ? request.getTrainerId() : 2L)
                .trainerName(request.getTrainerName() != null ? request.getTrainerName() : "Dr. Aris Vance")
                .title(request.getTitle())
                .skillName(request.getSkillName())
                .category(request.getCategory() != null ? request.getCategory() : "Database & Analytics")
                .difficulty(diff)
                .description(request.getDescription())
                .estimatedHours(request.getEstimatedHours() > 0 ? request.getEstimatedHours() : 10)
                .totalLessons(request.getTotalLessons() > 0 ? request.getTotalLessons() : 5)
                .isPublished(true)
                .build();

        return courseRepository.save(course);
    }

    @Transactional
    public Course updateCourse(Long id, CreateCourseRequest request) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Course with ID " + id + " not found."));

        if (request.getTitle() != null) course.setTitle(request.getTitle());
        if (request.getSkillName() != null) course.setSkillName(request.getSkillName());
        if (request.getCategory() != null) course.setCategory(request.getCategory());
        if (request.getDescription() != null) course.setDescription(request.getDescription());
        if (request.getEstimatedHours() > 0) course.setEstimatedHours(request.getEstimatedHours());
        if (request.getTotalLessons() > 0) course.setTotalLessons(request.getTotalLessons());

        return courseRepository.save(course);
    }

    @Transactional
    public void deleteCourse(Long id) {
        if (!courseRepository.existsById(id)) {
            throw new IllegalArgumentException("Course with ID " + id + " not found.");
        }
        courseRepository.deleteById(id);
    }
}
