package com.capacityconnect.user.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * =============================================================================
 * [CO3] Production REST API DTOs with Pydantic/JSR-380 Validation Patterns
 * =============================================================================
 */
public class AuthDtos {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class RegisterRequest {
        @NotBlank(message = "Full name is required")
        private String fullName;

        @NotBlank(message = "Email is required")
        @Email(message = "Must be a valid email address")
        private String email;

        @NotBlank(message = "Password is required")
        @Size(min = 4, message = "Password must be at least 4 characters")
        private String password;

        private String role; // "TRAINEE", "TRAINER", "ADMIN"
        private String targetRole;
        private String department;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class LoginRequest {
        @NotBlank(message = "Email is required")
        @Email(message = "Invalid email format")
        private String email;

        @NotBlank(message = "Password is required")
        private String password;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AuthResponse {
        private Long id;
        private String fullName;
        private String email;
        private String avatarUrl;
        private String primaryRole;
        private boolean isTrainee;
        private boolean isTrainer;
        private boolean isAdmin;
        private String activeRole;
        private String targetRole;
        private String department;
        private int careerScore;
        private int streak;
        private int learningProgress;
        private int xp;
        private String token;
    }
}
