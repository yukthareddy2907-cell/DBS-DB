package com.capacityconnect.skill.repository;

import com.capacityconnect.skill.model.CompetencyHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] Historical Progress & Competency Trajectory Tracking Repository
 * =============================================================================
 */
@Repository
public interface CompetencyHistoryRepository extends JpaRepository<CompetencyHistory, Long> {
    List<CompetencyHistory> findByUserIdOrderByRecordedAtDesc(Long userId);
}
