package com.capacityconnect.trainer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * =============================================================================
 * CAPACITY CONNECT — TRAINER, LEARNING & ASSESSMENT MICROSERVICE
 * =============================================================================
 * Course Outcomes Mapped:
 * [CO4] Develop backend services using Spring Boot through project-driven delivery.
 * [CO5] Bounded Context Domain: Trainer Matching, Courses, Knowledge Hub, Assessments.
 * =============================================================================
 */
@SpringBootApplication
public class TrainerServiceApplication {

    public static void main(String[] args) {
        System.out.println(">>> [CO4/CO5] Starting CAPACITY CONNECT - Trainer Microservice on Port 8083...");
        SpringApplication.run(TrainerServiceApplication.class, args);
        System.out.println(">>> [CO4/CO5] Trainer Microservice is LIVE at http://localhost:8083/api");
    }
}
