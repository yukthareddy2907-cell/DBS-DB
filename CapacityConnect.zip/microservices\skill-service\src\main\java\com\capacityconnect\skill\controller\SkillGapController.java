package com.capacityconnect.skill.controller;

import com.capacityconnect.skill.dto.SkillGapDtos.*;
import com.capacityconnect.skill.service.SkillGapEngineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * =============================================================================
 * [CO3] Asynchronous & Production-Ready REST API for AI Skill-Gap Analysis
 * [CO5] Bounded Context API for Competency Gap Calculations
 * =============================================================================
 */
@RestController
@RequestMapping("/gaps")
public class SkillGapController {

    private final SkillGapEngineService skillGapEngineService;

    @Autowired
    public SkillGapController(SkillGapEngineService skillGapEngineService) {
        this.skillGapEngineService = skillGapEngineService;
    }

    /**
     * GET /api/gaps/analyze?userId=4&targetRole=Data%20Analyst
     */
    @GetMapping("/analyze")
    public ResponseEntity<SkillGapAnalysisResponse> analyzeSkillGaps(
            @RequestParam(defaultValue = "4") Long userId,
            @RequestParam(defaultValue = "Data Analyst") String targetRole) {
        SkillGapAnalysisResponse response = skillGapEngineService.analyzeUserSkillGaps(userId, targetRole);
        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/gaps/update-competency (Closed Feedback Loop)
     */
    @PostMapping("/update-competency")
    public ResponseEntity<SkillGapAnalysisResponse> updateCompetency(@RequestBody UpdateCompetencyRequest request) {
        SkillGapAnalysisResponse updated = skillGapEngineService.updateUserCompetency(request);
        return ResponseEntity.ok(updated);
    }
}
