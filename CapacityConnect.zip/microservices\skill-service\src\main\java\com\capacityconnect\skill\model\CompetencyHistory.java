package com.capacityconnect.skill.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Competency History Entity for Closed Feedback Loop Progress Tracking
 * =============================================================================
 */
@Entity
@Table(name = "competency_history")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CompetencyHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "competency_id", nullable = false)
    private Competency competency;

    @Column(name = "previous_level", nullable = false)
    private int previousLevel;

    @Column(name = "new_level", nullable = false)
    private int newLevel;

    @Column(name = "trigger_event", nullable = false, length = 150)
    private String triggerEvent; // e.g. "Assessment Completed: 84% score"

    @Column(name = "assessment_score")
    private Double assessmentScore;

    @Column(name = "recorded_at", updatable = false)
    private LocalDateTime recordedAt;

    @PrePersist
    protected void onCreate() {
        this.recordedAt = LocalDateTime.now();
    }
}
