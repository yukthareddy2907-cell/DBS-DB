package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.CalendarNote;
import com.capacityconnect.trainer.model.ChatMessage;
import com.capacityconnect.trainer.model.SkillExchangeRequest;
import com.capacityconnect.trainer.model.TrainingSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Repositories for Skill Exchange, Real-Time Chat, Sessions & Calendar
 * =============================================================================
 */
public interface SkillExchangeRequestRepository extends JpaRepository<SkillExchangeRequest, Long> {
    List<SkillExchangeRequest> findByTrainerIdOrderByCreatedAtDesc(Long trainerId);
    List<SkillExchangeRequest> findByTraineeIdOrderByCreatedAtDesc(Long traineeId);
}
