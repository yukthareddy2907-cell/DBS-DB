package com.capacityconnect.skill.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Target Roles Entity
 * =============================================================================
 */
@Entity
@Table(name = "roles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoleFramework {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "role_name", nullable = false, unique = true, length = 150)
    private String roleName;

    @Column(nullable = false, length = 100)
    private String department;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
