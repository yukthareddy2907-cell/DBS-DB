package com.capacityconnect.trainer.controller;

import com.capacityconnect.trainer.dto.TrainerDtos.ExchangeRequestDto;
import com.capacityconnect.trainer.dto.TrainerDtos.SendChatMessageRequest;
import com.capacityconnect.trainer.model.ChatMessage;
import com.capacityconnect.trainer.model.SkillExchangeRequest;
import com.capacityconnect.trainer.service.ExchangeChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] REST Controller for Skill Exchange Lifecycle & Real-Time Chat
 * =============================================================================
 */
@RestController
@RequestMapping("/exchanges")
public class SkillExchangeController {

    private final ExchangeChatService exchangeChatService;

    @Autowired
    public SkillExchangeController(ExchangeChatService exchangeChatService) {
        this.exchangeChatService = exchangeChatService;
    }

    @GetMapping
    public ResponseEntity<List<SkillExchangeRequest>> getAllRequests() {
        return ResponseEntity.ok(exchangeChatService.getAllRequests());
    }

    @GetMapping("/trainer/{trainerId}")
    public ResponseEntity<List<SkillExchangeRequest>> getRequestsForTrainer(@PathVariable Long trainerId) {
        return ResponseEntity.ok(exchangeChatService.getRequestsForTrainer(trainerId));
    }

    @GetMapping("/trainee/{traineeId}")
    public ResponseEntity<List<SkillExchangeRequest>> getRequestsForTrainee(@PathVariable Long traineeId) {
        return ResponseEntity.ok(exchangeChatService.getRequestsForTrainee(traineeId));
    }

    @PostMapping("/send")
    public ResponseEntity<?> sendRequest(@RequestBody ExchangeRequestDto dto) {
        try {
            SkillExchangeRequest created = exchangeChatService.createRequest(dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PutMapping("/{id}/accept")
    public ResponseEntity<?> acceptRequest(@PathVariable Long id) {
        try {
            SkillExchangeRequest accepted = exchangeChatService.acceptRequest(id);
            return ResponseEntity.ok(accepted);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PutMapping("/{id}/decline")
    public ResponseEntity<?> declineRequest(@PathVariable Long id, @RequestBody(required = false) Map<String, String> body) {
        try {
            String reason = body != null ? body.get("reason") : "Schedule currently full.";
            SkillExchangeRequest declined = exchangeChatService.declineRequest(id, reason);
            return ResponseEntity.ok(declined);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @GetMapping("/{id}/messages")
    public ResponseEntity<List<ChatMessage>> getMessages(@PathVariable Long id) {
        return ResponseEntity.ok(exchangeChatService.getMessagesForExchange(id));
    }

    @PostMapping("/messages/send")
    public ResponseEntity<?> sendMessage(@RequestBody SendChatMessageRequest request) {
        try {
            ChatMessage msg = exchangeChatService.sendMessage(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(msg);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }
}
