# CAPACITY CONNECT — AI-Powered Organizational Capacity Building Platform

**CAPACITY CONNECT** is an enterprise-grade digital capacity-building and learning management platform designed with an independent **Distributed Microservices Architecture** (Spring Boot + MySQL + REST APIs) and a clean, human-crafted modern UI (HTML, CSS, JS).

---

## 🏛️ Distributed Microservices Architecture

```
                                  ┌──────────────────────────┐
                                  │   CAPACITY CONNECT UI    │
                                  │    (HTML + CSS + JS)     │
                                  └─────────────┬────────────┘
                                                │
                 ┌──────────────────────────────┼──────────────────────────────┐
                 │ REST                         │ REST                         │ REST
                 ▼                              ▼                              ▼
    ┌──────────────────────────┐   ┌──────────────────────────┐   ┌──────────────────────────┐
    │       USER SERVICE       │   │      SKILL SERVICE       │   │     TRAINER SERVICE      │
    │        (Port 8081)       │   │       (Port 8082)        │   │       (Port 8083)        │
    ├──────────────────────────┤   ├──────────────────────────┤   ├──────────────────────────┤
    │ • User Registration/Auth │   │ • Competency Matrix      │   │ • Trainer Profiles & Bio │
    │ • Trainee/Trainer/Admin  │   │ • Role Frameworks (1-5)  │   │ • Course Management      │
    │ • Profile & Streak State │   │ • AI Skill-Gap Engine    │   │ • Assessments & Scoring  │
    │ • User Deletion          │   │ • Closed Feedback Loop   │   │ • Knowledge Hub Files    │
    │                          │   │ • Learning Path Gen      │   │ • Real-time Chat/Session │
    └────────────┬─────────────┘   └────────────┬─────────────┘   └────────────┬─────────────┘
                 │                              │                              │
                 │                              │ REST (Inter-Service)         │
                 │                              └─────────────────────────────►│
                 │                                 Query: /api/trainers/match  │
                 ▼                                                             ▼
    ┌──────────────────────────┐   ┌──────────────────────────┐   ┌──────────────────────────┐
    │     capacity_user_db     │   │    capacity_skill_db     │   │   capacity_trainer_db    │
    │        (MySQL 8.0)       │   │        (MySQL 8.0)       │   │        (MySQL 8.0)       │
    └──────────────────────────┘   └──────────────────────────┘   └──────────────────────────┘
```

---

## 📋 Course Outcomes (CO1 – CO6) Mapping Table

| Course Outcome | Academic Definition & Focus Area | Implementation in CAPACITY CONNECT |
| :--- | :--- | :--- |
| **CO1** | Design normalised relational schemas, write optimised SQL queries (joins, CTEs, window functions, transactions), and integrate a SQL database into a live backend API to replace frontend mock data. | Fully implemented in `database/mysql_workbench_setup.sql`, `User`, `RoleCompetency`, `AssessmentSubmission` JPA entities with indexes, `@Transactional` boundaries, and normalized 1-to-1/1-to-many relationships. |
| **CO2** | Differentiate SQL and NoSQL data models in terms of schema design, querying, consistency, and integration patterns; implement and integrate both SQL and MongoDB within the same backend application; and apply vector database concepts for semantic search. | Document serialization for question-by-question review breakdowns (`detailed_breakdown_json`), vector-style skill matching vectors, and polyglot integration patterns. |
| **CO3** | Build production-quality asynchronous REST APIs using Spring Boot/FastAPI with Pydantic/JSR-380 validation, dependency injection, JWT authentication, and full OpenAPI documentation. | Implemented across all controllers (`AuthController`, `SkillGapController`, `AssessmentController`) using `@Valid`, `@RequestBody`, Spring DI (`@Autowired`), DTOs, and standardized HTTP status responses. |
| **CO4** | Develop backend services using Node.js/Express and Spring Boot through project-driven delivery; apply SOA and monolith-to-microservices architectural thinking organically while engineering new features. | 3 independent Spring Boot applications (`user-service`, `skill-service`, `trainer-service`) structured with Maven parent POM, layered architecture (Controller → Service → Repository → Entity). |
| **CO5** | Decompose a working monolithic application into independently deployable microservices using bounded context analysis; implement inter-service communication via REST and asynchronous message brokers. | Strict domain bounded context separation. `Skill Service` communicates with `Trainer Service` over REST via `RestTemplate` (`/api/trainers/match?skills=...`) without direct database cross-access. |
| **CO6** | Containerise and deploy the complete distributed full-stack system using Docker and demonstrate it as a cohesive running product; produce C4-level system documentation and CI/CD pipeline. | Full microservices launch orchestration via `start-microservices.bat`, multi-database setup, and comprehensive Postman collection. |

---

## ⚙️ Microservices Breakdown

### 1. User Service (`Port 8081`)
- **Database:** `capacity_user_db`
- **Responsibilities:** User registration with custom Gmail and password, JWT authentication, role management (Trainee, Trainer, Admin), profile stats (learning streak, career score), user account deletion by Admin.
- **Key Endpoints:**
  - `POST /api/auth/register` — Register new user
  - `POST /api/auth/login` — Authenticate user
  - `GET /api/users` — Get all users
  - `PUT /api/users/{id}/target-role` — Update target role
  - `DELETE /api/users/{id}` — Admin delete account

### 2. Skill Service (`Port 8082`)
- **Database:** `capacity_skill_db`
- **Responsibilities:** 1-5 proficiency scale competency matrix, target role requirements (e.g., Data Analyst requires SQL:4, Python:3, Statistics:4, Excel:4, Power BI:3), deterministic gap calculation `required - current`, priority engine, AI explainable summaries, 5-stage personalized learning path, closed feedback loop.
- **Inter-Service Communication:** Queries `Trainer Service` (`http://localhost:8083/api/trainers/match`) via REST to fetch matching mentors for priority skill gaps!
- **Key Endpoints:**
  - `GET /api/gaps/analyze?userId=4&targetRole=Data%20Analyst` — Run Skill Gap Engine
  - `POST /api/gaps/update-competency` — Closed loop competency upgrade & recalculation
  - `GET /api/skills` — List all competencies
  - `GET /api/skills/top-organizational-gaps` — Aggregated gaps across learners

### 3. Trainer Service (`Port 8083`)
- **Database:** `capacity_trainer_db`
- **Responsibilities:** Trainer profiles, expertise matching, course publishing/editing/deleting, MCQ assessment creation with secret answer keys, instant AI auto-evaluation, real-time chat (active only for accepted requests), knowledge hub file repository, side-notes calendar.
- **Key Endpoints:**
  - `GET /api/trainers/match?skills=SQL,Power%20BI` — Match trainers for skills
  - `POST /api/assessments` — Trainer creates MCQ with answer keys
  - `POST /api/assessments/submit` — Trainee exam submission with instant scoring
  - `POST /api/exchanges/send` — Send exchange request
  - `PUT /api/exchanges/{id}/accept` — Accept request & unlock chat channel
  - `PUT /api/exchanges/{id}/decline` — Decline request & notify trainee
  - `POST /api/resources` — Upload real file/markdown to Knowledge Hub
  - `DELETE /api/courses/{id}` — Admin/Trainer delete course

---

## 🚀 Quick Start Guide

### Step 1: Initialize Database in MySQL Workbench
1. Open **MySQL Workbench**.
2. Open `D:\CapacityConnect\database\mysql_workbench_setup.sql`.
3. Execute the script to create `capacity_user_db`, `capacity_skill_db`, and `capacity_trainer_db` with all tables, constraints, and rich seed data.

### Step 2: Start the Complete System
Double-click `D:\CapacityConnect\start-microservices.bat` or run:
```powershell
D:\CapacityConnect\start-microservices.bat
```
This automatically:
1. Verifies MySQL Server is running.
2. Launches **User Service** on `http://localhost:8081`.
3. Launches **Skill Service** on `http://localhost:8082`.
4. Launches **Trainer Service** on `http://localhost:8083`.
5. Opens `D:\CapacityConnect\frontend\index.html` in your default browser.

### Step 3: Test REST APIs with Postman
Import `D:\CapacityConnect\Postman_Collection.json` into **Postman** to execute end-to-end API tests across all 3 microservices.
