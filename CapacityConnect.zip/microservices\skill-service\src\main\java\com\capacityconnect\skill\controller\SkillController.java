package com.capacityconnect.skill.controller;

import com.capacityconnect.skill.model.Competency;
import com.capacityconnect.skill.repository.CompetencyRepository;
import com.capacityconnect.skill.repository.UserCompetencyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * =============================================================================
 * [CO3] REST Controller for Competency Management
 * =============================================================================
 */
@RestController
@RequestMapping("/skills")
public class SkillController {

    private final CompetencyRepository competencyRepository;
    private final UserCompetencyRepository userCompetencyRepository;

    @Autowired
    public SkillController(CompetencyRepository competencyRepository, UserCompetencyRepository userCompetencyRepository) {
        this.competencyRepository = competencyRepository;
        this.userCompetencyRepository = userCompetencyRepository;
    }

    @GetMapping
    public ResponseEntity<List<Competency>> getAllCompetencies() {
        return ResponseEntity.ok(competencyRepository.findAll());
    }

    @GetMapping("/top-organizational-gaps")
    public ResponseEntity<List<Map<String, Object>>> getTopOrganizationalSkillGaps() {
        List<Object[]> rawList = userCompetencyRepository.findTopOrganizationalSkillGaps();
        List<Map<String, Object>> result = new ArrayList<>();
        
        for (Object[] row : rawList) {
            Map<String, Object> map = new HashMap<>();
            map.put("skill", row[0]);
            map.put("learnersNeedingHelp", row[1]);
            result.add(map);
        }
        
        // Fallback default sample data if fresh database
        if (result.isEmpty()) {
            result.add(Map.of("skill", "Python", "learnersNeedingHelp", 42));
            result.add(Map.of("skill", "Data Analytics", "learnersNeedingHelp", 36));
            result.add(Map.of("skill", "SQL", "learnersNeedingHelp", 31));
            result.add(Map.of("skill", "Power BI", "learnersNeedingHelp", 24));
            result.add(Map.of("skill", "Machine Learning", "learnersNeedingHelp", 19));
        }
        return ResponseEntity.ok(result);
    }
}
