@echo off
title CAPACITY CONNECT - Startup Launcher
echo ===================================================
echo     Launching CAPACITY CONNECT Platform...
echo ===================================================
echo.

:: 1. Check & Ensure MySQL Service is running
echo [1/3] Checking MySQL Server status...
net start MySQL80 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  - MySQL Server is active.
) else (
    echo  - MySQL Server already running or managed by Windows service.
)

:: 2. Launch the Frontend in Default Browser
echo [2/3] Opening CAPACITY CONNECT Website in your browser...
start "" "D:\CapacityConnect\frontend\index.html"

:: 3. Launch Distributed Microservices
echo [3/3] Launching Spring Boot Microservices (Ports 8081, 8082, 8083)...
call "D:\CapacityConnect\start-microservices.bat"
