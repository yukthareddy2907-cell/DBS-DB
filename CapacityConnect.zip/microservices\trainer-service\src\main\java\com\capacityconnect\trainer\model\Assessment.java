package com.capacityconnect.trainer.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Assessments Framework with Question Cascade
 * =============================================================================
 */
@Entity
@Table(name = "assessments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "trainer_id", nullable = false)
    private Long trainerId;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(name = "skill_name", nullable = false, length = 100)
    private String skillName;

    @Column(name = "target_role", nullable = false, length = 150)
    @Builder.Default
    private String targetRole = "Data Analyst";

    @Column(name = "duration_minutes")
    @Builder.Default
    private int durationMinutes = 20;

    @Column(name = "passing_score")
    @Builder.Default
    private int passingScore = 75;

    @Column(name = "target_proficiency")
    @Builder.Default
    private int targetProficiency = 3;

    @OneToMany(mappedBy = "assessment", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JsonManagedReference
    @Builder.Default
    private List<AssessmentQuestion> questions = new ArrayList<>();

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
