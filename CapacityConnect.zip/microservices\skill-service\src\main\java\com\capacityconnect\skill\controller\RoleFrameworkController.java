package com.capacityconnect.skill.controller;

import com.capacityconnect.skill.model.RoleCompetency;
import com.capacityconnect.skill.model.RoleFramework;
import com.capacityconnect.skill.repository.RoleCompetencyRepository;
import com.capacityconnect.skill.repository.RoleFrameworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * =============================================================================
 * [CO3] REST Controller for Role Framework & Competency Requirements
 * =============================================================================
 */
@RestController
@RequestMapping("/roles")
public class RoleFrameworkController {

    private final RoleFrameworkRepository roleFrameworkRepository;
    private final RoleCompetencyRepository roleCompetencyRepository;

    @Autowired
    public RoleFrameworkController(RoleFrameworkRepository roleFrameworkRepository,
                                  RoleCompetencyRepository roleCompetencyRepository) {
        this.roleFrameworkRepository = roleFrameworkRepository;
        this.roleCompetencyRepository = roleCompetencyRepository;
    }

    @GetMapping
    public ResponseEntity<List<RoleFramework>> getAllRoles() {
        return ResponseEntity.ok(roleFrameworkRepository.findAll());
    }

    @GetMapping("/{roleName}/requirements")
    public ResponseEntity<List<RoleCompetency>> getRoleRequirements(@PathVariable String roleName) {
        return ResponseEntity.ok(roleCompetencyRepository.findByRoleName(roleName));
    }
}
