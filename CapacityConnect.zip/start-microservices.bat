@echo off
title CAPACITY CONNECT — Microservices Suite Launcher
echo ======================================================================
echo           CAPACITY CONNECT — DISTRIBUTED MICROSERVICES SUITE
echo ======================================================================
echo.

:: 1. Check MySQL Service
echo [1/5] Checking MySQL 8.0 Server status...
net start MySQL80 >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo       - MySQL Server is running.
) else (
    echo       - MySQL Server active or managed by Windows service.
)
echo.

:: 2. Launch USER SERVICE (Port 8081)
echo [2/5] Starting USER SERVICE (Port 8081, Database: capacity_user_db)...
start "User Service [Port 8081]" cmd /k "cd /d D:\CapacityConnect\microservices\user-service && mvn spring-boot:run"

:: 3. Launch SKILL SERVICE (Port 8082)
echo [3/5] Starting SKILL SERVICE (Port 8082, Database: capacity_skill_db)...
start "Skill Service [Port 8082]" cmd /k "cd /d D:\CapacityConnect\microservices\skill-service && mvn spring-boot:run"

:: 4. Launch TRAINER SERVICE (Port 8083)
echo [4/5] Starting TRAINER SERVICE (Port 8083, Database: capacity_trainer_db)...
start "Trainer Service [Port 8083]" cmd /k "cd /d D:\CapacityConnect\microservices\trainer-service && mvn spring-boot:run"

:: 5. Open CAPACITY CONNECT Web Interface in Default Browser
echo [5/5] Launching CAPACITY CONNECT Frontend in default browser...
start "" "D:\CapacityConnect\frontend\index.html"

echo.
echo ======================================================================
echo  All 3 Spring Boot Microservices have been launched in separate windows:
echo   - User Service:    http://localhost:8081/api
echo   - Skill Service:   http://localhost:8082/api
echo   - Trainer Service: http://localhost:8083/api
echo ======================================================================
echo.
pause
