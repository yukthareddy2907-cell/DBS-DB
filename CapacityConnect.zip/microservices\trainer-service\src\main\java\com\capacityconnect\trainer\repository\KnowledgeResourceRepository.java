package com.capacityconnect.trainer.repository;

import com.capacityconnect.trainer.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] JPA Repositories for Knowledge Resources, Assessments, Chat, Sessions
 * =============================================================================
 */
@Repository
public interface KnowledgeResourceRepository extends JpaRepository<KnowledgeResource, Long> {
    List<KnowledgeResource> findBySkillName(String skillName);
}
