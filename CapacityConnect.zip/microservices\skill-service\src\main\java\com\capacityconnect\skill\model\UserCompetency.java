package com.capacityconnect.skill.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: User Competency Records (1-5 Scale)
 * =============================================================================
 */
@Entity
@Table(name = "user_competencies", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"user_id", "competency_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserCompetency {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "competency_id", nullable = false)
    private Competency competency;

    @Column(name = "current_proficiency", nullable = false)
    private int currentProficiency; // 1 = Beginner, 2 = Basic, 3 = Intermediate, 4 = Advanced, 5 = Expert

    @Column(length = 255)
    @Builder.Default
    private String evidence = "Self-Assessment & Baseline Assessment";

    @Column(name = "confidence_score")
    @Builder.Default
    private double confidenceScore = 0.85;

    @Column(name = "last_assessed_at")
    private LocalDateTime lastAssessedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        this.lastAssessedAt = LocalDateTime.now();
    }
}
