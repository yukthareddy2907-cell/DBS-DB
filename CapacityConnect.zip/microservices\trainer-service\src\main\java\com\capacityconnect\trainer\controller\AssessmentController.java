package com.capacityconnect.trainer.controller;

import com.capacityconnect.trainer.dto.TrainerDtos.AssessmentEvaluationResult;
import com.capacityconnect.trainer.dto.TrainerDtos.CreateAssessmentRequest;
import com.capacityconnect.trainer.dto.TrainerDtos.SubmitAssessmentRequest;
import com.capacityconnect.trainer.model.Assessment;
import com.capacityconnect.trainer.model.AssessmentSubmission;
import com.capacityconnect.trainer.service.AssessmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] Production REST Controller for Assessments & Instant AI Auto-Evaluation
 * =============================================================================
 */
@RestController
@RequestMapping("/assessments")
public class AssessmentController {

    private final AssessmentService assessmentService;

    @Autowired
    public AssessmentController(AssessmentService assessmentService) {
        this.assessmentService = assessmentService;
    }

    @GetMapping
    public ResponseEntity<List<Assessment>> getAllAssessments() {
        return ResponseEntity.ok(assessmentService.getAllAssessments());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getAssessmentById(@PathVariable Long id) {
        return assessmentService.getAssessmentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/trainer/{trainerId}")
    public ResponseEntity<List<Assessment>> getTrainerAssessments(@PathVariable Long trainerId) {
        return ResponseEntity.ok(assessmentService.getAssessmentsByTrainerId(trainerId));
    }

    /**
     * [CO1] Trainer Creates / Uploads New Assessment with Questions & Answer Keys
     */
    @PostMapping
    public ResponseEntity<?> createAssessment(@RequestBody CreateAssessmentRequest request) {
        try {
            Assessment created = assessmentService.createAssessment(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    /**
     * [CO3] Trainee Submits Exam -> Instant Server-Side Evaluation & Scoring
     */
    @PostMapping("/submit")
    public ResponseEntity<?> submitAssessment(@RequestBody SubmitAssessmentRequest request) {
        try {
            AssessmentEvaluationResult result = assessmentService.evaluateSubmission(request);
            return ResponseEntity.ok(result);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @GetMapping("/submissions/user/{userId}")
    public ResponseEntity<List<AssessmentSubmission>> getUserSubmissions(@PathVariable Long userId) {
        return ResponseEntity.ok(assessmentService.getSubmissionsByUserId(userId));
    }

    @GetMapping("/submissions/trainer/{trainerId}")
    public ResponseEntity<List<AssessmentSubmission>> getTrainerSubmissions(@PathVariable Long trainerId) {
        return ResponseEntity.ok(assessmentService.getSubmissionsForTrainer(trainerId));
    }
}
