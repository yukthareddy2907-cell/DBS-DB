package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Trainer Profiles
 * =============================================================================
 */
@Entity
@Table(name = "trainer_profiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainerProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;

    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(name = "avatar_url", length = 500)
    private String avatarUrl;

    @Column(name = "primary_expertise", nullable = false, length = 200)
    private String primaryExpertise;

    @Column(name = "skills_taught", nullable = false, length = 500)
    private String skillsTaught; // e.g. "SQL, PostgreSQL, Data Modeling"

    @Column(name = "skills_wants", length = 500)
    private String skillsWants;

    @Column(name = "experience_years")
    @Builder.Default
    private int experienceYears = 8;

    @Column(precision = 3, scale = 2)
    @Builder.Default
    private double rating = 4.90;

    @Column(name = "availability_status", length = 100)
    @Builder.Default
    private String availabilityStatus = "Available on Thursdays & Weekends";

    @Column(columnDefinition = "TEXT", nullable = false)
    private String bio;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
