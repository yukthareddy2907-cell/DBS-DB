package com.capacityconnect.user.repository;

import com.capacityconnect.user.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] Optimized SQL Queries, Indexes, and Relational Data Access
 * =============================================================================
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    List<User> findByIsTraineeTrue();

    List<User> findByIsTrainerTrue();

    List<User> findByIsAdminTrue();

    @Query("SELECT COUNT(u) FROM User u WHERE u.isTrainee = true")
    long countActiveTrainees();

    @Query("SELECT COUNT(u) FROM User u WHERE u.isTrainer = true")
    long countActiveTrainers();
}
