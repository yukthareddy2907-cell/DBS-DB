package com.capacityconnect.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * =============================================================================
 * CAPACITY CONNECT — USER SERVICE APPLICATION
 * =============================================================================
 * Course Outcomes Mapped:
 * [CO4] Develop backend services using Spring Boot through project-driven delivery;
 *       apply SOA and monolith-to-microservices architectural thinking.
 * [CO5] Decompose a working monolithic application into independently deployable
 *       microservices using bounded context analysis (USER DOMAIN).
 * =============================================================================
 */
@SpringBootApplication
public class UserServiceApplication {

    public static void main(String[] args) {
        System.out.println(">>> [CO4/CO5] Starting CAPACITY CONNECT - User Microservice on Port 8081...");
        SpringApplication.run(UserServiceApplication.class, args);
        System.out.println(">>> [CO4/CO5] User Microservice is LIVE and accepting REST requests at http://localhost:8081/api");
    }
}
