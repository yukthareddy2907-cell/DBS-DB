package com.capacityconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapacityConnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(CapacityConnectApplication.class, args);
        System.out.println("=================================================");
        System.out.println("  CAPACITY CONNECT API Server running on port 8080");
        System.out.println("  Context Path: http://localhost:8080/api");
        System.out.println("=================================================");
    }
}
