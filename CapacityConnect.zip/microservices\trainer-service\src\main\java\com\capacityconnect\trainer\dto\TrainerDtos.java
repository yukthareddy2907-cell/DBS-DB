package com.capacityconnect.trainer.dto;

import lombok.*;
import java.util.List;
import java.util.Map;

/**
 * =============================================================================
 * [CO3] Structured REST API DTOs for Trainer, Course & Assessment Management
 * =============================================================================
 */
public class TrainerDtos {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateAssessmentRequest {
        private Long trainerId;
        private String title;
        private String skillName;
        private String targetRole;
        private int durationMinutes;
        private int passingScore;
        private int targetProficiency;
        private List<QuestionDto> questions;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class QuestionDto {
        private String questionText;
        private String optionA;
        private String optionB;
        private String optionC;
        private String optionD;
        private String correctOption; // 'A', 'B', 'C', 'D'
        private String explanation;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SubmitAssessmentRequest {
        private Long assessmentId;
        private Long userId;
        private String userName;
        private Map<Long, String> selectedAnswers; // questionId -> option ("A","B","C","D")
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AssessmentEvaluationResult {
        private Long submissionId;
        private Long assessmentId;
        private String assessmentTitle;
        private String skillName;
        private double scorePercentage;
        private boolean passed;
        private int correctCount;
        private int totalQuestions;
        private int newProficiencyLevel;
        private List<QuestionReviewItem> questionReviews;
        private String aiEvaluationNotes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class QuestionReviewItem {
        private Long questionId;
        private String questionText;
        private String selectedOption;
        private String correctOption;
        private boolean isCorrect;
        private String explanation;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateCourseRequest {
        private Long trainerId;
        private String trainerName;
        private String title;
        private String skillName;
        private String category;
        private String difficulty; // BEGINNER, INTERMEDIATE, ADVANCED
        private String description;
        private int estimatedHours;
        private int totalLessons;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateKnowledgeResourceRequest {
        private Long uploadedById;
        private String uploadedByName;
        private String title;
        private String skillName;
        private String category;
        private String resourceType; // DOCUMENT, CHEATSHEET, PROJECT_CODE, GUIDE, PRACTICE
        private String fileName;
        private String fileContent;
        private int fileSizeKb;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ExchangeRequestDto {
        private Long traineeId;
        private String traineeName;
        private Long trainerId;
        private String trainerName;
        private String skillRequested;
        private String skillOffered;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SendChatMessageRequest {
        private Long exchangeId;
        private Long senderId;
        private String senderName;
        private Long receiverId;
        private String messageText;
    }
}
