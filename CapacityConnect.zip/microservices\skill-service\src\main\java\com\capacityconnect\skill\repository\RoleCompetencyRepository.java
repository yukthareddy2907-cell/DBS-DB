package com.capacityconnect.skill.repository;

import com.capacityconnect.skill.model.RoleCompetency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * =============================================================================
 * [CO1] Optimized SQL Queries: Role-to-Competency Mapping Lookups
 * =============================================================================
 */
@Repository
public interface RoleCompetencyRepository extends JpaRepository<RoleCompetency, Long> {

    List<RoleCompetency> findByRoleId(Long roleId);

    @Query("SELECT rc FROM RoleCompetency rc WHERE rc.role.roleName = :roleName")
    List<RoleCompetency> findByRoleName(@Param("roleName") String roleName);
}
