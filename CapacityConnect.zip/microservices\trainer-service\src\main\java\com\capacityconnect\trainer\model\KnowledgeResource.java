package com.capacityconnect.trainer.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * =============================================================================
 * [CO1] Relational Schema Design: Knowledge Hub Resources with Real Download Content
 * =============================================================================
 */
@Entity
@Table(name = "knowledge_resources")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KnowledgeResource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "uploaded_by_id", nullable = false)
    private Long uploadedById;

    @Column(name = "uploaded_by_name", nullable = false, length = 150)
    private String uploadedByName;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(name = "skill_name", nullable = false, length = 100)
    private String skillName;

    @Column(nullable = false, length = 100)
    private String category;

    @Enumerated(EnumType.STRING)
    @Column(name = "resource_type", nullable = false)
    @Builder.Default
    private ResourceType resourceType = ResourceType.DOCUMENT;

    @Column(name = "file_name", nullable = false, length = 200)
    private String fileName;

    @Column(name = "file_content", columnDefinition = "LONGTEXT", nullable = false)
    private String fileContent; // Real downloadable file content / markdown / code

    @Column(name = "file_size_kb")
    @Builder.Default
    private int fileSizeKb = 240;

    @Column(name = "download_count")
    @Builder.Default
    private int downloadCount = 0;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public enum ResourceType {
        DOCUMENT, CHEATSHEET, PROJECT_CODE, GUIDE, PRACTICE
    }
}
