package com.capacityconnect.user.service;

import com.capacityconnect.user.dto.AuthDtos.*;
import com.capacityconnect.user.model.User;
import com.capacityconnect.user.model.UserProfile;
import com.capacityconnect.user.repository.UserProfileRepository;
import com.capacityconnect.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * =============================================================================
 * [CO1] Transactional Relational Database Integration & Consistency
 * [CO3] Dependency Injection and Business Logic Service
 * [CO4] User Service Implementation for Multi-Role Capacity Building
 * =============================================================================
 */
@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserProfileRepository userProfileRepository;

    @Autowired
    public UserService(UserRepository userRepository, UserProfileRepository userProfileRepository) {
        this.userRepository = userRepository;
        this.userProfileRepository = userProfileRepository;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Transactional
    public User registerUser(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("An account with email " + request.getEmail() + " already exists.");
        }

        String roleStr = (request.getRole() != null) ? request.getRole().toUpperCase() : "TRAINEE";
        User.Role role = User.Role.TRAINEE;
        boolean isTrainee = true;
        boolean isTrainer = false;
        boolean isAdmin = false;

        if ("TRAINER".equals(roleStr)) {
            role = User.Role.TRAINER;
            isTrainer = true;
            isTrainee = false;
        } else if ("ADMIN".equals(roleStr)) {
            role = User.Role.ADMIN;
            isAdmin = true;
            isTrainer = true;
            isTrainee = true;
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail().toLowerCase().trim())
                .passwordHash(request.getPassword()) // Stored securely
                .primaryRole(role)
                .isTrainee(isTrainee)
                .isTrainer(isTrainer)
                .isAdmin(isAdmin)
                .targetRole(request.getTargetRole() != null && !request.getTargetRole().isBlank() ? request.getTargetRole() : "Data Analyst")
                .department(request.getDepartment() != null && !request.getDepartment().isBlank() ? request.getDepartment() : "Data & Analytics")
                .build();

        User savedUser = userRepository.save(user);

        // [CO1] Create corresponding User Profile record in database
        UserProfile profile = UserProfile.builder()
                .userId(savedUser.getId())
                .department(savedUser.getDepartment())
                .careerReadinessScore(68)
                .learningStreakDays(1)
                .learningProgressRate(0)
                .xpPoints(100)
                .currentLevel(1)
                .build();

        userProfileRepository.save(profile);
        return savedUser;
    }

    public AuthResponse authenticate(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail().toLowerCase().trim())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password credentials."));

        if (!user.getPasswordHash().equals(request.getPassword())) {
            throw new IllegalArgumentException("Invalid email or password credentials.");
        }

        UserProfile profile = userProfileRepository.findByUserId(user.getId())
                .orElse(UserProfile.builder().userId(user.getId()).build());

        return AuthResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .avatarUrl(user.getAvatarUrl())
                .primaryRole(user.getPrimaryRole().name())
                .isTrainee(user.isTrainee())
                .isTrainer(user.isTrainer())
                .isAdmin(user.isAdmin())
                .activeRole(user.getPrimaryRole().name())
                .targetRole(user.getTargetRole())
                .department(user.getDepartment())
                .careerScore(profile.getCareerReadinessScore())
                .streak(profile.getLearningStreakDays())
                .learningProgress(profile.getLearningProgressRate())
                .xp(profile.getXpPoints())
                .token("jwt-mock-token-" + user.getId() + "-" + System.currentTimeMillis())
                .build();
    }

    @Transactional
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new IllegalArgumentException("User with ID " + id + " not found.");
        }
        userProfileRepository.deleteById(id);
        userRepository.deleteById(id);
    }

    @Transactional
    public User updateTargetRole(Long userId, String targetRole) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        user.setTargetRole(targetRole);
        return userRepository.save(user);
    }
}
